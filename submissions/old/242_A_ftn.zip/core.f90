module dtm_core
  use iso_c_binding
  use omp_lib
  implicit none
  private
  public :: ftn_dir, ftn_acc, ftn_ws, ftn_fmt_dir, ftn_fmt_acc, ftn_fmt_lab

  integer, parameter :: i8 = c_int8_t, i32 = c_int32_t, i64 = c_int64_t
  integer(i8), parameter :: NODIR = -9_i8
  integer(i8), parameter :: F80 = transfer(-32640_c_int16_t, 0_i8)
  integer(i8), parameter :: F81 = -127_i8
  integer, parameter :: MW = 8
  integer(i32), parameter :: WALK_DEFER = 256
  integer(i32), parameter :: WALK_DEFER_LOW = 16
  integer(i64), parameter :: WB = 4096
  integer(i64), parameter :: RB = 16384
  integer(i64), parameter :: CR_MAXP = 2
  integer(i64), parameter :: HMUL = 2654435761_i64
  integer(i64), parameter :: HMASK = 4294967295_i64
  integer(i64), parameter :: HLIM = 67108864_i64

  integer :: ii_
  integer(i8), parameter :: DIG2(0:199) = [(int(48 + (1 - mod(ii_, 2)) * ((ii_ / 2) / 10) &
       + mod(ii_, 2) * mod(ii_ / 2, 10), i8), ii_ = 0, 199)]

  interface
    type(c_ptr) function c_realloc(p, nbytes) bind(C, name='realloc')
      import :: c_ptr, c_size_t
      type(c_ptr), value :: p
      integer(c_size_t), value :: nbytes
    end function c_realloc
    subroutine c_free(p) bind(C, name='free')
      import :: c_ptr
      type(c_ptr), value :: p
    end subroutine c_free
  end interface

  type, bind(C) :: wcont
    integer(c_int64_t) :: c
    integer(c_int32_t) :: a, s
  end type wcont
  type, bind(C) :: ruler
    integer(c_int64_t) :: cell, last, sum, len
    integer(c_int32_t) :: a_in, src
  end type ruler
  type, bind(C) :: wlist
    type(c_ptr) :: p
    integer(c_int64_t) :: n, cap
    integer(c_int64_t) :: pad(5)
  end type wlist

contains

  subroutine ftn_dir(n, m, nv, t, DR) bind(C, name='ftn_dir')
    integer(c_int), value :: n, m
    real(c_float), value :: nv
    real(c_float), intent(in) :: t(-int(m, i64) : int(n, i64) * m + m - 1)
    integer(i8), intent(inout) :: DR(-int(m, i64) - 1 : int(n, i64) * m + m)
    integer :: i, code
    integer(i64) :: M8, o, j, u, w
    real(c_float) :: v, mn, xx
    logical :: c
    M8 = m
    !$omp parallel do schedule(static) private(o, j, u, w, v, mn, xx, c, code)
    do i = 0, n - 1
      o = int(i, i64) * M8
      u = o - M8
      w = o + M8
      v = t(o); mn = v; code = 0
      xx = t(u);     if (xx /= nv .and. xx < mn) then; mn = xx; code = 1; end if
      xx = t(u + 1); if (xx /= nv .and. xx < mn) then; mn = xx; code = 2; end if
      xx = t(o + 1); if (xx /= nv .and. xx < mn) then; mn = xx; code = 3; end if
      xx = t(w + 1); if (xx /= nv .and. xx < mn) then; mn = xx; code = 4; end if
      xx = t(w);     if (xx /= nv .and. xx < mn) then; mn = xx; code = 5; end if
      if (v /= nv) then; DR(o) = int(code, i8); else; DR(o) = NODIR; end if
      do j = 1, M8 - 2
        v = t(o + j); mn = v; code = 0
        xx = t(u + j);     c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(1, code, c)
        xx = t(u + j + 1); c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(2, code, c)
        xx = t(o + j + 1); c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(3, code, c)
        xx = t(w + j + 1); c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(4, code, c)
        xx = t(w + j);     c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(5, code, c)
        xx = t(w + j - 1); c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(6, code, c)
        xx = t(o + j - 1); c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(7, code, c)
        xx = t(u + j - 1); c = (xx /= nv) .and. (xx < mn); mn = merge(xx, mn, c); code = merge(8, code, c)
        DR(o + j) = merge(int(code, i8), NODIR, v /= nv)
      end do
      j = M8 - 1
      v = t(o + j); mn = v; code = 0
      xx = t(w + j);     if (xx /= nv .and. xx < mn) then; mn = xx; code = 5; end if
      xx = t(w + j - 1); if (xx /= nv .and. xx < mn) then; mn = xx; code = 6; end if
      xx = t(o + j - 1); if (xx /= nv .and. xx < mn) then; mn = xx; code = 7; end if
      xx = t(u + j - 1); if (xx /= nv .and. xx < mn) then; mn = xx; code = 8; end if
      xx = t(u + j);     if (xx /= nv .and. xx < mn) then; mn = xx; code = 1; end if
      if (v /= nv) then; DR(o + j) = int(code, i8); else; DR(o + j) = NODIR; end if
    end do
    !$omp end parallel do
  end subroutine ftn_dir

  pure logical function rhash(x)
    integer(i64), intent(in) :: x
    rhash = iand(x * HMUL, HMASK) < HLIM
  end function rhash

  subroutine wl_push(l, src, esize)
    type(wlist), intent(inout) :: l
    type(c_ptr), intent(in) :: src
    integer(c_int64_t), intent(in) :: esize
    integer(i8), pointer, contiguous :: dst(:), from(:)
    if (l%n == l%cap) then
      l%cap = max(64_i64, 2 * l%cap)
      l%p = c_realloc(l%p, int(l%cap * esize, c_size_t))
    end if
    call c_f_pointer(l%p, dst, [l%cap * esize])
    call c_f_pointer(src, from, [esize])
    dst(l%n * esize + 1 : l%n * esize + esize) = from(1:esize)
    l%n = l%n + 1
  end subroutine wl_push

  subroutine park_push(l, x, a, s)
    type(wlist), intent(inout) :: l
    integer(i64), intent(in) :: x
    integer(i32), intent(in) :: a, s
    type(wcont), target :: w
    w%c = x; w%a = a; w%s = s
    call wl_push(l, c_loc(w), 16_i64)
  end subroutine park_push

  subroutine walk_src(b, e, V, M8, DR, indeg, acc, SEG, STOP, off, park, st, budget)
    integer(i64), intent(in) :: b, e, V, M8
    integer(i8), intent(in) :: DR(-M8 - 1 : V + M8)
    integer(i8), intent(inout) :: indeg(0 : V - 1)
    integer(i32), intent(inout) :: acc(0 : V - 1), SEG(0 : V - 1), STOP(0 : V - 1)
    integer(i64), intent(in) :: off(0:8)
    type(wlist), intent(inout) :: park
    integer(i64), intent(inout) :: st
    integer(i64), intent(in) :: budget
    integer(i64) :: wc(0:MW - 1), nx, c, x
    integer(i32) :: wa(0:MW - 1), wsrc(0:MW - 1), wst(0:MW - 1), wlim(0:MW - 1), a
    integer(i8) :: cur, u, dg
    integer :: nact, k, dd
    logical :: done

    nx = b
    nact = 0
    do while (nact < MW .and. nx < e)
      !$omp atomic read
      dg = indeg(nx)
      if (dg == 0_i8 .and. DR(nx) /= NODIR) then
        wc(nact) = nx; wa(nact) = 1; wsrc(nact) = int(nx, i32); SEG(nx) = int(nx, i32)
        wst(nact) = 0; wlim(nact) = merge(WALK_DEFER_LOW, WALK_DEFER, st > budget)
        nact = nact + 1
      end if
      nx = nx + 1
    end do
    do while (nact > 0)
      k = 0
      do while (k < nact)
        c = wc(k); a = wa(k); dd = DR(c); done = .false.
        if (dd == 0) then
          STOP(wsrc(k)) = -int(c, i32) - 1; done = .true.
        else
          x = c + off(dd)
          !$omp atomic read seq_cst
          cur = indeg(x)
          if (cur == F81) then
            a = a + acc(x)
            acc(x) = a
            !$omp atomic write
            indeg(x) = F80
          else
            !$omp atomic update
            acc(x) = acc(x) + a
            !$omp atomic capture seq_cst
            indeg(x) = indeg(x) - 1_i8
            u = indeg(x)
            !$omp end atomic
            if (u /= F80) then
              STOP(wsrc(k)) = int(x, i32); done = .true.
            else
              !$omp atomic read
              a = acc(x)
            end if
          end if
          if (.not. done) then
            SEG(x) = wsrc(k); wc(k) = x; wa(k) = a
            st = st + 1
            wst(k) = wst(k) + 1
            if (wst(k) >= wlim(k)) then
              call park_push(park, x, a, wsrc(k)); done = .true.
            end if
          end if
        end if
        if (done) then
          do while (nx < e)
            !$omp atomic read
            dg = indeg(nx)
            if (dg == 0_i8 .and. DR(nx) /= NODIR) exit
            nx = nx + 1
          end do
          if (nx >= e) then
            nact = nact - 1
            wc(k) = wc(nact); wa(k) = wa(nact); wsrc(k) = wsrc(nact); wst(k) = wst(nact); wlim(k) = wlim(nact)
            cycle
          end if
          wc(k) = nx; wa(k) = 1; wsrc(k) = int(nx, i32); SEG(nx) = int(nx, i32)
          wst(k) = 0; wlim(k) = merge(WALK_DEFER_LOW, WALK_DEFER, st > budget)
          nx = nx + 1
        end if
        k = k + 1
      end do
    end do
  end subroutine walk_src

  subroutine walk_list(w, i0, i1, V, M8, DR, indeg, acc, SEG, STOP, off)
    type(wcont), intent(in) :: w(*)
    integer(i64), intent(in) :: i0, i1, V, M8
    integer(i8), intent(in) :: DR(-M8 - 1 : V + M8)
    integer(i8), intent(inout) :: indeg(0 : V - 1)
    integer(i32), intent(inout) :: acc(0 : V - 1), SEG(0 : V - 1), STOP(0 : V - 1)
    integer(i64), intent(in) :: off(0:8)
    integer(i64) :: wc(0:MW - 1), nx, c, x
    integer(i32) :: wa(0:MW - 1), wsrc(0:MW - 1), a
    integer(i8) :: cur, u
    integer :: nact, k, dd
    logical :: done

    nx = i0
    nact = 0
    do while (nact < MW .and. nx < i1)
      nx = nx + 1
      wc(nact) = w(nx)%c; wa(nact) = w(nx)%a; wsrc(nact) = w(nx)%s
      nact = nact + 1
    end do
    do while (nact > 0)
      k = 0
      do while (k < nact)
        c = wc(k); a = wa(k); dd = DR(c); done = .false.
        if (dd == 0) then
          STOP(wsrc(k)) = -int(c, i32) - 1; done = .true.
        else
          x = c + off(dd)
          !$omp atomic read seq_cst
          cur = indeg(x)
          if (cur == F81) then
            a = a + acc(x)
            acc(x) = a
            !$omp atomic write
            indeg(x) = F80
          else
            !$omp atomic update
            acc(x) = acc(x) + a
            !$omp atomic capture seq_cst
            indeg(x) = indeg(x) - 1_i8
            u = indeg(x)
            !$omp end atomic
            if (u /= F80) then
              STOP(wsrc(k)) = int(x, i32); done = .true.
            else
              !$omp atomic read
              a = acc(x)
            end if
          end if
          if (.not. done) then
            SEG(x) = wsrc(k); wc(k) = x; wa(k) = a
          end if
        end if
        if (done) then
          if (nx >= i1) then
            nact = nact - 1
            wc(k) = wc(nact); wa(k) = wa(nact); wsrc(k) = wsrc(nact)
            cycle
          end if
          nx = nx + 1
          wc(k) = w(nx)%c; wa(k) = w(nx)%a; wsrc(k) = w(nx)%s
        end if
        k = k + 1
      end do
    end do
  end subroutine walk_list

  subroutine chain_phase2(np, pw, V, M8, DR, indeg, acc, SEG, STOP, off, T)
    integer(i64), intent(in) :: np, V, M8
    type(wcont), intent(in) :: pw(np)
    integer(i8), intent(in) :: DR(-M8 - 1 : V + M8)
    integer(i8), intent(inout) :: indeg(0 : V - 1)
    integer(i32), intent(inout) :: acc(0 : V - 1), SEG(0 : V - 1), STOP(0 : V - 1)
    integer(i64), intent(in) :: off(0:8)
    integer, intent(in) :: T
    type(wlist), pointer, contiguous :: rl(:)
    type(ruler), pointer, contiguous :: rr(:), rt(:)
    type(ruler), target :: one
    type(c_ptr) :: rlp, rrp
    integer(i64) :: nr, lo, hi, r, x, y, S, L, k, w, c, i, ri, q, i2
    integer(i32) :: a, src, vv
    integer(i8) :: u
    integer :: tid, nt, dd, tt, TT1

    TT1 = max(T, 1)
    rlp = c_realloc(c_null_ptr, int(TT1, c_size_t) * 64_c_size_t)
    call c_f_pointer(rlp, rl, [TT1])
    do tt = 1, TT1
      rl(tt)%p = c_null_ptr; rl(tt)%n = 0; rl(tt)%cap = 0
    end do
    !$omp parallel num_threads(T) private(tid, nt, lo, hi, r, x, y, S, L, dd, one)
    tid = omp_get_thread_num(); nt = omp_get_num_threads()
    lo = V * tid / nt; hi = V * (tid + 1) / nt
    do r = lo, hi - 1
      if (.not. rhash(r)) cycle
      if (indeg(r) /= F81) cycle
      x = r; S = acc(x); L = 1
      do
        dd = DR(x)
        if (dd == 0) exit
        y = x + off(dd)
        if (indeg(y) /= F81) exit
        if (rhash(y)) exit
        x = y; S = S + acc(y); L = L + 1
      end do
      one%cell = r; one%last = x; one%sum = S; one%len = L; one%a_in = 0; one%src = 0
      call wl_push(rl(tid + 1), c_loc(one), 40_i64)
    end do
    !$omp end parallel
    nr = 0
    do tt = 1, TT1
      nr = nr + rl(tt)%n
    end do
    rrp = c_realloc(c_null_ptr, int(max(nr, 1_i64) * 40, c_size_t))
    call c_f_pointer(rrp, rr, [max(nr, 1_i64)])
    k = 0
    do tt = 1, TT1
      if (rl(tt)%n > 0) then
        call c_f_pointer(rl(tt)%p, rt, [rl(tt)%n])
        do i2 = 1, rl(tt)%n
          k = k + 1
          rr(k) = rt(i2)
        end do
      end if
      call c_free(rl(tt)%p)
    end do
    call c_free(rlp)
    do w = 1, np
      c = pw(w)%c; a = pw(w)%a; src = pw(w)%s
      do
        dd = DR(c)
        if (dd == 0) then
          STOP(src) = -int(c, i32) - 1; exit
        end if
        y = c + off(dd)
        u = indeg(y)
        if (u == F81) then
          ri = 0
          if (rhash(y)) ri = rfind(y)
          if (ri > 0) then
            rr(ri)%a_in = a; rr(ri)%src = src
            a = int(a + rr(ri)%sum, i32); c = rr(ri)%last
            cycle
          end if
          a = a + acc(y); acc(y) = a; indeg(y) = F80; SEG(y) = src; c = y
          cycle
        end if
        acc(y) = acc(y) + a
        u = u - 1_i8
        indeg(y) = u
        if (u /= F80) then
          STOP(src) = int(y, i32); exit
        end if
        a = acc(y); SEG(y) = src; c = y
      end do
    end do
    !$omp parallel do schedule(dynamic, 16) num_threads(T) private(x, vv, q)
    do i = 1, nr
      x = rr(i)%cell; vv = rr(i)%a_in
      do q = 0, rr(i)%len - 1
        vv = vv + acc(x); acc(x) = vv; indeg(x) = F80; SEG(x) = rr(i)%src
        if (q + 1 < rr(i)%len) x = x + off(DR(x))
      end do
    end do
    !$omp end parallel do
    call c_free(rrp)

  contains

    integer(i64) function rfind(yy)
      integer(i64), intent(in) :: yy
      integer(i64) :: l0, h0, md
      l0 = 1; h0 = nr; rfind = 0
      do while (l0 <= h0)
        md = (l0 + h0) / 2
        if (rr(md)%cell == yy) then
          rfind = md; return
        else if (rr(md)%cell < yy) then
          l0 = md + 1
        else
          h0 = md - 1
        end if
      end do
    end function rfind

  end subroutine chain_phase2

  subroutine ftn_acc(n, m, DR, acc, indeg, SEG, STOP, T) bind(C, name='ftn_acc')
    integer(c_int), value :: n, m, T
    integer(i8), intent(in) :: DR(-int(m, i64) - 1 : int(n, i64) * m + m)
    integer(i32), intent(inout) :: acc(0 : int(n, i64) * m - 1)
    integer(i8), intent(inout) :: indeg(0 : int(n, i64) * m - 1)
    integer(i32), intent(inout) :: SEG(0 : int(n, i64) * m - 1), STOP(0 : int(n, i64) * m - 1)
    integer(i64) :: V, M8, off(0:8), NWB, wbudget, it, b, e, c, st, np, q, i2
    integer :: i, k, tmax, me, tt
    type(wlist), pointer, contiguous :: pk(:)
    type(wcont), pointer, contiguous :: pw(:), pt(:)
    type(c_ptr) :: pkp, pwp

    M8 = m; V = int(n, i64) * M8
    off = [0_i64, -M8, -M8 + 1, 1_i64, M8 + 1, M8, M8 - 1, -1_i64, -M8 - 1]
    !$omp parallel do schedule(static) private(b, c, k)
    do i = 0, n - 1
      b = int(i, i64) * M8
      do c = b, b + M8 - 1
        k = 0
        if (DR(c - M8) == 5) k = k + 1
        if (DR(c - M8 + 1) == 6) k = k + 1
        if (DR(c + 1) == 7) k = k + 1
        if (DR(c + M8 + 1) == 8) k = k + 1
        if (DR(c + M8) == 1) k = k + 1
        if (DR(c + M8 - 1) == 2) k = k + 1
        if (DR(c - 1) == 3) k = k + 1
        if (DR(c - M8 - 1) == 4) k = k + 1
        indeg(c) = merge(int(k - 128, i8), 0_i8, k > 0)
        acc(c) = merge(-1_i32, 1_i32, DR(c) == NODIR)
      end do
    end do
    !$omp end parallel do

    tmax = max(omp_get_max_threads(), 1)
    pkp = c_realloc(c_null_ptr, int(tmax, c_size_t) * 64_c_size_t)
    call c_f_pointer(pkp, pk, [tmax])
    do tt = 1, tmax
      pk(tt)%p = c_null_ptr; pk(tt)%n = 0; pk(tt)%cap = 0
    end do
    NWB = (V + WB - 1) / WB
    wbudget = int(1.0d0 * real(V, c_double) / real(max(T, 1), c_double), i64)
    !$omp parallel private(me, st, it, b, e)
    me = omp_get_thread_num() + 1; st = 0
    !$omp do schedule(static)
    do it = 0, NWB - 1
      b = it * WB; e = min(b + WB, V)
      call walk_src(b, e, V, M8, DR, indeg, acc, SEG, STOP, off, pk(me), st, wbudget)
    end do
    !$omp end do
    !$omp end parallel

    np = 0
    do tt = 1, tmax
      np = np + pk(tt)%n
    end do
    if (np > 0) then
      pwp = c_realloc(c_null_ptr, int(np * 16, c_size_t))
      call c_f_pointer(pwp, pw, [np])
      q = 0
      do tt = 1, tmax
        if (pk(tt)%n > 0) then
          call c_f_pointer(pk(tt)%p, pt, [pk(tt)%n])
          do i2 = 1, pk(tt)%n
            pw(q + i2) = pt(i2)
          end do
          q = q + pk(tt)%n
        end if
      end do
      if (np <= CR_MAXP .and. T >= 2) then
        call chain_phase2(np, pw, V, M8, DR, indeg, acc, SEG, STOP, off, T)
      else
        !$omp parallel do schedule(dynamic, 1) private(b, e)
        do it = 0, (np + MW - 1) / MW - 1
          b = it * MW; e = min(b + MW, np)
          call walk_list(pw, b, e, V, M8, DR, indeg, acc, SEG, STOP, off)
        end do
        !$omp end parallel do
      end if
      call c_free(pwp)
    end if
    do tt = 1, tmax
      call c_free(pk(tt)%p)
    end do
    call c_free(pkp)
  end subroutine ftn_acc

  subroutine ftn_ws(n, m, DR, indeg, acc, SEG, STOP, T) bind(C, name='ftn_ws')
    integer(c_int), value :: n, m, T
    integer(i8), intent(in) :: DR(-int(m, i64) - 1 : int(n, i64) * m + m)
    integer(i8), intent(inout) :: indeg(0 : int(n, i64) * m - 1)
    integer(i32), intent(inout) :: acc(0 : int(n, i64) * m - 1), SEG(0 : int(n, i64) * m - 1), &
                                   STOP(0 : int(n, i64) * m - 1)
    integer(i64) :: V, NRB, it, b, e, s, q, c, CC, k, lo, hi, cnt
    integer(i32) :: vq, r, cur, lab
    integer(i64), pointer, contiguous :: fc(:)
    type(c_ptr) :: fcp

    V = int(n, i64) * m
    NRB = (V + RB - 1) / RB
    !$omp parallel do schedule(static) private(b, e, s, q, vq, r)
    do it = 0, NRB - 1
      b = it * RB; e = min(b + RB, V)
      do s = b, e - 1
        if (DR(s) == 0) acc(s) = huge(0_i32)
        if (DR(s) == NODIR) cycle
        if (SEG(s) /= s) cycle
        !$omp atomic read
        vq = STOP(s)
        if (vq < 0) cycle
        q = s
        do
          !$omp atomic read
          vq = STOP(q)
          if (vq < 0) then
            r = -vq - 1; exit
          end if
          q = SEG(vq)
        end do
        q = s
        do
          !$omp atomic read
          vq = STOP(q)
          if (vq < 0) exit
          !$omp atomic write
          STOP(q) = -r - 1
          q = SEG(vq)
        end do
      end do
    end do
    !$omp end parallel do
    !$omp parallel do schedule(static) private(r, cur)
    do c = 0, V - 1
      if (DR(c) == NODIR) then
        SEG(c) = -1; cycle
      end if
      r = -STOP(SEG(c)) - 1
      SEG(c) = r
      !$omp atomic read
      cur = acc(r)
      if (c < cur) then
        !$omp atomic update
        acc(r) = min(acc(r), int(c, i32))
      end if
    end do
    !$omp end parallel do
    CC = 4_i64 * T
    if (V < 64_i64 * T) CC = 1
    fcp = c_realloc(c_null_ptr, int((CC + 1) * 8, c_size_t))
    call c_f_pointer(fcp, fc, [CC + 1])
    fc(1) = 0
    !$omp parallel do schedule(static)
    do c = 0, V - 1
      if (DR(c) == 0) indeg(acc(c)) = 1_i8
    end do
    !$omp end parallel do
    !$omp parallel do schedule(static) private(lo, hi, cnt, c)
    do k = 0, CC - 1
      lo = V * k / CC; hi = V * (k + 1) / CC
      cnt = 0
      do c = lo, hi - 1
        if (indeg(c) == 1_i8) cnt = cnt + 1
      end do
      fc(k + 2) = cnt
    end do
    !$omp end parallel do
    do k = 2, CC + 1
      fc(k) = fc(k) + fc(k - 1)
    end do
    !$omp parallel do schedule(static) private(lo, hi, lab, c)
    do k = 0, CC - 1
      lo = V * k / CC; hi = V * (k + 1) / CC
      lab = 100 + int(fc(k + 1), i32)
      do c = lo, hi - 1
        if (indeg(c) == 1_i8) then
          lab = lab + 1
          acc(SEG(c)) = lab
        end if
      end do
    end do
    !$omp end parallel do
    call c_free(fcp)
  end subroutine ftn_ws

  subroutine put_u32(q, p, v0)
    integer(i8), intent(inout) :: q(0:*)
    integer(i64), intent(inout) :: p
    integer(i64), intent(in) :: v0
    integer(i64) :: v, nd, j, r
    v = v0
    if (v < 10) then
      q(p) = int(48 + v, i8); p = p + 1; return
    end if
    if (v < 100) then
      q(p) = DIG2(2 * v); q(p + 1) = DIG2(2 * v + 1); p = p + 2; return
    end if
    if (v < 1000) then
      nd = 3
    else if (v < 10000) then
      nd = 4
    else if (v < 100000) then
      nd = 5
    else if (v < 1000000) then
      nd = 6
    else if (v < 10000000) then
      nd = 7
    else if (v < 100000000) then
      nd = 8
    else if (v < 1000000000) then
      nd = 9
    else
      nd = 10
    end if
    j = p + nd
    do while (v >= 100)
      r = mod(v, 100_i64); v = v / 100
      j = j - 2
      q(j) = DIG2(2 * r); q(j + 1) = DIG2(2 * r + 1)
    end do
    if (v >= 10) then
      q(j - 2) = DIG2(2 * v); q(j - 1) = DIG2(2 * v + 1)
    else
      q(j - 1) = int(48 + v, i8)
    end if
    p = p + nd
  end subroutine put_u32

  integer(c_int64_t) function ftn_fmt_dir(Drow, m, nrows, q) bind(C, name='ftn_fmt_dir')
    integer(c_int64_t), value :: m, nrows
    integer(i8), intent(in) :: Drow(0 : m * nrows - 1)
    integer(i8), intent(inout) :: q(0:*)
    integer(i64) :: p, i, o, j, k
    integer(i8) :: d
    logical :: neg
    p = 0
    do i = 0, nrows - 1
      o = i * m
      j = 0
      do while (j + 16 <= m)
        neg = .false.
        do k = 0, 15
          neg = neg .or. (Drow(o + j + k) < 0)
        end do
        if (.not. neg) then
          do k = 0, 15
            q(p + 2 * k) = 48_i8 + Drow(o + j + k)
            q(p + 2 * k + 1) = 32_i8
          end do
          p = p + 32
        else
          do k = 0, 15
            d = Drow(o + j + k)
            if (d >= 0) then
              q(p) = 48_i8 + d; q(p + 1) = 32_i8; p = p + 2
            else
              q(p) = 45_i8; q(p + 1) = 57_i8; q(p + 2) = 32_i8; p = p + 3
            end if
          end do
        end if
        j = j + 16
      end do
      do while (j < m)
        d = Drow(o + j)
        if (d >= 0) then
          q(p) = 48_i8 + d; q(p + 1) = 32_i8; p = p + 2
        else
          q(p) = 45_i8; q(p + 1) = 57_i8; q(p + 2) = 32_i8; p = p + 3
        end if
        j = j + 1
      end do
      q(p) = 10_i8; p = p + 1
    end do
    ftn_fmt_dir = p
  end function ftn_fmt_dir

  integer(c_int64_t) function ftn_fmt_acc(A, m, nrows, q) bind(C, name='ftn_fmt_acc')
    integer(c_int64_t), value :: m, nrows
    integer(i32), intent(in) :: A(0 : m * nrows - 1)
    integer(i8), intent(inout) :: q(0:*)
    integer(i64) :: p, i, o, j, v
    p = 0
    do i = 0, nrows - 1
      o = i * m
      do j = 0, m - 1
        v = A(o + j)
        if (v < 0) then
          q(p) = 45_i8; p = p + 1; v = -v
        end if
        call put_u32(q, p, v)
        q(p) = 32_i8; p = p + 1
      end do
      q(p) = 10_i8; p = p + 1
    end do
    ftn_fmt_acc = p
  end function ftn_fmt_acc

  integer(c_int64_t) function ftn_fmt_lab(R, lab, m, nrows, q) bind(C, name='ftn_fmt_lab')
    integer(c_int64_t), value :: m, nrows
    integer(i32), intent(in) :: R(0 : m * nrows - 1)
    integer(i32), intent(in) :: lab(0:*)
    integer(i8), intent(inout) :: q(0:*)
    integer(i64) :: p, i, o, j, lp
    integer(i32) :: v, lr
    integer(i8) :: lbuf(0:15)
    p = 0
    lr = -2; lp = 0; lbuf = 0
    do i = 0, nrows - 1
      o = i * m
      do j = 0, m - 1
        v = R(o + j)
        if (v < 0) then
          q(p) = 45_i8; q(p + 1) = 49_i8; q(p + 2) = 32_i8; p = p + 3
          cycle
        end if
        if (v /= lr) then
          lr = v; lp = 0
          call put_u32(lbuf, lp, int(lab(v), i64))
          lbuf(lp) = 32_i8
        end if
        q(p : p + 15) = lbuf(0:15)
        p = p + lp + 1
      end do
      q(p) = 10_i8; p = p + 1
    end do
    ftn_fmt_lab = p
  end function ftn_fmt_lab

end module dtm_core
