// Problem A -- Terrain Flow and Watersheds -- optimised OpenMP version (round 8, "h8": h7w + chain ranking, static libraries).
// Output is byte-identical to the reference dtm.cpp: same tie order, labels and "%g" formatting.
// C++11, GCC 9.4 (judge compiler) warning-free with -Wall -Wextra. Build: make all.
// Run: ./A (clears the OpenMP environment, then exec ./dtm; the program picks its team size from
// the grid size and the CPU mask, see T_AUTO). Nothing is written to stderr.
// Measurements: research_notes/Strategies Marathon parallele 2026 A B C/A_experiments.md (Q7-Q11)
//
//  0. locality  one static row band per thread: the band's elevations are parsed, its
//             directions/indegrees computed, its walks started and its basin roots resolved
//             by the same thread, so pages are first-touched (and stay) on that thread's
//             NUMA node and walks mostly stay in its caches (round 3: 16000^2 0.44 -> 0.31 s).
//  1. input   stdin mmap'ed when it is a regular file (read() fallback for pipes). Header
//             parsed sequentially; elevations parsed in ONE pass per band: C = 4T chunks
//             cut at blanks, each parsed into band-local staging, prefix sum of the token
//             counts, then copied to its final index (the text is read once);
//             fio::parse_float (Clinger fast path: mantissa
//             < 2^24, |e10| <= 10 => one exact float op; else strtof) == strtof == cin >> float.
//  2. output  the writer thread is created before the first OpenMP region; it writes row
//             blocks in output order while the team formats/computes; each written buffer
//             goes back to the thread that formatted it and is reused first (cache-hot).
//             fio::put_g6 == printf("%g") (all 2^32 floats checked on glibc 2.34/2.36).
//             Watershed labels: runs of equal roots reuse the formatted digits.
//  3. dir     reference neighbour order (left edge N,NE,E,SE,S; right edge S,SW,W,NW,N;
//             interior N..NW), strict '<', nodata skipped.
//  4. acc     O(V) (the reference's repeated sweeps are Theta(V^2) in the worst case):
//             indegree pulled from the 8 neighbours, one downstream walk per source, the
//             last contributor continues (atomic add + acq_rel decrement, no RMW for the
//             last one); 8 interleaved walkers per thread; walks longer than 256 steps are
//             parked and resumed in a second, dynamically balanced phase.
//  5. ws      label = 100 + rank of the basin's first row-major cell. SEG[c] = source of the
//             walk that finalised c, STOP[s] = merge cell or sink of that walk; roots by
//             memoised chasing over sources (per band); one pass gives every cell's root and
//             the first-cell atomic min; first cells flagged from the sinks, prefix-sum rank.
//  6. memory  big arrays and output buffers >= 4 MB: 2 MB-aligned anonymous maps with
//             MADV_HUGEPAGE (2 large row blocks per section per thread); everything is
//             released with parallel MADV_DONTNEED slices before exit (serial kernel
//             teardown of 4 KB pages cost 0.3 s).
// Indices are int (like the reference: V < 2^31); sizes and offsets 64-bit.
// Options (measured, see notes): TPOOL, BPT, SIMD_COUNT, FMTD_SIMD, NUMA_STATIC, RES_STATIC, FMT_STATIC, LAB_CACHE, WS3,
//   WS_HALVE2, WALK_BLOCK, WALK_DEFER, RES_BLOCK, MW, THP_ADVISE, FASTREL, PARSE_FULL,
//   IN_PREAD, IN_MMAP, OUT_ASYNC, OUT_POOL, OUT_HUGE, OUT_LF, OUT_MMAP (rejected),
//   OUT_NOHUGE (test only), PROF=1 (timings, stderr).
#include <stdint.h>
#include <stdio.h>
#if defined(__SSE2__)
#include <emmintrin.h>
#endif
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <stdint.h>
#include <vector>
#include <thread>
#include <chrono>
#include <sys/uio.h>
#include <mutex>
#include <condition_variable>
#ifdef _OPENMP
#include <omp.h>
#endif
#include "fastio.h"

#ifndef PROF
#define PROF 0
#endif
#ifndef WALK_CHUNK
#define WALK_CHUNK 1  // blocks per dynamic grab in the walk loop (scheduler contention at 100+ threads)
#endif
#ifndef RES_BLOCK
#define RES_BLOCK 16384 // cells per block in the root-resolution loop (0: = WALK_BLOCK)
#endif
#ifndef WALK_DEFER
#define WALK_DEFER 256 // park walks after this many steps, resume them in a balanced 2nd phase (0: off)
#endif
#ifndef IN_PREAD
#define IN_PREAD 0    // 1: regular-file stdin read by parallel pread() into a THP buffer
#endif
#ifndef IN_MMAP
#define IN_MMAP 1
#endif
#ifndef OUT_ASYNC
#define OUT_ASYNC 1
#endif
#ifndef WALK_BLOCK
#define WALK_BLOCK 4096
#endif
#ifndef WALK_PERM
#define WALK_PERM 1
#endif
#ifndef MW
#define MW 8
#endif
#ifndef OUT_MMAP
#define OUT_MMAP 0
#endif
#ifndef OUT_POOL
#define OUT_POOL 1
#endif
#ifndef THP_ADVISE
#define THP_ADVISE 1  // madvise(MADV_HUGEPAGE) on every big anonymous region (THP "madvise" judges)
#endif
#ifndef T_AUTO
#define T_AUTO 1      // OMP_NUM_THREADS unset: T = min(work rule, cap, max(3c/4, c-16)) for c CPUs in
#endif                // the mask; cap 64, or 112 from T_BIG_CELLS; env DTM_TMAX: cap (0 = T = c)
#ifndef T_MAX
#define T_MAX 112     // team cap for large inputs (V >= T_BIG_CELLS)
#endif
#ifndef T_MID
#define T_MID 64      // team cap otherwise ("never more than ~64 unless the input is large")
#endif
#ifndef T_BIG_CELLS
#define T_BIG_CELLS 12000000L
#endif
#ifndef T_CPT
#define T_CPT 125000L // work rule: at most ceil(V / T_CPT) threads (0 = off)
#endif
#ifndef T_SQRT_K
#define T_SQRT_K 16   // work rule: T = max(round(T_SQRT_K * sqrt(V / 1e6)), ceil(V / T_CPT)) (R27)
#endif
#ifndef CHAIN_RANK
#define CHAIN_RANK 1  // phase 2 with <= CR_MAXP parked walks: ruling-set ranking of the long chains
#endif
#ifndef CR_MAXP
#define CR_MAXP 2
#endif
#ifndef CR_SHIFT
#define CR_SHIFT 26   // ruler = pending chain cell whose 32-bit hash has its top 32-CR_SHIFT bits zero (1/64)
#endif
#ifndef NB_CELLS
#define NB_CELLS 16384L   // at most ceil(V / NB_CELLS) output row blocks per section (0 = off)
#endif
#ifndef BIG_MIN
#define BIG_MIN ((size_t)4 << 20)   // smaller arrays: page-rounded maps, no 2 MB rounding/THP advice
#endif
#ifndef REL_MIN
#define REL_MIN ((size_t)0)  // parallel release below this many mapped bytes skipped; 0 = always release
                            // (R30: also faster than the exit teardown on small grids, snake 450^2
                            // 5.83 -> 5.51 ms, nwplane 1000^2 17.33 -> 16.26 ms)
#endif
#ifndef FAST_EXIT
#define FAST_EXIT 0   // _exit(0) at the end (no static destructors / atexit handlers)
#endif
#ifndef OUT_HUGE
#define OUT_HUGE 1    // output buffers >= OUT_HUGE_MIN bytes: 2 MB-aligned THP-advised maps (big_alloc)
#endif
#ifndef OUT_HUGE_MIN
#define OUT_HUGE_MIN ((size_t)4 << 20)
#endif
#ifndef OUT_NOHUGE
#define OUT_NOHUGE 0  // TEST ONLY: MADV_NOHUGEPAGE on the other output buffers, so that a THP "always"
                      // host behaves like a THP "madvise" host for them (judge emulation)
#endif
#ifndef FASTREL
#define FASTREL 1     // no serial munmap/free on the critical path: parallel MADV_DONTNEED slices
#endif
#ifndef PARSE_FULL
#define PARSE_FULL 0  // 1: count/parse with all available CPUs (measured: no gain, slower at 8000^2)
#endif
#ifndef LAB_CACHE
#define LAB_CACHE 1   // watershed formatter reuses the previous label's digits (runs of equal labels)
#endif
#ifndef OUT_LF
#define OUT_LF 0      // 1: lock-free block hand-off to the writer (atomic flags, writev batches, rings)
#endif
#ifndef PARSE1
#define PARSE1 1      // single-pass parse into band-local staging + prefix sum + copy (no count pass)
#endif
#ifndef FMTD_SIMD
#define FMTD_SIMD 1   // SSE2 formatting of the direction grid (16 cells per step when no nodata)
#endif
#ifndef SIMD_COUNT
#define SIMD_COUNT 1  // SSE2 token counting (x86-64); scalar elsewhere
#endif
#ifndef TPOOL
#define TPOOL 1       // per-thread recycling of output buffers (blocks rewritten while cache-hot)
#endif
#ifndef BPT
#define BPT 2         // output row blocks per section per thread (16 -> 8 -> 4 -> 2: R17-R21; needs OUT_HUGE on THP "madvise" hosts)
#endif
#ifndef FMT_STATIC
#define FMT_STATIC 0  // 1: row blocks formatted on static bands (same threads as parse/walks)
#endif
#ifndef RES_STATIC
#define RES_STATIC 1  // with NUMA_STATIC: root resolution also on static bands
#endif
#ifndef WS_HALVE2
#define WS_HALVE2 0   // WS2 path: path halving instead of full compression
#endif
#ifndef NUMA_STATIC
#define NUMA_STATIC 1 // parse, phase-1 walks (and, with RES_STATIC, root resolution) on static row bands
#endif
#if NUMA_STATIC
#define SCHED_LOC schedule(static)
#else
#define SCHED_LOC schedule(dynamic, 1)
#endif
#ifndef WS_HALVE
#define WS_HALVE 1    // (WS3 path) root resolution by lock-free path halving (CAS, roots never overwritten)
#endif
#ifndef WS3
#define WS3 0         // 1: watershed from per-segment minima (measured slower: contended atomic min, Q9)
#endif
#ifndef WS2
#define WS2 1         // watershed: atomic-min fused with root pass, sink-only flagging,
#endif                // label gather done by the formatter (2 full passes fewer)

static double wtime() {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + 1e-9 * ts.tv_nsec;
}
static inline int nthreads(long V) {
    (void)V;
#ifdef _OPENMP
#if T_AUTO
    // omp_get_num_procs() = CPUs in the process affinity mask (libgomp: sched_getaffinity),
    // so a taskset / cpuset / one-socket VM limit is honoured; an explicit OMP_NUM_THREADS wins
    // A team that fills the mask spins at its barriers (libgomp default wait policy) and
    // starves the writer thread: nwplane 3000² on 64 CPUs took 0.04 s with 48 threads but
    // 0.09-0.22 s with 64 (A_experiments.md Q12), so some CPUs are left free.
    const char* e = getenv("OMP_NUM_THREADS");
    if (!e || !*e) {
        const int c = omp_get_num_procs();   // logical CPUs (SMT siblings included)
        int t = c - 16 > 3 * c / 4 ? c - 16 : 3 * c / 4, cap = T_MAX;
        const char* m = getenv("DTM_TMAX");
        bool all = false;
        if (m && *m) { const int v = atoi(m); if (v > 0) cap = v; else { t = c; cap = INT_MAX; all = true; } }
        else cap = V >= T_BIG_CELLS ? T_MAX : T_MID;
        if (t > cap) t = cap;
        // work rule: small inputs are dominated by per-thread fixed costs (team start-up,
        // barriers, one output block per thread); a few threads finish them sooner
        // the sqrt term is the better count below ~4M cells (snake 450^2: 7 threads), the
        // linear one above (16M cells: 112); A_experiments.md Q13
        if ((T_SQRT_K > 0 || T_CPT > 0) && !all) {
            const double ws = T_SQRT_K > 0 ? T_SQRT_K * sqrt((double)V / 1e6) : 0;
            long w = (long)(ws + 0.5);
            if (T_CPT > 0) { const long wl = (V + T_CPT - 1) / T_CPT; if (wl > w) w = wl; }
            if (w < 1) w = 1;
            if (w < t) t = (int)w;
        }
        omp_set_num_threads(t < 1 ? 1 : t);
    }
#endif
    return omp_get_max_threads();
#else
    return 1;
#endif
}
static inline void split(long n, int T, int k, long* lo, long* hi) { *lo = n * k / T; *hi = n * (k + 1) / T; }

static const signed char NODIR = -9;

static void write_all(const char* b, size_t len) {
    while (len) {
        ssize_t w = write(1, b, len);
        if (w < 0) { if (errno == EINTR) continue; perror("write"); exit(1); }
        b += w; len -= (size_t)w;
    }
}

// ------------------------------------------------------------------ big regions
// 2 MB-aligned anonymous mappings, THP-advised before first touch, released at the end by
// parallel MADV_DONTNEED slices (the kernel's exit teardown is single-threaded).
struct Region { char* p; size_t len; };
static std::vector<Region> g_regions, g_pool;   // compute arrays / output buffers
static std::mutex g_regmu;
static void* small_alloc(size_t bytes) {   // page-rounded map, no THP advice (small grids)
    const size_t pg = (size_t)sysconf(_SC_PAGESIZE);
    const size_t len = (bytes + pg - 1) / pg * pg;
    void* m = mmap(0, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (m == MAP_FAILED) { void* q = malloc(bytes); if (!q) { perror("alloc"); exit(1); } return q; }
    std::lock_guard<std::mutex> g(g_regmu);
    Region r = {(char*)m, len};
    g_regions.push_back(r);
    return m;
}
static void* big_alloc(size_t bytes, bool pool = false) {
    if (bytes < BIG_MIN && !pool) return small_alloc(bytes);   // small grid: no zeroed 2 MB pages
    const size_t A = (size_t)2 << 20;
    size_t len = (bytes + A - 1) / A * A;
    void* m = mmap(0, len + A, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (m == MAP_FAILED) { void* q = malloc(bytes); if (!q) { perror("alloc"); exit(1); } return q; }
    char* a = (char*)(((uintptr_t)m + A - 1) & ~(uintptr_t)(A - 1));
    size_t head = (size_t)(a - (char*)m), tail = A - head;
    if (head) munmap(m, head);
    if (tail) munmap(a + len, tail);
#if THP_ADVISE && defined(MADV_HUGEPAGE)
    madvise(a, len, MADV_HUGEPAGE);
#endif
    std::lock_guard<std::mutex> g(g_regmu);
    Region r = {a, len};
    (pool ? g_pool : g_regions).push_back(r);
    return a;
}
// output block buffers: plain page-rounded anonymous maps (no 2 MB rounding, no THP advice:
// 16T small blocks per section must not each fault in and zero a whole 2 MB huge page)
// OUT_HUGE: large block buffers (few blocks per thread) take the big_alloc path instead
static void* pool_alloc(size_t bytes) {
#if OUT_HUGE
    if (bytes >= (size_t)OUT_HUGE_MIN) return big_alloc(bytes, true);
#endif
    const size_t pg = (size_t)sysconf(_SC_PAGESIZE);
    size_t len = (bytes + pg - 1) / pg * pg;
    void* m = mmap(0, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (m == MAP_FAILED) { perror("mmap"); exit(1); }
#if OUT_NOHUGE && defined(MADV_NOHUGEPAGE)
    madvise(m, len, MADV_NOHUGEPAGE);
#endif
    std::lock_guard<std::mutex> g(g_regmu);
    Region r = {(char*)m, len};
    g_pool.push_back(r);
    return m;
}
// release regions (page-aligned) in parallel slices; file-backed private maps: drops PTEs
static inline void release_parallel(const std::vector<Region>& rs, int nth) {
    const size_t S = (size_t)32 << 20;
    std::vector<Region> sl;
    for (size_t i = 0; i < rs.size(); i++)
        for (size_t o = 0; o < rs[i].len; o += S) { Region r = {rs[i].p + o, rs[i].len - o < S ? rs[i].len - o : S}; sl.push_back(r); }
    if (nth < 1) nth = 1;
#pragma omp parallel for schedule(dynamic, 1) num_threads(nth)
    for (long i = 0; i < (long)sl.size(); i++) madvise(sl[(size_t)i].p, sl[(size_t)i].len, MADV_DONTNEED);
}

// ------------------------------------------------------------------ ordered output
// Blocks are appended in output order (slots reserved up-front); producers fill them
// in any order; the writer (thread or synchronous flush) emits them strictly in order.
#if OUT_LF && !OUT_ASYNC
#error "OUT_LF needs the writer thread (OUT_ASYNC=1)"
#endif
#if OUT_LF
// Lock-free block hand-off (OUT_LF): producers publish a block with one release store and
// only take the mutex when the writer is actually asleep; the writer spins briefly, then
// sleeps with a timeout; it writes every consecutive ready block with one writev() and
// returns each buffer to its formatter through a per-thread single-producer ring.
struct Out {
    struct Blk { const char* p; size_t len; char* tofree; size_t cap; int owner; unsigned char ready; };
    enum { RING = 64 };
    struct Ring { std::pair<char*, size_t> e[RING]; unsigned head, tail; char pad[56]; };
    std::vector<Blk> blk;
    size_t next_write;
    std::mutex mu;
    std::condition_variable cv;
    std::thread th;
    bool async;
    int wsleep;
    std::vector<std::pair<char*, size_t> > pool;     // overflow / wrong-size buffers (locked)
    std::vector<Ring> ring;                          // per formatting thread
    std::vector<std::vector<std::pair<char*, size_t> > > tpool;   // unused (interface parity)
    double t_wait, t_write, t_free;
    explicit Out(bool a) : next_write(0), async(a), wsleep(0), t_wait(0), t_write(0), t_free(0) {}
    size_t reserve(size_t k) { size_t b = blk.size(); Blk z = {0, 0, 0, 0, -1, 0}; blk.resize(b + k, z); return b; }
    void init_rings(int T) { Ring z = Ring(); ring.assign((size_t)(T > 0 ? T : 1), z); }
    char* get(size_t need, size_t* cap, int tid = -1) {
        if (tid >= 0 && (size_t)tid < ring.size()) {
            Ring& r = ring[(size_t)tid];
            for (;;) {
                const unsigned t = r.tail, h = __atomic_load_n(&r.head, __ATOMIC_ACQUIRE);
                if (t == h) break;
                std::pair<char*, size_t> e = r.e[t % RING];
                __atomic_store_n(&r.tail, t + 1, __ATOMIC_RELEASE);
                if (e.second >= need) { *cap = e.second; return e.first; }
                std::lock_guard<std::mutex> g(mu); pool.push_back(e);   // too small: park it
            }
        }
        {
            std::lock_guard<std::mutex> g(mu);
            for (size_t i = pool.size(); i-- > 0;)
                if (pool[i].second >= need) { char* b = pool[i].first; *cap = pool[i].second; pool[i] = pool.back(); pool.pop_back(); return b; }
        }
        *cap = need;
        return (char*)pool_alloc(need);
    }
    void ready(size_t i, const char* p, size_t len, char* tofree, size_t cap = 0, int owner = -1) {
        Blk& b = blk[i];
        b.p = p; b.len = len; b.tofree = tofree; b.cap = cap; b.owner = owner;
        __atomic_store_n(&b.ready, (unsigned char)1, __ATOMIC_SEQ_CST);
        if (__atomic_load_n(&wsleep, __ATOMIC_SEQ_CST)) { std::lock_guard<std::mutex> g(mu); cv.notify_one(); }
    }
    bool isready(size_t i) { return __atomic_load_n(&blk[i].ready, __ATOMIC_ACQUIRE) != 0; }
    void give_back(const Blk& b) {
        if (!b.tofree) return;
        if (!b.cap) { free(b.tofree); return; }
        if (b.owner >= 0 && (size_t)b.owner < ring.size()) {
            Ring& r = ring[(size_t)b.owner];
            const unsigned h = r.head, t = __atomic_load_n(&r.tail, __ATOMIC_ACQUIRE);
            if (h - t < (unsigned)RING) { r.e[h % RING] = std::make_pair(b.tofree, b.cap); __atomic_store_n(&r.head, h + 1, __ATOMIC_RELEASE); return; }
        }
        std::lock_guard<std::mutex> g(mu); pool.push_back(std::make_pair(b.tofree, b.cap));
    }
    void run(size_t total) {
        std::vector<struct iovec> iov(256);
        size_t i = 0;
        while (i < total) {
            double t0 = PROF ? wtime() : 0;
            if (!isready(i)) {
                for (int spin = 0; spin < 20000 && !isready(i); spin++) {
#if defined(__SSE2__)
                    _mm_pause();
#endif
                }
                if (!isready(i)) {
                    std::unique_lock<std::mutex> g(mu);
                    __atomic_store_n(&wsleep, 1, __ATOMIC_SEQ_CST);
                    while (!isready(i)) cv.wait_for(g, std::chrono::milliseconds(2));
                    __atomic_store_n(&wsleep, 0, __ATOMIC_SEQ_CST);
                }
            }
            size_t j = i, k = 0;
            while (j < total && k < iov.size() && isready(j)) { iov[k].iov_base = (void*)blk[j].p; iov[k].iov_len = blk[j].len; ++k; ++j; }
            double t1 = PROF ? wtime() : 0;
            size_t first = 0;   // writev with partial-write handling
            while (first < k) {
                ssize_t w = writev(1, &iov[first], (int)(k - first));
                if (w < 0) { if (errno == EINTR) continue; perror("write"); exit(1); }
                size_t left = (size_t)w;
                while (first < k && left >= iov[first].iov_len) { left -= iov[first].iov_len; ++first; }
                if (first < k && left) { iov[first].iov_base = (char*)iov[first].iov_base + left; iov[first].iov_len -= left; }
            }
            double t2 = PROF ? wtime() : 0;
            for (size_t q = i; q < j; q++) give_back(blk[q]);
            if (PROF) { double t3 = wtime(); t_wait += t1 - t0; t_write += t2 - t1; t_free += t3 - t2; }
            i = j;
        }
    }
};
#else
struct Out {
    struct Blk { const char* p; size_t len; char* tofree; size_t cap; int owner; bool ready; };
    std::vector<Blk> blk;
    size_t next_write;
    std::mutex mu;
    std::condition_variable cv;
    std::thread th;
    bool async;
    // OUT_POOL: the writer recycles written buffers instead of free()ing them (free of a
    // large block = munmap = TLB shoot-down IPIs to every CPU running a team thread,
    // paid on the single writer thread, i.e. on the critical path)
    std::vector<std::pair<char*, size_t> > pool;
    // TPOOL: written buffers go back to the thread that formatted them; its most recent
    // buffer is reused first, so small blocks are rewritten while still in its caches
    std::vector<std::vector<std::pair<char*, size_t> > > tpool;
    double t_wait, t_write, t_free;   // writer-side profile (PROF)
    explicit Out(bool a) : next_write(0), async(a), t_wait(0), t_write(0), t_free(0) {}
    size_t reserve(size_t k) { size_t b = blk.size(); Blk z = {0, 0, 0, 0, -1, false}; blk.resize(b + k, z); return b; }
    char* get(size_t need, size_t* cap, int tid = -1) {
        if (OUT_POOL) {
            std::lock_guard<std::mutex> g(mu);
            if (TPOOL && tid >= 0 && (size_t)tid < tpool.size()) {
                std::vector<std::pair<char*, size_t> >& tp = tpool[(size_t)tid];
                for (size_t i = tp.size(); i-- > 0;)
                    if (tp[i].second >= need) { char* b = tp[i].first; *cap = tp[i].second; tp.erase(tp.begin() + (long)i); return b; }
            }
            for (size_t i = pool.size(); i-- > 0;)
                if (pool[i].second >= need) { char* b = pool[i].first; *cap = pool[i].second; pool[i] = pool.back(); pool.pop_back(); return b; }
        }
        *cap = need;
        return (char*)(OUT_POOL ? pool_alloc(need) : malloc(need));
    }
    void ready(size_t i, const char* p, size_t len, char* tofree, size_t cap = 0, int owner = -1) {
        std::lock_guard<std::mutex> g(mu);
        blk[i].p = p; blk[i].len = len; blk[i].tofree = tofree; blk[i].cap = cap; blk[i].owner = owner; blk[i].ready = true;
        cv.notify_one();
    }
    void run(size_t total) {   // writer loop
        for (size_t i = 0; i < total; i++) {
            Blk b;
            double t0 = PROF ? wtime() : 0;
            {
                std::unique_lock<std::mutex> g(mu);
                while (!blk[i].ready) cv.wait(g);
                b = blk[i];
            }
            double t1 = PROF ? wtime() : 0;
            write_all(b.p, b.len);
            double t2 = PROF ? wtime() : 0;
            if (b.tofree) {
                if (OUT_POOL && b.cap) {
                    std::lock_guard<std::mutex> g(mu);
                    if (TPOOL && b.owner >= 0 && (size_t)b.owner < tpool.size()) tpool[(size_t)b.owner].push_back(std::make_pair(b.tofree, b.cap));
                    else pool.push_back(std::make_pair(b.tofree, b.cap));
                }
                else free(b.tofree);
            }
            if (PROF) { double t3 = wtime(); t_wait += t1 - t0; t_write += t2 - t1; t_free += t3 - t2; }
        }
    }
};
#endif


// number of positions q in [s, e) with q[0] > ' ' and q[-1] <= ' ' (token starts; s[-1] is
// readable). SSE2 (x86-64 baseline): 16 bytes per step, byte counters drained with SAD.
static inline long count_token_starts(const char* s, const char* e) {
    long c = 0;
    const char* q = s;
#if SIMD_COUNT && defined(__SSE2__)
    const __m128i sp = _mm_set1_epi8(' ');
    const __m128i zero = _mm_setzero_si128();
    while (e - q >= 16) {
        long iters = (e - q) / 16; if (iters > 255) iters = 255;
        __m128i acc = zero;
        for (long it = 0; it < iters; it++, q += 16) {
            const __m128i cur = _mm_loadu_si128((const __m128i*)q);
            const __m128i prv = _mm_loadu_si128((const __m128i*)(q - 1));
            const __m128i wsc = _mm_cmpeq_epi8(_mm_max_epu8(cur, sp), sp);   // cur <= ' '
            const __m128i wsp = _mm_cmpeq_epi8(_mm_max_epu8(prv, sp), sp);   // prev <= ' '
            acc = _mm_sub_epi8(acc, _mm_andnot_si128(wsc, wsp));              // +1 per start
        }
        const __m128i sad = _mm_sad_epu8(acc, zero);
        c += _mm_cvtsi128_si64(sad) + _mm_cvtsi128_si64(_mm_unpackhi_epi64(sad, sad));
    }
#endif
    for (; q < e; ++q) c += ((unsigned char)q[0] > ' ') & ((unsigned char)q[-1] <= ' ');
    return c;
}

// ------------------------------------------------------------------ accumulation walks
struct WCont { long c; int a; int src; int mn; }; // a parked walk: cell c final with value a, segment min mn
struct SrcScan {                                    // yields the sources of [nx, e)
    long nx, e; const unsigned char* indeg; const signed char* D; int* SEG;
    inline bool operator()(long& c, int& a, int& src, int& mn) {
        while (nx < e) {
            long s_ = nx++;
            if (__atomic_load_n(&indeg[s_], __ATOMIC_RELAXED) == 0 && D[s_] != NODIR) {
                c = s_; a = 1; src = (int)s_; mn = (int)s_; SEG[s_] = (int)s_; return true;
            }
        }
        return false;
    }
};
struct ContList {                                   // yields parked walks [i, e)
    const WCont* p; long i, e;
    inline bool operator()(long& c, int& a, int& src, int& mn) {
        if (i >= e) return false;
        c = p[i].c; a = p[i].a; src = p[i].src; mn = p[i].mn; ++i; return true;
    }
};
// Phase 2 when only a few walks were parked (e.g. one serpentine path of 100k+ cells): instead
// of one thread walking the whole path, the remaining "chain" cells (exactly one pending
// contribution, indeg == 0x81, so reachable only through their predecessor) are cut into
// segments at hash-chosen rulers; each segment's length, last cell and sum of acc are found in
// parallel; the parked walks then run sequentially, jumping a whole segment at a time (merge,
// stop and sink logic unchanged), and each segment is finally filled in parallel with the
// exact running sums acc[x] = v += acc[x], SEG[x] = source, indeg[x] = 0x80.
struct Ruler { long cell, last; long long sum; int a_in, src; long len; int assigned; };
static inline bool ruler_hash(long x) { return ((uint32_t)x * 2654435761u) >> CR_SHIFT == 0; }
static void chain_phase2(const std::vector<WCont>& all, const signed char* D, unsigned char* indeg, int* acc,
                         int* SEG, int* STOP, const long* off, long V, int T) {
    double q0 = PROF ? wtime() : 0, q2 = 0, q3 = 0;
    std::vector<std::vector<Ruler> > rl((size_t)(T > 0 ? T : 1));
#pragma omp parallel num_threads(T)
    {   // rulers of this band, and their segments (a segment ends before the next hashed
        // pending cell, so no thread needs the other bands' rulers)
        const int t = omp_get_thread_num(), nt = omp_get_num_threads();
        const long lo = V * t / nt, hi = V * (t + 1) / nt;
        std::vector<Ruler>& v = rl[(size_t)t];
        for (long r = lo; r < hi; r++) {
            if (!ruler_hash(r) || indeg[r] != 0x81) continue;
            long x = r; long long S = acc[x]; long L = 1;
            for (;;) {
                const int d = D[x];
                if (d == 0) break;
                const long y = x + off[d];
                if (indeg[y] != 0x81 || ruler_hash(y)) break;   // chain end, or the next ruler
                x = y; S += acc[y]; L++;
            }
            Ruler q = {r, x, S, 0, 0, L, 0}; v.push_back(q);
        }
    }
    std::vector<Ruler> R;
    for (size_t t = 0; t < rl.size(); t++) R.insert(R.end(), rl[t].begin(), rl[t].end());
    const long NR = (long)R.size();
    auto is_r = [&](long y) -> long {   // index of ruler y, or -1 (rulers are fixed at this point)
        if (!ruler_hash(y)) return -1;
        long lo = 0, hi = NR;
        while (lo < hi) { const long md = (lo + hi) / 2; if (R[(size_t)md].cell < y) lo = md + 1; else hi = md; }
        return lo < NR && R[(size_t)lo].cell == y ? lo : -1;
    };
    if (PROF) q2 = wtime();
    for (size_t w = 0; w < all.size(); w++) {   // the parked walks, one after the other
        long c = all[w].c; int a = all[w].a; const int src = all[w].src;
        for (;;) {
            const int d = D[c];
            if (d == 0) { STOP[src] = -(int)c - 1; break; }
            const long y = c + off[d];
            const unsigned char u = indeg[y];
            if (u == 0x81) {
                const long ri = is_r(y);
                if (ri >= 0) { Ruler& r = R[(size_t)ri]; r.a_in = a; r.src = src; r.assigned = 1; a = (int)(a + r.sum); c = r.last; continue; }
                a += acc[y]; acc[y] = a; indeg[y] = 0x80; SEG[y] = src; c = y; continue;
            }
            acc[y] += a; indeg[y] = (unsigned char)(u - 1);
            if (u - 1 != 0x80) { STOP[src] = (int)y; break; }
            a = acc[y]; SEG[y] = src; c = y;
        }
    }
    if (PROF) q3 = wtime();
#pragma omp parallel for schedule(dynamic, 16) num_threads(T)
    for (long i = 0; i < NR; i++) {
        const Ruler& r = R[(size_t)i];
        long x = r.cell; int v = r.a_in;
        for (long k = 0; k < r.len; k++) {
            v += acc[x]; acc[x] = v; indeg[x] = 0x80; SEG[x] = r.src;
            if (k + 1 < r.len) x += off[D[x]];
        }
    }
    if (PROF) fprintf(stderr, "CR NR=%ld scanseg=%.6f seq=%.6f fill=%.6f\n", NR, q2 - q0, q3 - q2, wtime() - q3);
}

// MW walkers advanced round-robin: independent memory accesses overlap (MLP), and walkers
// from neighbouring sources share cache lines (e.g. parallel diagonals). At each cell the
// last contributor to arrive continues; others record where they merged (STOP) and stop.
template <class Next>
static inline void walk_run(Next& next, const signed char* D, unsigned char* indeg, int* acc, int* SEG,
                            int* STOP, const long* off, std::vector<WCont>* park, int kd, int* SMIN) {
    long wc[MW]; int wa[MW]; int wsrc[MW]; int wst[MW]; int wmn[MW];
    int nact = 0;
    for (;;) { if (nact == MW) break; if (!next(wc[nact], wa[nact], wsrc[nact], wmn[nact])) break; wst[nact] = 0; nact++; }
    while (nact > 0) {
        for (int k = 0; k < nact;) {
            const long c = wc[k];
            int a = wa[k];
            const int d = D[c];
            bool done = false;
            if (d == 0) { STOP[wsrc[k]] = -(int)c - 1; if (SMIN) SMIN[wsrc[k]] = wmn[k]; done = true; }
            else {
                const long x = c + off[d];
                unsigned char cur = __atomic_load_n(&indeg[x], __ATOMIC_ACQUIRE);
                if (cur == 0x81) {          // only/last contribution: no RMW needed
                    a += acc[x];
                    acc[x] = a;
                    __atomic_store_n(&indeg[x], (unsigned char)0x80, __ATOMIC_RELAXED);
                } else {
                    __atomic_fetch_add(&acc[x], a, __ATOMIC_RELAXED);
                    if (__atomic_sub_fetch(&indeg[x], 1, __ATOMIC_ACQ_REL) != 0x80) { STOP[wsrc[k]] = (int)x; if (SMIN) SMIN[wsrc[k]] = wmn[k]; done = true; }
                    else a = __atomic_load_n(&acc[x], __ATOMIC_RELAXED);
                }
                if (!done) {
                    SEG[x] = wsrc[k]; wc[k] = x; wa[k] = a;
                    if ((int)x < wmn[k]) wmn[k] = (int)x;
                    if (kd && ++wst[k] >= kd) { WCont w = {x, a, wsrc[k], wmn[k]}; park->push_back(w); done = true; }
                }
            }
            if (done) {
                if (!next(wc[k], wa[k], wsrc[k], wmn[k])) { --nact; wc[k] = wc[nact]; wa[k] = wa[nact]; wsrc[k] = wsrc[nact]; wst[k] = wst[nact]; wmn[k] = wmn[nact]; continue; }
                wst[k] = 0;
            }
            ++k;
        }
    }
}

#ifndef PROF_TEAM
#define PROF_TEAM 0   // PROF only: time team creation alone (one empty parallel region first)
#endif
static inline long long rt_ns() { struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); return ts.tv_sec * 1000000000LL + ts.tv_nsec; }
static inline long minflt() { struct rusage ru; getrusage(RUSAGE_SELF, &ru); return ru.ru_minflt; }

int main() {
    const long long rt0 = PROF ? rt_ns() : 0;   // PROF: absolute time of main entry (pre-main cost)
    double t0 = wtime(), tA = t0, tB;
    double ph[48]; const char* pn[48]; long pf[48]; int np = 0; long fA = PROF ? minflt() : 0, fB;
#define PM(name) do { if (PROF) { tB = wtime(); fB = minflt(); pn[np] = name; pf[np] = fB - fA; ph[np++] = tB - tA; tA = tB; fA = fB; } } while (0)
#define MARK() PM("?")
#if PROF && PROF_TEAM
    PM("start");
#pragma omp parallel
    { }
    PM("team");
#endif

    // ------------------------------------------------------------ read
    const char* buf = 0; size_t len = 0; char* owned = 0; void* mapped = 0; size_t maplen = 0;
    {
        struct stat st;
        bool reg = fstat(0, &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0;
#if IN_PREAD
        if (reg) {
            off_t cur = lseek(0, 0, SEEK_CUR);
            if (cur >= 0 && cur < st.st_size) {
                const size_t L = (size_t)(st.st_size - cur), CH = (size_t)8 << 20;
                char* b = (char*)big_alloc(L + 64);
                const long nch = (long)((L + CH - 1) / CH);
                int ok = 1;
#pragma omp parallel for schedule(dynamic, 1) reduction(min : ok)
                for (long k = 0; k < nch; k++) {
                    size_t o = (size_t)k * CH, l = L - o < CH ? L - o : CH, done = 0;
                    while (done < l) {
                        ssize_t r = pread(0, b + o + done, l - done, cur + (off_t)(o + done));
                        if (r < 0 && errno == EINTR) continue;
                        if (r <= 0) { ok = 0; break; }
                        done += (size_t)r;
                    }
                }
                if (ok) { b[L] = '\0'; buf = b; len = L; }
            }
        }
#endif
#if IN_MMAP
        if (reg && !buf) {
            off_t cur = lseek(0, 0, SEEK_CUR);
            if (cur >= 0 && cur < st.st_size) {
                void* mp = mmap(0, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, 0, 0);
                if (mp != MAP_FAILED) {
                    const char* c = (const char*)mp;
                    if (fio::is_ws((unsigned char)c[st.st_size - 1])) {   // need a terminating blank
                        mapped = mp; maplen = (size_t)st.st_size; buf = c + cur; len = (size_t)(st.st_size - cur);
                    } else munmap(mp, (size_t)st.st_size);
                }
            }
        }
#endif
        if (!buf) {
            size_t cap = reg ? (size_t)st.st_size + 1 : (size_t)1 << 20, n = 0;
            owned = (char*)malloc(cap + 1);
            for (;;) {
                if (n == cap) { cap *= 2; owned = (char*)realloc(owned, cap + 1); }
                ssize_t r = read(0, owned + n, cap - n);
                if (r < 0) { if (errno == EINTR) continue; perror("read"); exit(1); }
                if (r == 0) break;
                n += (size_t)r;
            }
            owned[n] = '\0'; buf = owned; len = n;
        }
    }
    PM("read");
    const char* p = buf;
    const char* end = buf + len;
    long hv[5];
    for (int k = 0; k < 5; k++) {
        while (p < end && fio::is_ws((unsigned char)*p)) ++p;
        char* e; hv[k] = strtol(p, &e, 10); p = e;
    }
    const int n = (int)hv[0], m = (int)hv[1];
    float nv;
    while (p < end && fio::is_ws((unsigned char)*p)) ++p;
    p = fio::parse_float(p, &nv);
    const long V = (long)n * m;
    const long M = m;
    const int T = nthreads(V);   // after the header: the team size depends on the grid size
    PM("hdr0");
    // output plan + writer thread are set up before the first OpenMP region, so that the
    // writer inherits the process-wide CPU mask even when OMP_PROC_BIND pins the team
    // ------------------------------------------------------------ output plan
    // per section: header, [top ghost], NB row blocks, [bottom ghost]
    Out out(OUT_ASYNC != 0);
    long NB = n < (long)BPT * T ? n : (long)BPT * T;   // row blocks per section
    if (NB_CELLS > 0) { const long nb = (V + NB_CELLS - 1) / NB_CELLS; if (nb < NB) NB = nb < 1 ? 1 : nb; }
    if (TPOOL) out.tpool.resize((size_t)(T > 0 ? T : 1));
#if OUT_LF
    out.init_rings(T);
#endif
    std::vector<long> blo(NB + 1);
    for (long b = 0; b <= NB; b++) blo[b] = (long)((long long)n * b / NB);
    size_t secbase[4];
    for (int s = 0; s < 4; s++) secbase[s] = out.reserve(s == 0 ? 1 + NB : 3 + NB);
    const size_t total_blocks = out.blk.size();
    // OUT_MMAP: if stdout is a regular file (not O_APPEND), reopen it read-write through
    // /proc/self/fd/1, size it to an upper bound, map it and let all threads copy the
    // formatted blocks in parallel (parallel page faults instead of one write() stream);
    // the file is truncated to the exact size at the end. Any failure => write() path.
    char* omap = 0; size_t omap_len = 0, opos = 0; off_t obase = 0; int ofd = -1;
#if OUT_MMAP
    {
        struct stat so;
        int fl = fcntl(1, F_GETFL);
        off_t cur = lseek(1, 0, SEEK_CUR);
        if (fstat(1, &so) == 0 && S_ISREG(so.st_mode) && fl >= 0 && !(fl & O_APPEND) && cur >= 0 && cur % 65536 == 0) {
            int fd = open("/proc/self/fd/1", O_RDWR);
            if (fd >= 0) {
                size_t ub = 128 + (size_t)n * (13 * (size_t)M + 1) + 3 * (size_t)(n + 2) * (12 * (size_t)M + 1);
                if (ftruncate(fd, cur + (off_t)ub) == 0) {
                    void* mp = mmap(0, ub, PROT_READ | PROT_WRITE, MAP_SHARED, fd, cur);
                    if (mp != MAP_FAILED) { omap = (char*)mp; omap_len = ub; obase = cur; ofd = fd; }
                    else if (ftruncate(fd, cur) != 0) { /* ignore */ }
                }
                if (!omap) close(fd);
            }
        }
    }
    if (omap) out.async = false;
#endif
    if (out.async) out.th = std::thread(&Out::run, &out, total_blocks);
    static const char* hdr[4] = {"the terrain\n", "the directions\n", "flow accumulation \n", "watersheds\n"};
    for (int s = 0; s < 4; s++) out.ready(secbase[s], hdr[s], strlen(hdr[s]), 0);
    std::vector<char*> ghosts;
    for (int s = 1; s < 4; s++) {
        for (int w = 0; w < 2; w++) {
            const char* g = s == 1 ? (w ? "5 " : "1 ") : s == 2 ? "0 " : "-1 ";
            size_t gl = strlen(g);
            char* gb = (char*)malloc(gl * (size_t)M + 2);
            size_t L = 0;
            for (long j = 0; j < M; j++) { memcpy(gb + L, g, gl); L += gl; }
            gb[L++] = '\n';
            out.ready(secbase[s] + (w ? 2 + NB : 1), gb, L, gb);
        }
    }

    float* tp = (float*)big_alloc(sizeof(float) * (size_t)(V + 2 * M));
    PM("hdr");
    float* t = tp + M;
    {
        // C chunks cut at blanks; the loops below do not depend on the team size
        const int TP = PARSE_FULL ? (omp_get_num_procs() > T ? omp_get_num_procs() : T) : T;
        const int C = 4 * TP;
        const char* beg = p;
        std::vector<const char*> cut(C + 1);
        std::vector<long> cnt(C + 1, 0);
        cut[0] = beg; cut[C] = end;
        for (int k = 1; k < C; k++) {
            const char* b = beg + (end - beg) * k / C;
            if (b < cut[k - 1]) b = cut[k - 1];
            while (b < end && !fio::is_ws((unsigned char)*b)) ++b;
            cut[k] = b;
        }
#if PARSE1
        // single pass: each chunk is parsed into its own staging area (first-touched by the
        // thread that owns the band), then copied to its final index after a prefix sum;
        // the input text is read once instead of twice (count + parse)
        std::vector<size_t> soff(C + 1, 0);
        for (int k = 0; k < C; k++) soff[k + 1] = soff[k] + (size_t)((cut[k + 1] - cut[k]) / 2 + 2);
        float* stg = (float*)big_alloc(sizeof(float) * soff[C]);
        PM("cut");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {
            float* o = stg + soff[k];
            const long capk = (long)(soff[k + 1] - soff[k]);
            long nk = 0;
            const char* q = cut[k];
            const char* e = cut[k + 1];
            while (nk < capk) {   // well-formed input never reaches capk (>= 2 bytes per token)
                while (q < e && fio::is_ws((unsigned char)*q)) ++q;
                if (q >= e) break;
                q = fio::parse_float(q, &o[nk++]);
            }
            cnt[k + 1] = nk;
        }
        for (int k = 1; k <= C; k++) cnt[k] += cnt[k - 1];
        PM("parse");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {
            const long a = cnt[k], b = cnt[k + 1] < V ? cnt[k + 1] : V;
            if (a < b) memcpy(t + a, stg + soff[k], (size_t)(b - a) * sizeof(float));
        }
        PM("copy");
#else
        PM("cut");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {   // count tokens = blank->non-blank transitions
            cnt[k + 1] = count_token_starts(cut[k], cut[k + 1]);
        }
        for (int k = 1; k <= C; k++) cnt[k] += cnt[k - 1];
        PM("count");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {
            long idx = cnt[k];
            const char* q = cut[k];
            const char* e = cut[k + 1];
            while (idx < V) {
                while (q < e && fio::is_ws((unsigned char)*q)) ++q;
                if (q >= e) break;
                q = fio::parse_float(q, &t[idx++]);
            }
        }
        PM("parse");
#endif
        for (long i = cnt[C] < V ? cnt[C] : V; i < V; i++) t[i] = 0.0f;   // short input
    }
    std::vector<Region> late;   // released in parallel at the end (FASTREL)
    if (mapped) {
        if (FASTREL) { size_t pg = (size_t)sysconf(_SC_PAGESIZE); Region r = {(char*)mapped, (maplen + pg - 1) / pg * pg}; late.push_back(r); }
        else munmap(mapped, maplen);
    }
    if (owned) free(owned);
    for (long j = 0; j < M; j++) { tp[j] = nv; t[V + j] = nv; }
    PM("ghost");

    // format one section's row blocks in parallel (dynamic: blocks finish roughly in order)
    const int* gi = 0;
    const int* glab = 0;   // WS2: watershed labels gathered as glab[root]
    const int* gstop = 0; const int* gseg = 0;   // WS3: root(c) = -gstop[gseg[c]] - 1
    signed char* D = 0;
    auto format_section = [&](int sec) {
        const size_t wmax = sec == 0 ? 13 : sec == 1 ? 3 : 12;
        const size_t first = secbase[sec] + (sec == 0 ? 1 : 2);
#if FMT_STATIC
#pragma omp parallel for schedule(static)     // thread t formats its own row band (NUMA-local reads)
#else
#pragma omp parallel for schedule(dynamic, 1)
#endif
        for (long b = 0; b < NB; b++) {
            size_t bcap;
            const int me = omp_get_thread_num();
            char* bb = out.get((size_t)(blo[b + 1] - blo[b]) * (wmax * (size_t)M + 1) + 16, &bcap, me);
            char* q = bb;
            for (long i = blo[b]; i < blo[b + 1]; i++) {
                const long o = i * M;
                if (sec == 0) {
                    const float* r = t + o;
                    for (long j = 0; j < M; j++) { q = fio::put_g6(q, r[j]); *q++ = ' '; }
                } else if (sec == 1) {
                    const signed char* r = D + o;
                    long j = 0;
#if FMTD_SIMD && defined(__SSE2__)
                    // 16 directions at a time when none is nodata: "d " pairs by byte interleave
                    const __m128i z0 = _mm_set1_epi8('0'), spc = _mm_set1_epi8(' ');
                    for (; j + 16 <= M; j += 16) {
                        const __m128i v = _mm_loadu_si128((const __m128i*)(r + j));
                        if (_mm_movemask_epi8(v)) {                      // a nodata code (-9): these 16 scalar
                            for (int k = 0; k < 16; k++) {
                                int d = r[j + k];
                                if (d >= 0) { q[0] = (char)('0' + d); q[1] = ' '; q += 2; }
                                else { q[0] = '-'; q[1] = '9'; q[2] = ' '; q += 3; }
                            }
                            continue;
                        }
                        const __m128i c = _mm_add_epi8(v, z0);
                        _mm_storeu_si128((__m128i*)q, _mm_unpacklo_epi8(c, spc));
                        _mm_storeu_si128((__m128i*)(q + 16), _mm_unpackhi_epi8(c, spc));
                        q += 32;
                    }
#endif
                    for (; j < M; j++) {
                        int d = r[j];
                        if (d >= 0) { q[0] = (char)('0' + d); q[1] = ' '; q += 2; }
                        else { q[0] = '-'; q[1] = '9'; q[2] = ' '; q += 3; }
                    }
                } else {
                    const int* r = gi + o;
                    if (sec == 3 && gstop) {
                        const signed char* dr = D + o;
                        const int* sg = gseg + o;
#if LAB_CACHE
                        // basins are contiguous: neighbouring cells mostly share a segment, and
                        // segments of one basin share a label -> reuse the last formatted label
                        int lseg = -1; uint32_t llab = 0xffffffffu; char lbuf[16] = {0}; int llen = 0;
                        for (long j = 0; j < M; j++) {
                            if (dr[j] == NODIR) { q[0] = '-'; q[1] = '1'; q[2] = ' '; q += 3; continue; }
                            const int sj = sg[j];
                            if (sj != lseg) {
                                lseg = sj;
                                const uint32_t lab = (uint32_t)glab[-gstop[sj] - 1];
                                if (lab != llab) { llab = lab; llen = (int)(fio::put_u32(lbuf, lab) - lbuf); lbuf[llen] = ' '; }
                            }
                            memcpy(q, lbuf, 16); q += llen + 1;   // buffers have >= 12 bytes/cell of slack
                        }
#else
                        for (long j = 0; j < M; j++) {
                            if (dr[j] != NODIR) q = fio::put_u32(q, (uint32_t)glab[-gstop[sg[j]] - 1]);
                            else { q[0] = '-'; q[1] = '1'; q += 2; }
                            *q++ = ' ';
                        }
#endif
                    } else if (sec == 3 && glab) {
#if LAB_CACHE
                        int lr = -2; char lbuf[16] = {0}; int llen = 0;   // runs of the same root
                        for (long j = 0; j < M; j++) {
                            const int v = r[j];
                            if (v < 0) { q[0] = '-'; q[1] = '1'; q[2] = ' '; q += 3; continue; }
                            if (v != lr) { lr = v; llen = (int)(fio::put_u32(lbuf, (uint32_t)glab[v]) - lbuf); lbuf[llen] = ' '; }
                            memcpy(q, lbuf, 16); q += llen + 1;   // >= 12 bytes/cell of slack in the buffer
                        }
#else
                        for (long j = 0; j < M; j++) {
                            int v = r[j];
                            if (v >= 0) q = fio::put_u32(q, (uint32_t)glab[v]);
                            else { q[0] = '-'; q[1] = '1'; q += 2; }
                            *q++ = ' ';
                        }
#endif
                    } else
                    for (long j = 0; j < M; j++) {
                        int v = r[j];
                        q = v >= 0 ? fio::put_u32(q, (uint32_t)v) : fio::put_i32(q, v);
                        *q++ = ' ';
                    }
                }
                *q++ = '\n';
            }
            out.ready(first + (size_t)b, bb, (size_t)(q - bb), bb, bcap, me);
        }
    };
    // synchronous mode (OUT_ASYNC=0): flush finished sections in order after formatting
    auto flush_upto = [&](size_t upto) {
        for (; out.next_write < upto; out.next_write++) {
            Out::Blk& b = out.blk[out.next_write];
            write_all(b.p, b.len);
            if (b.tofree) free(b.tofree);
        }
    };
    (void)flush_upto;
    auto mmap_section = [&](int sec) {     // parallel copy of a finished section
        const size_t lo = secbase[sec], hi = sec == 3 ? total_blocks : secbase[sec + 1];
        std::vector<size_t> offs(hi - lo + 1);
        offs[0] = opos;
        for (size_t i = lo; i < hi; i++) offs[i - lo + 1] = offs[i - lo] + out.blk[i].len;
#pragma omp parallel for schedule(dynamic, 1)
        for (long i = (long)lo; i < (long)hi; i++) {
            Out::Blk& bk = out.blk[(size_t)i];
            memcpy(omap + offs[(size_t)i - lo], bk.p, bk.len);
            if (bk.tofree) free(bk.tofree);
        }
        opos = offs[hi - lo];
    };
    (void)mmap_section;
#define FORMAT(sec) do { format_section(sec); \
        if (omap) mmap_section(sec); \
        else if (!out.async) flush_upto((sec) == 3 ? total_blocks : secbase[(sec) + 1]); } while (0)

    PM("plan");
    FORMAT(0);
    PM("fmtT");

    // ------------------------------------------------------------ directions
    signed char* dpad = (signed char*)big_alloc((size_t)(V + 2 * M + 2));
    D = dpad + 1 + M;
    memset(dpad, NODIR, (size_t)(M + 1));
    memset(D + V, NODIR, (size_t)(M + 1));
#pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
        const float* r = t + (long)i * M;
        const float* up = r - M;
        const float* dn = r + M;
        signed char* dr = D + (long)i * M;
        {
            float v = r[0], mn = v; int code = 0;
            const float nb[5] = {up[0], up[1], r[1], dn[1], dn[0]};
            for (int k = 0; k < 5; k++) if (nb[k] != nv && nb[k] < mn) { mn = nb[k]; code = k + 1; }
            dr[0] = v != nv ? (signed char)code : NODIR;
        }
        for (int j = 1; j < m - 1; j++) {
            float v = r[j], mn = v; int code = 0;
#define STEPD(x, kk) { float xx = (x); bool c = (xx != nv) & (xx < mn); mn = c ? xx : mn; code = c ? (kk) : code; }
            STEPD(up[j], 1) STEPD(up[j + 1], 2) STEPD(r[j + 1], 3) STEPD(dn[j + 1], 4)
            STEPD(dn[j], 5) STEPD(dn[j - 1], 6) STEPD(r[j - 1], 7) STEPD(up[j - 1], 8)
#undef STEPD
            dr[j] = v != nv ? (signed char)code : NODIR;
        }
        if (m > 1) {
            int j = m - 1;
            float v = r[j], mn = v; int code = 0;
            const float nb[5] = {dn[j], dn[j - 1], r[j - 1], up[j - 1], up[j]};
            static const int cd[5] = {5, 6, 7, 8, 1};
            for (int k = 0; k < 5; k++) if (nb[k] != nv && nb[k] < mn) { mn = nb[k]; code = cd[k]; }
            dr[j] = v != nv ? (signed char)code : NODIR;
        }
    }
    PM("dir");
    FORMAT(1);
    PM("fmtD");

    // ------------------------------------------------------------ accumulation
    const long off[9] = {0, -M, -M + 1, 1, M + 1, M, M - 1, -1, -M - 1};
    int* acc = (int*)big_alloc(sizeof(int) * (size_t)V);
    unsigned char* indeg = (unsigned char*)big_alloc((size_t)V);
#pragma omp parallel for schedule(static)
    for (long i = 0; i < n; i++) {
        const long b = i * M, e = b + M;
        for (long c = b; c < e; c++) {
            int k = (D[c - M] == 5) + (D[c - M + 1] == 6) + (D[c + 1] == 7) + (D[c + M + 1] == 8)
                  + (D[c + M] == 1) + (D[c + M - 1] == 2) + (D[c - 1] == 3) + (D[c - M - 1] == 4);
            indeg[c] = (unsigned char)(k ? (0x80 | k) : 0);
            acc[c] = D[c] == NODIR ? -1 : 1;
        }
    }
    PM("accinit");
    // walks are distributed in blocks of WB cells (not rows): on planes all sources sit
    // in one row/column, row granularity would give one thread almost all the work
    const long WB = WALK_BLOCK, NWB = (V + WB - 1) / WB;
    // consecutive dispatches go to distant blocks (stride coprime with NWB) so that
    // threads do not fight over the same cache lines; one thread's block stays contiguous
    long PST = WALK_PERM ? (NWB / (T > 1 ? T : 1)) | 1 : 1;
    while (WALK_PERM && NWB > 1) { long a = PST, b2 = NWB; while (b2) { long t2 = a % b2; a = b2; b2 = t2; } if (a == 1) break; PST += 2; }
    // SEG[c] = source whose walk finalised c (segment id); STOP[s] = cell where the walk
    // started at source s merged into another walk (>= 0) or -(sink+1) if it reached its sink.
    // Watershed roots then follow STOP/SEG chains over sources only (no per-cell walks).
    int* SEG = (int*)tp;          // terrain no longer needed (directions done, section formatted)
    int* STOP = (int*)big_alloc(sizeof(int) * (size_t)V);
    int* SMIN = WS3 ? (int*)big_alloc(sizeof(int) * (size_t)V) : (int*)0;   // per source: min cell of its segment
    // phase 1: walks from the sources of each block; a walk longer than WALK_DEFER steps is
    // parked (its cell is final, its value carried) so that blocks holding many long walks
    // (e.g. a whole row of sources on a tilted plane) do not serialise on one thread;
    // phase 2 resumes the parked walks in parallel and runs them to completion.
    const int TMAX = omp_get_max_threads();
    std::vector<std::vector<WCont> > parked((size_t)(TMAX > 0 ? TMAX : 1));
#if NUMA_STATIC
#pragma omp parallel for schedule(static)
    for (long it = 0; it < NWB; it++) {
        const long wb = it;   // contiguous band per thread: the cells it first-touched
#else
#pragma omp parallel for schedule(dynamic, WALK_CHUNK)
    for (long it = 0; it < NWB; it++) {
        const long wb = (long)(((unsigned long long)it * (unsigned long long)PST) % (unsigned long long)NWB);
#endif
        const long b = wb * WB, e = b + WB < V ? b + WB : V;
        SrcScan nx = {b, e, indeg, D, SEG};
        walk_run(nx, D, indeg, acc, SEG, STOP, off, &parked[(size_t)omp_get_thread_num()], WALK_DEFER, SMIN);
    }
    PM("walk1");
    {
        std::vector<WCont> all;
        for (size_t k = 0; k < parked.size(); k++) all.insert(all.end(), parked[k].begin(), parked[k].end());
        const long NP = (long)all.size(), PCH = MW;
#if CHAIN_RANK
        if (NP > 0 && NP <= CR_MAXP && T >= 2 && !SMIN) chain_phase2(all, D, indeg, acc, SEG, STOP, off, V, T);
        else
#endif
        if (NP > 0) {
#pragma omp parallel for schedule(dynamic, 1)
            for (long ib = 0; ib < (NP + PCH - 1) / PCH; ib++) {
                ContList cl = {&all[0], ib * PCH, (ib + 1) * PCH < NP ? (ib + 1) * PCH : NP};
                walk_run(cl, D, indeg, acc, SEG, STOP, off, (std::vector<WCont>*)0, 0, SMIN);
            }
        }
    }
    PM("walk2");
    gi = acc;
    FORMAT(2);
    PM("fmtA");

    // ------------------------------------------------------------ watershed
#if WS3
    // F (in acc, formatted) = first cell of each basin, then its label. Every cell belongs to
    // exactly one walk segment and each segment's minimum cell was tracked during the walk,
    // so F[root] = min over the root's segments: only sources are visited, SEG stays intact
    // and the formatter gathers F[root(SEG[c])].
    int* F = acc;
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) if (D[c] == 0) F[c] = INT_MAX;
    PM("wsinit");
    const long RB = RES_BLOCK > 0 ? RES_BLOCK : WB, NRB = (V + RB - 1) / RB;
#pragma omp parallel for SCHED_LOC
    for (long it = 0; it < NRB; it++) {     // resolve the root of every source (memoised) + min
        const long b = it * RB, e = b + RB < V ? b + RB : V;
        for (long s = b; s < e; s++) {
            if (D[s] == NODIR || SEG[s] != (int)s) continue;   // sources only
            int v = __atomic_load_n(&STOP[s], __ATOMIC_RELAXED);
            int r;
            if (v < 0) r = -v - 1;
            else {
#if WS_HALVE
                // path halving over segments: STOP[q] (merge cell of q) is replaced by its
                // parent's merge cell (same basin, one level closer to the sink) with a CAS,
                // so a concurrently written root (< 0) is never overwritten
                long q = s;
                for (;;) {
                    int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED);
                    if (vq < 0) { r = -vq - 1; break; }
                    const long pq = SEG[vq];
                    int vp = __atomic_load_n(&STOP[pq], __ATOMIC_RELAXED);
                    if (vp < 0) { r = -vp - 1; break; }
                    __atomic_compare_exchange_n(&STOP[q], &vq, vp, false, __ATOMIC_RELAXED, __ATOMIC_RELAXED);
                    q = SEG[vp];
                }
                __atomic_store_n(&STOP[s], -r - 1, __ATOMIC_RELAXED);
#else
                long q = s;
                for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) { r = -vq - 1; break; } q = SEG[vq]; }
                q = s;
                for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) break;
                           __atomic_store_n(&STOP[q], -r - 1, __ATOMIC_RELAXED); q = SEG[vq]; }
#endif
            }
            const int mn = SMIN[s];
            int cur = __atomic_load_n(&F[r], __ATOMIC_RELAXED);
            while (mn < cur && !__atomic_compare_exchange_n(&F[r], &cur, mn, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
        }
    }
    PM("wsres");
    {
        const long C = V < 64L * T ? 1 : 4L * T;
        std::vector<long> fc(C + 1, 0);
#pragma omp parallel for schedule(static)
        for (long c = 0; c < V; c++) if (D[c] == 0) indeg[F[c]] = 1;   // indeg is 0/0x80 now: flag = 1
        PM("wsflag");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            long cntk = 0;
            for (long c = lo; c < hi; c++) cntk += indeg[c] == 1;
            fc[k + 1] = cntk;
        }
        for (long k = 1; k <= C; k++) fc[k] += fc[k - 1];
        PM("wscnt");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            int lab = 100 + (int)fc[k];
            for (long c = lo; c < hi; c++) if (indeg[c] == 1) F[-STOP[SEG[c]] - 1] = ++lab;
        }
    }
    PM("wslab");
    gstop = STOP; gseg = SEG; glab = F;
    FORMAT(3);
#else
    int* R = SEG;      // converted in place: R[c] = root sink of c
    int* F = acc;      // acc is formatted: F = first cell of each basin, then labels
    const long RB = RES_BLOCK > 0 ? RES_BLOCK : WB, NRB = (V + RB - 1) / RB;
#if NUMA_STATIC && RES_STATIC
#pragma omp parallel for schedule(static)
#else
#pragma omp parallel for schedule(dynamic, 1)
#endif
    for (long it = 0; it < NRB; it++) {     // resolve the root of every source (memoised)
        const long b = it * RB, e = b + RB < V ? b + RB : V;
        for (long s = b; s < e; s++) {
            if (!WS2 || D[s] == 0) F[s] = INT_MAX;
            if (D[s] == NODIR || SEG[s] != (int)s) continue;   // sources only
            int v = __atomic_load_n(&STOP[s], __ATOMIC_RELAXED);
            if (v < 0) continue;
            long q = s; int r;
#if WS_HALVE2
            for (;;) {   // lock-free path halving (CAS: a written root is never overwritten)
                int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED);
                if (vq < 0) { r = -vq - 1; break; }
                const long pq = SEG[vq];
                int vp = __atomic_load_n(&STOP[pq], __ATOMIC_RELAXED);
                if (vp < 0) { r = -vp - 1; break; }
                __atomic_compare_exchange_n(&STOP[q], &vq, vp, false, __ATOMIC_RELAXED, __ATOMIC_RELAXED);
                q = SEG[vp];
            }
            __atomic_store_n(&STOP[s], -r - 1, __ATOMIC_RELAXED);
#else
            for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) { r = -vq - 1; break; } q = SEG[vq]; }
            q = s;
            for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) break;
                       __atomic_store_n(&STOP[q], -r - 1, __ATOMIC_RELAXED); q = SEG[vq]; }
#endif
        }
    }
    PM("wsres");
#if WS2
    // root of every cell (in place over SEG) fused with the first-cell atomic min
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) {
        if (D[c] == NODIR) { R[c] = -1; continue; }
        const int r = -STOP[SEG[c]] - 1;
        R[c] = r;
        int cur = __atomic_load_n(&F[r], __ATOMIC_RELAXED);
        while (c < cur && !__atomic_compare_exchange_n(&F[r], &cur, (int)c, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
    }
    {   // flag first cells from the sinks only (indeg holds 0 or 0x80 now, flag = 1),
        // then rank flags in raster order; label stored at the sink, gathered by the formatter
        const long C = V < 64L * T ? 1 : 4L * T;
        PM("wsroot");
        std::vector<long> fc(C + 1, 0);
#pragma omp parallel for schedule(static)
        for (long c = 0; c < V; c++) if (D[c] == 0) indeg[F[c]] = 1;
        PM("wsflag");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            long cntk = 0;
            for (long c = lo; c < hi; c++) cntk += indeg[c] == 1;
            fc[k + 1] = cntk;
        }
        for (long k = 1; k <= C; k++) fc[k] += fc[k - 1];
        PM("wscnt");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            int lab = 100 + (int)fc[k];
            for (long c = lo; c < hi; c++) if (indeg[c] == 1) F[R[c]] = ++lab;
        }
    }
#else
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) R[c] = D[c] == NODIR ? -1 : -STOP[SEG[c]] - 1;
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) {
        if (D[c] == NODIR) continue;
        int r = R[c];
        int cur = __atomic_load_n(&F[r], __ATOMIC_RELAXED);
        while (c < cur && !__atomic_compare_exchange_n(&F[r], &cur, (int)c, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
    }
    {   // rank basins by their first cell (flags in indeg, prefix sum over C chunks)
        const long C = V < 64L * T ? 1 : 4L * T;
        std::vector<long> fc(C + 1, 0);
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            long cntk = 0;
            for (long c = lo; c < hi; c++) {
                unsigned char f = D[c] != NODIR && F[R[c]] == c;
                indeg[c] = f; cntk += f;
            }
            fc[k + 1] = cntk;
        }
        for (long k = 1; k <= C; k++) fc[k] += fc[k - 1];
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            int lab = 100 + (int)fc[k];
            for (long c = lo; c < hi; c++) if (indeg[c]) F[R[c]] = ++lab;   // label stored at the sink
        }
#pragma omp parallel for schedule(static)
        for (long c = 0; c < V; c++) R[c] = D[c] == NODIR ? -1 : F[R[c]];
    }
#endif
    PM("wslab");
    gi = R;
    if (WS2) glab = F;
    FORMAT(3);
#endif
    PM("fmtW");
    size_t relbytes = 0;   // small totals: the exit teardown is cheaper than a parallel pass
    for (size_t i = 0; i < late.size(); i++) relbytes += late[i].len;
    for (size_t i = 0; i < g_regions.size(); i++) relbytes += g_regions[i].len;
    for (size_t i = 0; i < g_pool.size(); i++) relbytes += g_pool[i].len;
    const bool rel = FASTREL && relbytes + 1 > (size_t)REL_MIN;   // relbytes >= REL_MIN (no -Wtype-limits at 0)
    (void)rel;
#if FASTREL
    if (rel) {   // compute arrays + input mapping: released while the writer drains its last blocks
        std::vector<Region> rs = late;
        rs.insert(rs.end(), g_regions.begin(), g_regions.end());
        release_parallel(rs, T);
    }
#endif
    PM("rel1");
    if (out.async) out.th.join();
    if (omap) {
        munmap(omap, omap_len);
        if (ftruncate(ofd, obase + (off_t)opos) != 0) perror("ftruncate");
        lseek(1, obase + (off_t)opos, SEEK_SET);
        close(ofd);
    }
    PM("join");
#if FASTREL
    if (rel) release_parallel(g_pool, T);   // output buffers
#endif
    PM("rel2");
    if (PROF) {
        struct rusage ru; getrusage(RUSAGE_SELF, &ru);
        fprintf(stderr, "maxrss=%ld(kB-linux/B-mac) writer[wait=%.3f write=%.3f free=%.3f] ", (long)ru.ru_maxrss, out.t_wait, out.t_write, out.t_free);
    }
    if (PROF) {
        const long long rt1 = rt_ns();
        fprintf(stderr, "PAR3 T=%d n=%d m=%d", T, n, m);
        for (int k = 0; k < np; k++) fprintf(stderr, " %s=%.4f/%ld", pn[k], ph[k], pf[k]);
        fprintf(stderr, " total=%.4f ABS main0=%lld mainend=%lld minflt=%ld\n", wtime() - t0, rt0, rt1, minflt());
    }
#if FAST_EXIT
    _exit(0);   // stdout is written with write(2) only; nothing is buffered
#endif
    return 0;
}
