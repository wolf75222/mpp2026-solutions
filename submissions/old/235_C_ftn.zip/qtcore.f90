! Problem C (Quadtree) -- compute core in Fortran 2008 + OpenMP, called from the C driver qt.c.
!
! The C driver reads the input, decides which path is exact for the domain (same rules as the C version),
! builds the level-D tables (thresholds TXv/TYv, relevant cells in DFS order) and formats the output.
! This module does the heavy part of the query-limited build:
!   1. phase 1: the glibc rand() TYPE_3 stream (seed 42) is generated in 16 interleaved lanes per chunk,
!      each chunk started by an exact jump-ahead; every point is tested against the k-space box of the
!      relevant cells and, if inside, located in its level-D cell and kept (generation order per lane);
!   2. a stable counting sort of the kept points by cell (cells in DFS order);
!   3. the check that every relevant node above level D has >= 5 points (else the driver retries D = 0);
!   4. phase 2: for every relevant cell, the top-down build of its subtree from its points (generation
!      order) with the query, exactly as the reference subdivides and visits (NW, NE, SW, SE).
!
! Arithmetic modulo 2^32: Fortran has no unsigned type, so the rand() state is held in INTEGER(4) and
! the sources are compiled with -fwrapv (two's-complement wrap-around of signed overflow).  Logical
! shifts use ISHFT; k = (r >>> 1) mod 1e6 is then non-negative.  Doubles follow IEEE exactly as in C
! (compiled with -ffp-contract=off, no fast-math): every coordinate and comparison is the reference's.
module qtcore
  use iso_c_binding
  implicit none
  private
  public :: qtf_run, qtf_results

  integer, parameter :: LANES = 16, ROWS = 256, MAXN = 1000000
  integer(c_int64_t), parameter :: KMASK20 = 1048575_c_int64_t

  ! results of the last run (read by the driver through qtf_results)
  real(c_double), allocatable, target, save :: g_res(:,:)
  integer(c_int64_t), allocatable, target, save :: g_base(:), g_rc(:)

  ! shared tables (set by qtf_run)
  integer :: g_d
  integer(c_int32_t), pointer :: g_tx(:), g_ty(:), g_relmap(:)
  real(c_double) :: g_sub(4)

  interface
    subroutine qt_shim_assert() bind(C, name="qt_shim_assert")
    end subroutine
    subroutine qt_shim_endless() bind(C, name="qt_shim_endless")
    end subroutine
  end interface

contains

  ! ------------------------------------------------------------------ glibc rand() stream
  ! Re-implementation of glibc srandom_r/random_r TYPE_3 (glibc stdlib/random_r.c): Park-Miller seeding with
  ! Schrage's factorisation; r(i) = r(i-31) + r(i-3) mod 2^32; output k is r(k+344) >>> 1.
  subroutine base_window(seed, b)
    integer, intent(in) :: seed
    integer(c_int32_t), intent(out) :: b(0:30)
    integer(c_int32_t) :: r(0:33), word, hi, lo
    integer :: i
    word = seed
    if (word == 0) word = 1
    r(0) = word
    do i = 1, 30
      hi = word / 127773
      lo = mod(word, 127773)
      word = 16807 * lo - 2836 * hi
      if (word < 0) word = word + 2147483647
      r(i) = word
    end do
    r(31:33) = r(0:2)
    b(0:30) = r(3:33)
  end subroutine

  ! out = a * b mod (x^31 - x^28 - 1) over Z/2^32 (x^31 = x^3 + 1 for the window recurrence)
  subroutine poly_mulmod(a, b, out)
    integer(c_int32_t), intent(in) :: a(0:30), b(0:30)
    integer(c_int32_t), intent(out) :: out(0:30)
    integer(c_int32_t) :: t(0:60), v
    integer :: i, j, k
    t = 0
    do i = 0, 30
      if (a(i) == 0) cycle
      do j = 0, 30
        t(i + j) = t(i + j) + a(i) * b(j)
      end do
    end do
    do k = 60, 31, -1
      v = t(k)
      t(k - 31) = t(k - 31) + v
      t(k - 3) = t(k - 3) + v
    end do
    out = t(0:30)
  end subroutine

  ! w = the 31 values r(k+313 .. k+343): w(0) + w(28) is r(k+344), i.e. the k-th rand() output (before >>>1)
  subroutine window_for_output(k, gb, w)
    integer(c_int64_t), intent(in) :: k
    integer(c_int32_t), intent(in) :: gb(0:30)
    integer(c_int32_t), intent(out) :: w(0:30)
    integer(c_int32_t) :: res(0:30), base(0:30), tmp(0:30), carry, s
    integer(c_int64_t) :: j
    integer :: t, i
    j = k + 310
    res = 0; base = 0
    res(0) = 1; base(1) = 1
    do while (j /= 0)
      if (iand(j, 1_c_int64_t) /= 0) then
        call poly_mulmod(res, base, tmp)
        res = tmp
      end if
      call poly_mulmod(base, base, tmp)
      base = tmp
      j = ishft(j, -1)
    end do
    do t = 0, 30
      s = 0
      do i = 0, 30
        s = s + res(i) * gb(i)
      end do
      w(t) = s
      carry = res(30)
      res(1:30) = res(0:29)
      res(0) = carry
      res(28) = res(28) + carry
    end do
  end subroutine

  ! m(:, t) = coefficients of x^(s+t) mod P: advances a window by s values (lane spacing)
  subroutine adv_matrix(s, m)
    integer(c_int64_t), intent(in) :: s
    integer(c_int32_t), intent(out) :: m(0:30, 0:30)
    integer(c_int32_t) :: res(0:30), base(0:30), tmp(0:30), carry
    integer(c_int64_t) :: j
    integer :: t
    j = s
    res = 0; base = 0
    res(0) = 1; base(1) = 1
    do while (j /= 0)
      if (iand(j, 1_c_int64_t) /= 0) then
        call poly_mulmod(res, base, tmp)
        res = tmp
      end if
      call poly_mulmod(base, base, tmp)
      base = tmp
      j = ishft(j, -1)
    end do
    do t = 0, 30
      m(:, t) = res
      carry = res(30)
      res(1:30) = res(0:29)
      res(0) = carry
      res(28) = res(28) + carry
    end do
  end subroutine

  ! ------------------------------------------------------------------ level-D cell lookup
  integer function xcell(kx)
    integer(c_int32_t), intent(in) :: kx
    integer :: l, j
    j = 0
    do l = 0, g_d - 1
      j = 2 * j + merge(1, 0, kx >= g_tx(ishft(1, l) + j))     ! g_tx is 1-based: index (2^l - 1 + j) + 1
    end do
    xcell = j
  end function
  integer function ycell(ky)
    integer(c_int32_t), intent(in) :: ky
    integer :: l, j
    j = 0
    do l = 0, g_d - 1
      j = 2 * j + merge(1, 0, ky >= g_ty(ishft(1, l) + j))
    end do
    ycell = j
  end function

  ! ------------------------------------------------------------------ reference predicates
  logical function point_in(r, x, y)          ! r = (x_min, x_max, y_min, y_max)
    real(c_double), intent(in) :: r(4), x, y
    point_in = .true.
    if (x < r(1)) point_in = .false.
    if (x > r(2)) point_in = .false.
    if (y < r(3)) point_in = .false.
    if (y > r(4)) point_in = .false.
  end function
  logical function retangle_in(r2, r1)        ! any corner of r2 inside r1
    real(c_double), intent(in) :: r2(4), r1(4)
    retangle_in = point_in(r1, r2(1), r2(3)) .or. point_in(r1, r2(1), r2(4)) .or. &
                  point_in(r1, r2(2), r2(3)) .or. point_in(r1, r2(2), r2(4))
  end function
  logical function intercept(r1, r2)
    real(c_double), intent(in) :: r1(4), r2(4)
    intercept = retangle_in(r2, r1) .or. retangle_in(r1, r2)
  end function

  ! ------------------------------------------------------------------ top-down build of one subtree
  ! node rect b; its c points are a(:, ao+1 : ao+c) (generation order); t is scratch at the same offsets;
  ! printed points are appended to out(:, r+1 ...).  Same steps as the reference's insertions.
  recursive subroutine build_node(b, a, t, ao, c, out, r, emit, depth)
    real(c_double), intent(in) :: b(4)
    real(c_double), intent(inout) :: a(2, *), t(2, *), out(2, *)
    integer(c_int64_t), intent(in) :: ao, c
    integer(c_int64_t), intent(inout) :: r
    logical, intent(in) :: emit
    integer, intent(in) :: depth
    logical :: em
    real(c_double) :: xa, ya, cb(4)
    real(c_float) :: fd
    integer(c_int64_t) :: cnt(0:3), off(0:3), pos(0:3), i
    integer :: ch
    em = emit
    if (em) em = intercept(b, g_sub)
    if (.not. em) return
    if (c <= 4) then
      do i = ao + 1, ao + c
        if (point_in(g_sub, a(1, i), a(2, i))) then
          r = r + 1
          out(:, r) = a(:, i)
        end if
      end do
      return
    end if
    ! the reference's assert(ret >= 0): a side below MAX_ERROR after conversion to float
    fd = real(b(2) - b(1), c_float)
    if (real(abs(fd), c_double) < 1.0d-10) call qt_shim_assert()
    fd = real(b(4) - b(3), c_float)
    if (real(abs(fd), c_double) < 1.0d-10) call qt_shim_assert()
    if (depth > 100000) call qt_shim_endless()
    xa = (b(1) + b(2)) / 2.0d0
    ya = (b(3) + b(4)) / 2.0d0
    cnt = 0
    do i = ao + 1, ao + c
      ch = merge(2, 0, a(2, i) < ya) + merge(1, 0, a(1, i) > xa)
      cnt(ch) = cnt(ch) + 1
    end do
    off(0) = 0; off(1) = cnt(0); off(2) = cnt(0) + cnt(1); off(3) = cnt(0) + cnt(1) + cnt(2)
    pos = off
    do i = ao + 1, ao + c
      ch = merge(2, 0, a(2, i) < ya) + merge(1, 0, a(1, i) > xa)
      pos(ch) = pos(ch) + 1
      t(:, ao + pos(ch)) = a(:, i)
    end do
    do ch = 0, 3                                     ! NW, NE, SW, SE
      if (iand(ch, 1) /= 0) then
        cb(1) = xa; cb(2) = b(2)
      else
        cb(1) = b(1); cb(2) = xa
      end if
      if (iand(ch, 2) /= 0) then
        cb(3) = b(3); cb(4) = ya
      else
        cb(3) = ya; cb(4) = b(4)
      end if
      call build_node(cb, t, a, ao + off(ch), cnt(ch), out, r, em, depth + 1)
    end do
  end subroutine

  ! ------------------------------------------------------------------ phase 1, one chunk of 16 lanes
  ! Lane l of chunk ch is the sub-stream of points s*L .. s*L+L-1 with s = 16 ch + l - 1 (one segment).
  ! The block loops are written lane-innermost on fixed-size local arrays so that gfortran vectorises the
  ! recurrence, the k = (r >>> 1) mod 1e6 reduction and the box test (AVX2: 16 lanes = 2 vectors).
  ! Profile history (single thread, 1e8 points, ROMEO): first version with array expressions on an
  ! allocatable ring 550 ms; this routine with a branchy .and. box test 677 ms (scalar division); the
  ! branch-free sign-bit box test, vectorised, 93-97 ms (a 64-bit magic-multiply modulo: 113 ms, kept
  ! the division); the C version takes 45 ms for the same work.
  subroutine p1_chunk(ch, n, lseg, nblk, d, bx0, bxw, by0, byw, gb, madv, capseg, pool, kvn, ovf)
    integer(c_int64_t), intent(in) :: ch, n, lseg, nblk, capseg
    integer, intent(in) :: d
    integer(c_int32_t), intent(in) :: bx0, bxw, by0, byw, gb(0:30), madv(0:30, 0:30)
    integer(c_int64_t), intent(inout) :: pool(capseg, *), kvn(*)
    integer, intent(inout) :: ovf
    integer(c_int32_t) :: ring(LANES, 0:ROWS + 30), w(0:30), w2(0:30)
    integer(c_int32_t) :: fl(LANES, 0:ROWS / 2 - 1)
    integer(c_int32_t) :: ux, uy, mq, kxv, kyv, msk(0:ROWS / 2 - 1)
    integer(c_int32_t), parameter :: LBIT(LANES) = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768]
    integer(c_int64_t) :: s0, blk, pos, idx, sv
    integer :: l, q, t, i, rid
    s0 = ch * LANES
    call window_for_output(2 * s0 * lseg, gb, w)
    do l = 1, LANES
      ring(l, 0:30) = w
      do t = 0, 30                                     ! next lane: w2(t) = sum_i w(i) * madv(i, t) mod 2^32
        w2(t) = 0
        do i = 0, 30
          w2(t) = w2(t) + w(i) * madv(i, t)
        end do
      end do
      w = w2
    end do
    do blk = 0, nblk - 1
      do q = 0, ROWS / 2 - 1                          ! r(i) = r(i-31) + r(i-3), two rows per pair
        do l = 1, LANES
          ring(l, 31 + 2 * q) = ring(l, 2 * q) + ring(l, 28 + 2 * q)
          ring(l, 32 + 2 * q) = ring(l, 2 * q + 1) + ring(l, 29 + 2 * q)
        end do
      end do
      do q = 0, ROWS / 2 - 1                          ! k = (r >>> 1) mod 1e6 and box test of every point;
        do l = 1, LANES                               ! 0 <= d < w <=> sign(d - w) = 1 and sign(d) = 0
          ux = ishft(ring(l, 31 + 2 * q), -1)
          uy = ishft(ring(l, 32 + 2 * q), -1)
          ux = ux - (ux / MAXN) * MAXN - bx0          ! gfortran vectorises the division by the constant
          uy = uy - (uy / MAXN) * MAXN - by0
          fl(l, q) = iand(iand(ishft(ux - bxw, -31), 1 - ishft(ux, -31)), iand(ishft(uy - byw, -31), 1 - ishft(uy, -31)))
        end do
      end do
      do q = 0, ROWS / 2 - 1                          ! lane mask of every pair (vectorised reduction)
        mq = 0
        do l = 1, LANES
          mq = mq + fl(l, q) * LBIT(l)
        end do
        msk(q) = mq
      end do
      do q = 0, ROWS / 2 - 1
        mq = msk(q)
        do while (mq /= 0)                            ! candidates: exact cell lookup, keep if relevant
          l = trailz(mq) + 1
          mq = iand(mq, mq - 1)
          pos = blk * (ROWS / 2) + q
          idx = (s0 + l - 1) * lseg + pos
          if (pos >= lseg .or. idx >= n) cycle
          kxv = mod(ishft(ring(l, 31 + 2 * q), -1), MAXN)
          kyv = mod(ishft(ring(l, 32 + 2 * q), -1), MAXN)
          rid = g_relmap(ior(ishft(ycell(kyv), d), xcell(kxv)) + 1) - 1
          if (rid < 0) cycle
          sv = s0 + l                                 ! 1-based segment
          if (kvn(sv) >= capseg) then
            !$omp atomic write
            ovf = 1
            cycle
          end if
          kvn(sv) = kvn(sv) + 1
          pool(kvn(sv), sv) = ior(ior(ishft(int(rid, c_int64_t), 40), ishft(int(kxv, c_int64_t), 20)), int(kyv, c_int64_t))
        end do
      end do
      ring(:, 0:30) = ring(:, ROWS:ROWS + 30)
    end do
  end subroutine

  ! ------------------------------------------------------------------ the whole fast path
  ! returns 1 (results ready), 0 (a relevant node above level D has < 5 points: retry with D = 0),
  ! -1 (a segment of the kept-point pool overflowed: the driver uses its C pipeline)
  integer(c_int) function qtf_run(n, lseg, nchunks, d, t1, bx0, bxw, by0, byw, ntab, tx, ty, ncells_all, relmap, &
                                  rd, cell_x, cell_y, nnodes, xlo, xhi, ylo, yhi, wx, wy, xmin, ymin, sub, &
                                  nrn, rn_l, rn_xj, rn_yj, rn_parent, capseg, m_out) bind(C, name="qtf_run")
    integer(c_int64_t), value :: n, lseg, nchunks, ncells_all, rd, nnodes, nrn, capseg
    integer(c_int), value :: d, t1, ntab
    integer(c_int32_t), value :: bx0, bxw, by0, byw
    integer(c_int32_t), target, intent(in) :: tx(ntab), ty(ntab), relmap(ncells_all)
    integer(c_int32_t), intent(in) :: cell_x(rd), cell_y(rd), rn_l(nrn), rn_xj(nrn), rn_yj(nrn), rn_parent(nrn)
    real(c_double), intent(in) :: xlo(nnodes), xhi(nnodes), ylo(nnodes), yhi(nnodes)
    real(c_double), value :: wx, wy, xmin, ymin
    real(c_double), intent(in) :: sub(4)
    integer(c_int64_t), intent(out) :: m_out

    integer(c_int64_t), allocatable :: pool(:,:), kvn(:), soff(:), hist(:,:), cellcnt(:), base(:), rcnt(:)
    integer(c_int32_t) :: gb(0:30), madv(0:30, 0:30), w(0:30), w2(0:30)
    real(c_double), allocatable :: a(:,:), scr(:,:)
    integer(c_int64_t) :: nseg, ch, s0, nblk, blk, pos, idx, tot, cl, cc, acc, maxcell, sv, r, m, i, s
    integer(c_int32_t) :: kx(LANES), ky(LANES), kxv, kyv
    integer :: l, q, t, ts, ovf, rid, fl, tt
    real(c_double) :: cb(4), x, y
    logical :: ok

    g_d = d
    g_tx => tx
    g_ty => ty
    g_relmap => relmap
    g_sub = sub
    nseg = nchunks * LANES
    allocate(pool(capseg, nseg), kvn(nseg))
    kvn = 0
    call base_window(42, gb)
    call adv_matrix(2 * lseg, madv)
    ovf = 0
    nblk = (lseg + ROWS / 2 - 1) / (ROWS / 2)

    ! ---- phase 1: generation + box filter + cell lookup, one chunk of 16 lanes at a time
    !$omp parallel do num_threads(t1) default(shared) schedule(dynamic, 1)
    do ch = 0, nchunks - 1
      call p1_chunk(ch, n, lseg, nblk, d, bx0, bxw, by0, byw, gb, madv, capseg, pool, kvn, ovf)
    end do
    !$omp end parallel do
    if (ovf /= 0) then
      qtf_run = -1
      return
    end if

    ! ---- stable counting sort by cell: ts sorters, each on a contiguous range of segments
    allocate(soff(0:nseg))
    soff(0) = 0
    do s = 1, nseg
      soff(s) = soff(s - 1) + kvn(s)
    end do
    tot = soff(nseg)
    ts = int(min(int(t1, c_int64_t), max(1_c_int64_t, tot / 1024)))
    ts = int(min(int(ts, c_int64_t), max(1_c_int64_t, 4194304_c_int64_t / rd)))   ! histograms <= 32 MB
    allocate(hist(rd, ts), cellcnt(rd), base(rd + 1))
    !$omp parallel do num_threads(ts) private(s, i, cl) schedule(static, 1)
    do tt = 1, ts
      hist(:, tt) = 0
      do s = seg_first(tt), seg_first(tt + 1) - 1
        do i = 1, kvn(s)
          cl = ishft(pool(i, s), -40) + 1
          hist(cl, tt) = hist(cl, tt) + 1
        end do
      end do
    end do
    !$omp end parallel do
    do cl = 1, rd
      cellcnt(cl) = sum(hist(cl, :))
    end do

    ! ---- every relevant node above level D needs >= 5 points (lower bound: points kept below it)
    allocate(rcnt(nrn))
    rcnt = 0
    do i = 1, nrn
      if (rn_l(i) == d) rcnt(i) = cellcnt(relmap(ior(ishft(rn_yj(i), d), rn_xj(i)) + 1))   ! relmap = rank + 1
    end do
    do i = nrn, 2, -1
      rcnt(rn_parent(i) + 1) = rcnt(rn_parent(i) + 1) + rcnt(i)
    end do
    ok = .true.
    do i = 1, nrn
      if (rn_l(i) < d .and. rcnt(i) < 5) ok = .false.
    end do
    if (.not. ok) then
      qtf_run = 0
      return
    end if

    ! ---- offsets (cells in DFS order, sorters in segment order) and scatter with coordinates
    acc = 0
    maxcell = 0
    do cl = 1, rd
      base(cl) = acc
      do tt = 1, ts
        cc = hist(cl, tt)
        hist(cl, tt) = acc
        acc = acc + cc
      end do
      maxcell = max(maxcell, cellcnt(cl))
    end do
    base(rd + 1) = acc
    allocate(a(2, max(tot, 1_c_int64_t)))
    !$omp parallel do num_threads(ts) private(s, i, cl, kxv, kyv, x, y) schedule(static, 1)
    do tt = 1, ts
      do s = seg_first(tt), seg_first(tt + 1) - 1
        do i = 1, kvn(s)
          cl = ishft(pool(i, s), -40) + 1
          kxv = int(iand(ishft(pool(i, s), -20), KMASK20), c_int32_t)
          kyv = int(iand(pool(i, s), KMASK20), c_int32_t)
          x = real(kxv, c_double) / real(MAXN, c_double)          ! = get_randon(); x *= W; x += x_min
          x = x * wx
          x = x + xmin
          y = real(kyv, c_double) / real(MAXN, c_double)
          y = y * wy
          y = y + ymin
          hist(cl, tt) = hist(cl, tt) + 1
          a(1, hist(cl, tt)) = x
          a(2, hist(cl, tt)) = y
        end do
      end do
    end do
    !$omp end parallel do
    deallocate(pool)

    ! ---- phase 2: build + query of every relevant cell, results at the cell's base
    if (allocated(g_res)) deallocate(g_res)
    if (allocated(g_base)) deallocate(g_base)
    if (allocated(g_rc)) deallocate(g_rc)
    allocate(g_res(2, max(tot, 1_c_int64_t)), g_base(rd + 1), g_rc(rd))
    g_base = base
    !$omp parallel num_threads(t1) default(shared) private(scr, cl, cb, r)
    allocate(scr(2, max(maxcell, 1_c_int64_t)))
    !$omp do schedule(dynamic, 1)
    do cl = 1, rd
      cb(1) = xlo(cell_x(cl) + ishft(1, d))        ! node index 2^D - 1 + xj, 1-based
      cb(2) = xhi(cell_x(cl) + ishft(1, d))
      cb(3) = ylo(cell_y(cl) + ishft(1, d))
      cb(4) = yhi(cell_y(cl) + ishft(1, d))
      r = 0
      call build_node(cb, a(:, base(cl) + 1:), scr, 0_c_int64_t, base(cl + 1) - base(cl), g_res(:, base(cl) + 1:), r, &
                      .true., d)
      g_rc(cl) = r
    end do
    !$omp end do
    deallocate(scr)
    !$omp end parallel
    m = sum(g_rc)
    m_out = m
    qtf_run = 1

  contains
    integer(c_int64_t) function seg_first(tt)      ! first segment of sorter tt (segments split by kept count)
      integer, intent(in) :: tt
      integer(c_int64_t) :: target, lo, hi, mid
      if (tt > ts) then
        seg_first = nseg + 1
        return
      end if
      if (tt == 1) then
        seg_first = 1
        return
      end if
      target = (tot * (tt - 1)) / ts
      lo = 1; hi = nseg + 1                        ! smallest s with soff(s-1) >= target
      do while (lo < hi)
        mid = (lo + hi) / 2
        if (soff(mid - 1) >= target) then
          hi = mid
        else
          lo = mid + 1
        end if
      end do
      seg_first = lo
    end function
  end function

  ! pointers to the results of the last run: points (x, y) of cell c are res(:, base(c)+1 .. base(c)+rc(c))
  subroutine qtf_results(res, base, rc) bind(C, name="qtf_results")
    type(c_ptr), intent(out) :: res, base, rc
    res = c_loc(g_res)
    base = c_loc(g_base)
    rc = c_loc(g_rc)
  end subroutine
end module
