/*
 * Problem C (Quadtree) -- fast version, output byte-identical to the reference qt.c
 * as it runs on Linux/glibc.
 *
 * Key facts used (all derived from the reference code):
 *  - the final quadtree is a pure function of the point sequence: a node is subdivided
 *    iff >= 5 points are routed to it; leaf points are kept in generation order;
 *    child = (y < y_ave ? 2 : 0) + (x > x_ave ? 1 : 0), x_ave = (x_min + x_max)/2.0;
 *  - the query visits children NW,NE,SW,SE and prunes with intercept() (corner tests only);
 *    a point is printed iff point_in(region) and intercept() holds on its whole root path;
 *  - so only the nodes whose path intercepts the query need to be built (top-down,
 *    stable partition), everything else only has to be counted;
 *  - glibc rand() is the additive lagged generator r[i]=r[i-31]+r[i-3] (mod 2^32),
 *    output r[k+344]>>1, which is linear => exact jump-ahead => parallel generation;
 *  - coordinates x = fl(fl(fl(k/1e6)*W)+x_min) are monotone in k = rand()%1e6 (W>0),
 *    so every comparison against a fixed threshold becomes an integer comparison on k.
 *
 * Build (Makefile): gcc -O3 -Wall -pthread -ffp-contract=off qt.c -o qt -Wl,--as-needed -lm
 *   -ffp-contract=off is REQUIRED: an FMA in x*W+x_min changes coordinates bitwise.
 *   The whole pipeline runs on one team of POSIX threads created by the program (no OpenMP runtime);
 *   its size follows the work and is bounded by the CPU affinity mask.
 * -DFORCE_GLIBC_EMU : always use the built-in glibc rand() emulation (for testing on macOS).
 * Developer test / profiling switches (environment variables QT_*, read at the start of main) are all
 * off unless set; the script C sets none.
 *
 * C_ftn variant: the query-limited fast path (phase 1 generation and filter, sort, check, build and query)
 * runs in the Fortran 2008 + OpenMP module qtcore.f90 (qtf_run); this C file is the driver: input parsing
 * (atof semantics), the choice of the exact path, the level-D tables, the exact "(%.1f,%.1f)" output, and
 * the fallback paths (full parallel build, serial generic path, non-AVX2 or non-glibc systems, pool
 * overflow), which are the C version's own.
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <assert.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <sys/uio.h>
#include <sys/mman.h>
#include <sys/resource.h>
#ifdef __linux__
#include <sys/prctl.h>
#endif
#if defined(__x86_64__) || defined(__SSE2__)
#include <emmintrin.h>
static inline double qt_sqrt(double x) { return _mm_cvtsd_f64(_mm_sqrt_sd(_mm_set_sd(x), _mm_set_sd(x))); }   /* = sqrt(), no libm/errno */
#else
static inline double qt_sqrt(double x) { return __builtin_sqrt(x); }
#endif
static inline double dmax(double a, double b) { return a > b ? a : b; }   /* fmax for non-NaN operands */
static int g_fastsetup = 1, g_p1k = 2;   /* closed-form kthr seed (env QT_FASTSETUP=0 off); phase-1 box test: 2 = fraction bits, 0 = modulo (env QT_P1K) */
static int g_madv = 1, g_earlyfree = -1; /* MADV_HUGEPAGE on big blocks (env QT_NOMADV=1 off); early release: -1 auto (4 KB pages only), env QT_EARLYFREE=0/1 */
static double g_tfmin = -1;              /* env QT_TFMIN: result lines per format thread */

#define MAX_CHILDREN 4
#define MAX_ERROR  1E-10
#define MAX_NORMA  1000000
#define STRING_SIZE 1024*64

typedef struct { double x; double y; } tpPoint;
typedef struct { double x_min; double x_max; double y_min; double y_max; } tpRectangle;
typedef struct { tpRectangle map_boundaries; tpRectangle sub_boundaries; uint64_t n_points; } tpConfig;

/* ------------------------------------------------------------------ reference helpers (verbatim semantics) */
static bool point_in(tpRectangle r, tpPoint p) {
    if (p.x < r.x_min) return false;
    if (p.x > r.x_max) return false;
    if (p.y < r.y_min) return false;
    if (p.y > r.y_max) return false;
    return true;
}
static bool retangle_in(tpRectangle r2, tpRectangle r1) {
    tpPoint p; bool ret = false;
    p.x = r2.x_min; p.y = r2.y_min; if (point_in(r1, p)) ret = true;
    p.x = r2.x_min; p.y = r2.y_max; if (point_in(r1, p)) ret = true;
    p.x = r2.x_max; p.y = r2.y_min; if (point_in(r1, p)) ret = true;
    p.x = r2.x_max; p.y = r2.y_max; if (point_in(r1, p)) ret = true;
    return ret;
}
static bool intercept(tpRectangle r1, tpRectangle r2) {
    bool r2_in_r1 = retangle_in(r2, r1);
    bool r1_in_r2 = retangle_in(r1, r2);
    return (r2_in_r1 || r1_in_r2);
}
static int g_fastsetup_early = 1;   /* trim() without the 64 KB memset, glibc check without the jump */
static void trim(char *dest, char *source) {
    uint64_t len = strlen(source), i = 0, j = 0;
    if (!g_fastsetup_early) memset(dest, 0, STRING_SIZE);
    while (i < len) { if ((source[i] != ' ') && (source[i] != '\n')) dest[j++] = source[i]; i++; }
    dest[j] = 0;   /* the only byte the string functions read past the copy */
}
static tpConfig load_config_ini(void) {
    tpConfig config;
    static char line[STRING_SIZE], param[STRING_SIZE], value[STRING_SIZE];
    memset(&config, 0, sizeof config);   /* reference leaves missing keys uninitialised (UB) */
    while (fgets(line, STRING_SIZE, stdin)) {
        char *token = strtok(line, "=");
        trim(param, token);
        if ((strlen(param) > 0) && (param[0] != '#')) {
            token = strtok(NULL, "=");
            trim(value, token);
            if (strcmp(param, "x_min") == 0) config.map_boundaries.x_min = atof(value);
            else if (strcmp(param, "x_max") == 0) config.map_boundaries.x_max = atof(value);
            else if (strcmp(param, "y_min") == 0) config.map_boundaries.y_min = atof(value);
            else if (strcmp(param, "y_max") == 0) config.map_boundaries.y_max = atof(value);
            else if (strcmp(param, "sub_x_min") == 0) config.sub_boundaries.x_min = atof(value);
            else if (strcmp(param, "sub_x_max") == 0) config.sub_boundaries.x_max = atof(value);
            else if (strcmp(param, "sub_y_min") == 0) config.sub_boundaries.y_min = atof(value);
            else if (strcmp(param, "sub_y_max") == 0) config.sub_boundaries.y_max = atof(value);
            else if (strcmp(param, "num_points") == 0) config.n_points = (uint64_t) atoi(value);
        }
    }
    return config;
}
/* the reference's assert(ret >= 0) in insert_point_quadtree (reference qt.c:298) fires when a node with
 * >= 5 points cannot be subdivided (side < MAX_ERROR after float conversion); same end here: the message
 * mirrors glibc's assert text for that line, then abort() (SIGABRT, empty stdout as in the reference) */
static void check_subdivision(const tpRectangle *b) {
    int ret = 1;
    double d = fabsf(b->x_max - b->x_min);
    if (d < MAX_ERROR) ret = -1;
    d = fabsf(b->y_max - b->y_min);
    if (d < MAX_ERROR) ret = -1;
    if (ret < 0) {
        fprintf(stderr, "qt: qt.c: insert_point_quadtree: Assertion `ret >= 0' failed.\n");
        abort();
    }
}
static inline tpRectangle child_rect(const tpRectangle *b, int c, double x_ave, double y_ave) {
    tpRectangle r;
    if (c & 1) { r.x_min = x_ave; r.x_max = b->x_max; } else { r.x_min = b->x_min; r.x_max = x_ave; }
    if (c & 2) { r.y_min = b->y_min; r.y_max = y_ave; } else { r.y_min = y_ave; r.y_max = b->y_max; }
    return r;
}

/* ------------------------------------------------------------------ glibc rand() emulation + jump-ahead
 * Re-implementation of glibc srandom_r/random_r TYPE_3 (algorithm from glibc stdlib/random_r.c, LGPL-2.1)
 * to reproduce rand() exactly: Park-Miller seeding with Schrage's factorisation, r[i] = r[i-31] + r[i-3]
 * (mod 2^32), the first 310 values discarded, output r >> 1.  It is checked at start-up against the
 * real rand() (libc_rand_is_glibc); on another libc the program uses that libc's rand() sequentially.
 * The jump-ahead (x^j mod the characteristic polynomial) is ours. */
static uint32_t g_B[31];
static void rng_base_window(unsigned seed, uint32_t B[31]) {
    int32_t r[34];
    if (seed == 0) seed = 1;
    r[0] = (int32_t)seed; int32_t word = (int32_t)seed;
    for (int i = 1; i < 31; i++) {
        long hi = word / 127773, lo = word % 127773;
        word = (int32_t)(16807 * lo - 2836 * hi);
        if (word < 0) word += 2147483647;
        r[i] = word;
    }
    for (int i = 31; i < 34; i++) r[i] = r[i - 31];
    for (int i = 0; i < 31; i++) B[i] = (uint32_t)r[3 + i];
}
static void poly_mulmod(const uint32_t *a, const uint32_t *b, uint32_t *out) {
    uint32_t t[61];
    memset(t, 0, sizeof t);
    for (int i = 0; i < 31; i++) { uint32_t ai = a[i]; if (!ai) continue; for (int j = 0; j < 31; j++) t[i + j] += ai * b[j]; }
    for (int k = 60; k >= 31; k--) { uint32_t v = t[k]; t[k - 31] += v; t[k - 3] += v; }
    memcpy(out, t, 31 * sizeof(uint32_t));
}
/* W = r[k+313 .. k+343]: the next value W[0]+W[28] = r[k+344] gives the k-th rand() output */
static void rng_window_for_output(uint64_t k, uint32_t W[31]) {
    uint64_t j = k + 310;
    uint32_t res[31] = {0}, base[31] = {0};
    res[0] = 1; base[1] = 1;
    while (j) { if (j & 1) poly_mulmod(res, base, res); poly_mulmod(base, base, base); j >>= 1; }
    for (int t = 0; t < 31; t++) {
        uint32_t s = 0;
        for (int i = 0; i < 31; i++) s += res[i] * g_B[i];
        W[t] = s;
        uint32_t carry = res[30];
        for (int i = 30; i > 0; i--) res[i] = res[i - 1];
        res[0] = carry; res[28] += carry;
    }
}
/* returns 1 if the C library rand() is glibc's (checked on the first outputs of srand(42)) */
static int libc_rand_is_glibc(void) {
#ifdef FORCE_GLIBC_EMU
    return 1;
#else
    uint32_t W[31 + 64];
    if (g_fastsetup_early) {   /* r[0..33] from the base window (r[3..33] = B, r[0..2] = r[31..33]), then r[i] = r[i-31] + r[i-3] */
        uint32_t r[344 + 64];
        for (int i = 0; i < 31; i++) r[3 + i] = g_B[i];
        r[0] = r[31]; r[1] = r[32]; r[2] = r[33];
        for (int i = 34; i < 344 + 64; i++) r[i] = r[i - 31] + r[i - 3];
        for (int i = 0; i < 31 + 64; i++) W[i] = r[313 + i];
    } else {
        rng_window_for_output(0, W);
        for (int i = 31; i < 31 + 64; i++) W[i] = W[i - 31] + W[i - 3];
    }
    srand(42);
    for (int i = 0; i < 64; i++) if (rand() != (int)(W[31 + i] >> 1)) return 0;
    return 1;
#endif
}

/* ------------------------------------------------------------------ globals */
#include <time.h>
static int g_prof = 0;
static uint64_t g_ppt = 0;   /* if set (env QT_PPT): points per phase-1 thread, overrides the sqrt rule */
static double tnow(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + 1e-9 * t.tv_nsec; }
#define PROF(name, t0) do { if (g_prof) { double t1_ = tnow(); fprintf(stderr, "  %-28s %.5f s\n", name, t1_ - (t0)); (t0) = t1_; } } while (0)
static tpConfig C;
static double Wx, Wy;               /* x_max-x_min, y_max-y_min exactly as the reference computes them */
static int use_emu = 1;             /* 1: jump-ahead emulation; 0: arrays filled with the real rand() */
static uint32_t *KX = NULL, *KY = NULL;

static inline double fx(uint32_t k) { double x = (double)(int)k / (double)MAX_NORMA; x *= Wx; x += C.map_boundaries.x_min; return x; }
static inline double fy(uint32_t k) { double y = (double)(int)k / (double)MAX_NORMA; y *= Wy; y += C.map_boundaries.y_min; return y; }
/* smallest k in [0,1e6] with f(k) > t (gt=1) or f(k) >= t (gt=0); f monotone non-decreasing */
static inline int kpred(int isx, double t, int gt, long k) {   /* k = 1e6 is the "none" sentinel */
    if (k >= MAX_NORMA) return 1;
    double v = isx ? fx((uint32_t)k) : fy((uint32_t)k);
    return gt ? (v > t) : (v >= t);
}
static uint32_t kthr(int isx, double t, int gt) {
    if (g_fastsetup) {   /* seed k ~ (t - lo) / W * 1e6, then walk with the exact predicate (<= 8 steps) */
        double W = isx ? Wx : Wy, lo0 = isx ? C.map_boundaries.x_min : C.map_boundaries.y_min;
        double gk = (t - lo0) / W * 1e6;
        if (gk > -4.0 && gk < MAX_NORMA + 4.0) {
            long k = (long)gk; if (k < 0) k = 0; if (k > MAX_NORMA) k = MAX_NORMA;
            for (int st = 0; st < 8; st++) {
                if (!kpred(isx, t, gt, k)) { k++; continue; }
                if (k > 0 && kpred(isx, t, gt, k - 1)) { k--; continue; }
                return (uint32_t)k;
            }
        }
    }
    uint32_t lo = 0, hi = MAX_NORMA;
    while (lo < hi) {
        uint32_t mid = (lo + hi) >> 1;
        double v = isx ? fx(mid) : fy(mid);
        bool ok = gt ? (v > t) : (v >= t);
        if (ok) hi = mid; else lo = mid + 1;
    }
    return lo;
}

#define GEN_BLK 2046   /* even (x,y pairs) and multiple of 3 (register rotation) */
/* buf[31..31+GEN_BLK) = next values from the window buf[0..31): r[k] = r[k-31] + r[k-3] */
static inline void rng_fill(uint32_t *buf) {
    uint32_t a = buf[28], b = buf[29], c = buf[30];
    for (int k = 31; k < 31 + GEN_BLK; k += 3) {
        a += buf[k - 31]; buf[k] = a;
        b += buf[k - 30]; buf[k + 1] = b;
        c += buf[k - 29]; buf[k + 2] = c;
    }
}

/* ------------------------------------------------------------------ thread pool of the generic path
 * par_run(nt, fn, ctx) runs fn(tid, nt_actual, ctx) on nt threads (nt<=1: inline call).  It is only used
 * to format the output of the generic path; the fast path uses the fused team further down.  Pool threads
 * are created as a binary tree (each new thread creates its children); between jobs they spin, then
 * block on a condition variable. */
typedef void (*job_fn)(int, int, void *);
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#if defined(__x86_64__) || defined(__i386__)
#define CPU_RELAX() __builtin_ia32_pause()
#elif defined(__aarch64__)
#define CPU_RELAX() __asm__ __volatile__("yield" ::: "memory")
#else
#define CPU_RELAX() do { } while (0)
#endif
#ifndef POOL_STACK
#define POOL_STACK (256 * 1024)
#endif
#ifndef POOL_SPIN
#define POOL_SPIN (1L << 20)
#endif
#define POOL_MAX 4096
static int pool_size = 1, pool_target = 1, pool_broken = 0, pool_attr_ok = 0;
static _Atomic int pool_accounted = 0;           /* threads created or given up (incl. failed subtrees) */
static _Atomic unsigned pool_gen = 0;
static _Atomic int pool_done = 0, pool_sleepers = 0;
static job_fn pool_fn; static void *pool_ctx; static int pool_nt;
static pthread_mutex_t pool_mx = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t pool_cv = PTHREAD_COND_INITIALIZER;
static pthread_attr_t pool_attr;
static void *pool_worker(void *arg);
static int subtree_size(int c, int T) { int s = 0; long lo = c, hi = c; while (lo < T) { s += (int)((hi < T - 1 ? hi : T - 1) - lo + 1); lo = 2 * lo + 1; hi = 2 * hi + 2; } return s; }
static void pool_spawn(int id, unsigned seen, int tree) {
    pthread_t th;
    uintptr_t a = ((uintptr_t)seen << 17) | ((uintptr_t)tree << 16) | (uintptr_t)id;
    if (pthread_create(&th, pool_attr_ok ? &pool_attr : NULL, pool_worker, (void *)a) != 0) {
        pool_broken = 1;
        atomic_fetch_add(&pool_accounted, tree ? subtree_size(id, pool_target) : 1);
        return;
    }
    pthread_detach(th);
    atomic_fetch_add(&pool_accounted, 1);
}
/* "ramp": the first phase-1 job is run by every worker straight from its start routine, so the
 * master and the first threads work while the rest of the tree is still being created
 * (thread creation is serialised in the kernel at ~30 us/thread on a 2x96-core EPYC). */
static job_fn g_ramp_fn; static void *g_ramp_ctx; static int g_ramp_nt;
static _Atomic int g_ramp_state = 0;             /* 0 = not yet published, 1 = run it, 2 = cancelled */
static void ramp_cancel(void) { int z = 0; atomic_compare_exchange_strong(&g_ramp_state, &z, 2); }
static void *pool_worker(void *arg) {
    uintptr_t a = (uintptr_t)arg;
    int id = (int)(a & 0xffff), tree = (int)((a >> 16) & 1);
    unsigned seen = (unsigned)(a >> 17);
    if (tree) for (int k = 1; k <= 2; k++) { int c = 2 * id + k; if (c < pool_target) pool_spawn(c, seen, 1); }
    if (tree && seen == 0) {                     /* initial tree: join the ramp job (phase 1) */
        int st;
        while ((st = atomic_load(&g_ramp_state)) == 0) CPU_RELAX();
        if (st == 1 && id < g_ramp_nt) g_ramp_fn(id, g_ramp_nt, g_ramp_ctx);
    }
    for (;;) {
        unsigned g; long spins = 0;
        while ((g = atomic_load(&pool_gen)) == seen) {
            CPU_RELAX();
            if (++spins > POOL_SPIN) {
                pthread_mutex_lock(&pool_mx);
                atomic_fetch_add(&pool_sleepers, 1);
                while ((g = atomic_load(&pool_gen)) == seen) pthread_cond_wait(&pool_cv, &pool_mx);
                atomic_fetch_sub(&pool_sleepers, 1);
                pthread_mutex_unlock(&pool_mx);
                break;
            }
        }
        seen = g;
        if (id < pool_nt) pool_fn(id, pool_nt, pool_ctx);
        atomic_fetch_add(&pool_done, 1);
    }
    return NULL;
}
static void pool_attr_init(void) {
    if (!pool_attr_ok && pthread_attr_init(&pool_attr) == 0) { pthread_attr_setstacksize(&pool_attr, POOL_STACK); pool_attr_ok = 1; }
}
/* start creating T-1 workers as a tree; returns at once (the master only creates ids 1 and 2) */
__attribute__((unused)) static void pool_start(int T) {
    if (T > POOL_MAX) T = POOL_MAX;
    if (T <= pool_target || pool_target > 1) return;
    pool_attr_init();
    pool_target = T;
    for (int k = 1; k <= 2; k++) if (k < T) pool_spawn(k, atomic_load(&pool_gen), 1);
}
static void pool_ensure(int nt) {
    if (nt > POOL_MAX) nt = POOL_MAX;
    if (pool_target < nt) {
        if (pool_target == 1) { ramp_cancel(); pool_start(nt); }   /* plain job pool: no ramp */
        else {   /* grow: the master creates the extra workers (only for large-m phases) */
            while (atomic_load(&pool_accounted) < pool_target - 1) CPU_RELAX();
            int old = pool_target; pool_target = nt;
            for (int id = old; id < nt; id++) pool_spawn(id, atomic_load(&pool_gen), 0);
        }
    }
    while (atomic_load(&pool_accounted) < pool_target - 1) CPU_RELAX();
    pool_size = pool_target;
}
static void par_run(int nt, job_fn fn, void *ctx) {
    if (nt > POOL_MAX) nt = POOL_MAX;
    if (nt <= 1 || pool_broken) { fn(0, 1, ctx); return; }
    pool_ensure(nt);
    if (pool_broken) { fn(0, 1, ctx); return; }
    pool_fn = fn; pool_ctx = ctx; pool_nt = nt;
    atomic_store(&pool_done, 0);
    atomic_fetch_add(&pool_gen, 1);
    if (atomic_load(&pool_sleepers) > 0) { pthread_mutex_lock(&pool_mx); pthread_cond_broadcast(&pool_cv); pthread_mutex_unlock(&pool_mx); }
    fn(0, nt, ctx);
    while (atomic_load(&pool_done) < pool_size - 1) CPU_RELAX();
}
static int nthreads(void) {
    int ncpu = 0;
#ifdef __linux__
    cpu_set_t cs; if (sched_getaffinity(0, sizeof cs, &cs) == 0) ncpu = CPU_COUNT(&cs);
#endif
    if (ncpu <= 0) { long c = sysconf(_SC_NPROCESSORS_ONLN); ncpu = c > 0 ? (int)c : 1; }
    const char *e = getenv("OMP_NUM_THREADS");   /* honoured only downwards: spinning teams must not oversubscribe */
    if (e && atoi(e) > 0 && atoi(e) < ncpu) return atoi(e);
    return ncpu;
}
#define ATOMIC_SIZE _Atomic size_t
#define FETCH_ADD(p, v) atomic_fetch_add((p), (v))

/* ------------------------------------------------------------------ top-down build of the query-relevant part */
/* recursive build of a node holding c points (generation order) in a[]; tmp[] is scratch of size c.
 * Appends printed points (DFS order) to out[*r].  emit=0: subtree not printed, only built to
 * reproduce the reference's assert (generic path only). */
static void build_node(tpRectangle b, tpPoint *a, tpPoint *tmp, size_t c, tpPoint *out, size_t *r, int emit, int full, int depth) {
    if (emit && !intercept(b, C.sub_boundaries)) emit = 0;
    if (!emit && !full) return;
    if (c <= MAX_CHILDREN) {
        if (emit) for (size_t i = 0; i < c; i++) if (point_in(C.sub_boundaries, a[i])) out[(*r)++] = a[i];
        return;
    }
    check_subdivision(&b);
    /* >=5 points that midpoint rounding can no longer separate (child == parent): the reference
     * recurses forever in insert_point_quadtree and dies of stack overflow -> same observable end */
    if (depth > 100000) { fprintf(stderr, "quadtree: unbounded subdivision (reference overflows its stack)\n"); raise(SIGSEGV); abort(); }
    double x_ave = (b.x_min + b.x_max) / 2.0;
    double y_ave = (b.y_min + b.y_max) / 2.0;
    size_t cnt[4] = {0, 0, 0, 0};
    for (size_t i = 0; i < c; i++) cnt[(a[i].y < y_ave ? 2 : 0) + (a[i].x > x_ave ? 1 : 0)]++;
    size_t off[4] = {0, cnt[0], cnt[0] + cnt[1], cnt[0] + cnt[1] + cnt[2]}, pos[4];
    memcpy(pos, off, sizeof pos);
    for (size_t i = 0; i < c; i++) tmp[pos[(a[i].y < y_ave ? 2 : 0) + (a[i].x > x_ave ? 1 : 0)]++] = a[i];
    for (int ch = 0; ch < 4; ch++)
        build_node(child_rect(&b, ch, x_ave, y_ave), tmp + off[ch], a + off[ch], cnt[ch], out, r, emit, full, depth + 1);
}

/* ------------------------------------------------------------------ output */
static const char DIG2[201] =
    "00010203040506070809101112131415161718192021222324252627282930313233343536373839"
    "40414243444546474849505152535455565758596061626364656667686970717273747576777879"
    "8081828384858687888990919293949596979899";
static char *fmt_slow(char *p, double v) { return p + sprintf(p, "%.1f", v); }
/* exact "%.1f" (round-half-even on the exact binary value, like glibc printf) */
static inline char *fmt1(char *p, double v) {
    uint64_t bits; memcpy(&bits, &v, 8);
    int ex = (int)((bits >> 52) & 0x7ff);
    uint64_t man = bits & ((1ULL << 52) - 1);
    int e;
    if (ex == 0x7ff) return fmt_slow(p, v);
    if (ex == 0) e = -1074; else { man |= 1ULL << 52; e = ex - 1075; }
    uint64_t R, t = man * 10;                       /* |v|*10 = t * 2^e, t < 2^57 */
    if (e >= 0) { if (e > 6) return fmt_slow(p, v); R = t << e; }
    else {
        int s = -e;
        if (s >= 58) R = 0;                         /* < 0.5 */
        else {
            uint64_t q = t >> s, rem = t & ((1ULL << s) - 1), half = 1ULL << (s - 1);
            if (rem > half || (rem == half && (q & 1))) q++;
            R = q;
        }
    }
    if (bits >> 63) *p++ = '-';
    /* digits of R with a '.' before the last one ("0.d" when R < 10) */
    char tmpd[24]; char *ep = tmpd + 24;
    while (R >= 100) { uint64_t q = R / 100; unsigned rr = (unsigned)(R - q * 100); ep -= 2; memcpy(ep, DIG2 + 2 * rr, 2); R = q; }
    ep -= 2; memcpy(ep, DIG2 + 2 * R, 2);                 /* R < 100: two digits, leading '0' kept */
    if (ep[0] == '0' && ep + 2 < tmpd + 24) ep++;          /* drop a leading zero unless it is the "0" of 0.d */
    size_t nd = (size_t)(tmpd + 24 - ep);
    memcpy(p, ep, nd - 1); p += nd - 1; *p++ = '.'; *p++ = ep[nd - 1];
    return p;
}
static void write_all(const char *p, size_t len) {
    while (len) { ssize_t w = write(1, p, len); if (w <= 0) { perror("write"); exit(1); } p += w; len -= (size_t)w; }
}
/* threads worth using for a phase of `work` items costing `ns_per_item`, given ~37 us per extra
 * thread (measured on a 2x96-core EPYC): T* = sqrt(work * cost / 37us), clamped to [1, available] */
static int g_T1 = 1;                              /* threads already created by phase 1 (reusable) */
#ifndef P1_NS
#define P1_NS 1.2            /* team-size rule constant (with P1_THREAD_US): T = sqrt(n*P1_NS/P1_THREAD_US);   */
#endif                       /* best measured with the AVX2 kernel too (ROMEO jobs 815794, 815802)            */
#ifndef P1_THREAD_US
#define P1_THREAD_US 67.0    /* one extra thread: ~37 us creation + ~30 us exit teardown */
#endif
#ifndef TF_MIN_LINES
#define TF_MIN_LINES 1024.0  /* result lines per format thread (8192 before r18; ROMEO job 815932) */
#endif
#ifndef TS_MIN_ITEMS
#define TS_MIN_ITEMS 1024.0  /* kept points per sorting thread (16384 before r18; ROMEO job 815932) */
#endif
static double g_tsmin = -1;
static int g_pretouch = 1;                       /* env QT_NOPRETOUCH=1 disables the arena first touch */
static int threads_for(double work, double ns_per_item, int avail) {
    double t = qt_sqrt(work * ns_per_item * 1e-9 / 37e-6);
    int T = (int)t; if (T < 1) T = 1; if (T > avail) T = avail;
    return T;
}
static double g_p1a = -1, g_p1c = -1;           /* ns per point, s per thread (env QT_P1A [ns], QT_P1C [us]) */
/* own team: the whole pipeline runs on the phase-1 team, so the team size also pays for the work after
 * phase 1, which scales with the kept points (~ n * relevant k-area): T = sqrt((n*a + kept*b) / c) */
#ifndef KEPT_NS
#define KEPT_NS 140.0        /* thread-ns per kept point for sort + build/query + format (ROMEO job 815852) */
#endif
static double g_keptns = -1;                     /* env QT_KEPTNS [ns] (0 = phase-1 rule only) */
static int team_threads(uint64_t n, double kept, int avail) {
    double a = g_p1a > 0 ? g_p1a * 1e-9 : P1_NS * 1e-9, c = g_p1c > 0 ? g_p1c * 1e-6 : P1_THREAD_US * 1e-6;
    double b = g_keptns >= 0 ? g_keptns * 1e-9 : KEPT_NS * 1e-9;
    double t = qt_sqrt(((double)n * a + kept * b) / c);
    int T = (int)t; if (T < 1) T = 1; if (T > avail) T = avail;
    return T;
}
/* later phases: threads already created by phase 1 are free to reuse */
static int reuse_threads(double work, double ns_per_item, double min_items, int avail) {
    int T = threads_for(work, ns_per_item, avail);
    int R = (int)(work / min_items); if (R > g_T1) R = g_T1;
    if (R > T) T = R;
    if (T < 1) T = 1;
    if (T > avail) T = avail;
    return T;
}
/* upper bound of one output line "(x,y)\n": printed points lie in the root rectangle, |v| < 10^k gives
 * at most 1 (sign) + k + 2 (".d") characters per value (|v| < 1e15 fast path, else the 48-byte default) */
static size_t line_bound(void) {
    double mx = dmax(dmax(fabs(C.map_boundaries.x_min), fabs(C.map_boundaries.x_max)), dmax(fabs(C.map_boundaries.y_min), fabs(C.map_boundaries.y_max)));
    if (!(mx < 1e15)) return 48;
    int k = 1; double p = 10.0; while (p <= mx + 1.0) { p *= 10.0; k++; }
    size_t b = (size_t)(4 + 2 * (k + 3));
    return b < 48 ? b : 48;
}
/* print the results stored as nsg slices res[start[i] .. start[i]+cnt[i]) in slice order */
typedef struct { const tpPoint *res; const size_t *start, *cnt, *pre; size_t nsg, m, per; int T; char *big; size_t *cap0; char **bufs; size_t *lens; } FmtCtx;
static void fmt_job(int tid, int nt, void *vp) {
    FmtCtx *F = (FmtCtx *)vp;
    for (int t = tid; t < F->T; t += nt) {
        size_t a = (size_t)t * F->per, b = a + F->per < F->m ? a + F->per : F->m;
        if (a >= b) continue;
        size_t lo = 0, hi = F->nsg;                     /* slice containing global index a */
        while (hi - lo > 1) { size_t mid = (lo + hi) / 2; if (F->pre[mid] <= a) lo = mid; else hi = mid; }
        size_t sg = lo, off = a - F->pre[lo];
        size_t cap = F->cap0[t], used = 0;
        char *buf = F->bufs[t];
        int own = 0;
        for (size_t g = a; g < b; g++) {
            while (off >= F->cnt[sg]) { sg++; off = 0; }
            const tpPoint *q = F->res + F->start[sg] + off; off++;
            if (cap - used < 1024) {                    /* slow path (huge |v|) can be long: grow privately */
                size_t nc = 2 * cap + 4096; char *nb = malloc(nc); memcpy(nb, buf, used);
                if (own) free(buf);
                buf = nb; cap = nc; own = 1;
            }
            char *p = buf + used;
            *p++ = '(';
            p = fmt1(p, q->x);
            *p++ = ',';
            p = fmt1(p, q->y);
            *p++ = ')'; *p++ = '\n';
            used = (size_t)(p - buf);
        }
        F->bufs[t] = buf; F->lens[t] = used;
    }
}
static void print_slices(const tpPoint *res, const size_t *start, const size_t *cnt, size_t nsg, size_t m) {
    fflush(stdout);
    if (m == 0) { write_all("Empty\n", 6); return; }
    int T = reuse_threads((double)m, 40.0, 8192.0, nthreads());
    size_t *pre = malloc(sizeof(size_t) * (nsg + 1));
    pre[0] = 0; for (size_t i = 0; i < nsg; i++) pre[i + 1] = pre[i] + cnt[i];
    size_t per = (m + T - 1) / T;
    size_t one = per * 48 + 1024;                       /* 48 B/line covers |v| < 1e15 */
    char *big = malloc(one * (size_t)T);
    char **bufs = malloc(sizeof(char *) * (size_t)T);
    size_t *lens = calloc((size_t)T, sizeof(size_t)), *cap0 = malloc(sizeof(size_t) * ((size_t)T + 1));
    for (int t = 0; t < T; t++) { bufs[t] = big + one * (size_t)t; cap0[t] = one; }
    cap0[T] = 0;
    FmtCtx F = { res, start, cnt, pre, nsg, m, per, T, big, cap0, bufs, lens };
    par_run(T, fmt_job, &F);
    for (int t = 0; t < T; t++) if (lens[t]) write_all(bufs[t], lens[t]);
}
static void print_results(const tpPoint *res, size_t m) { size_t z = 0; print_slices(res, &z, &m, 1, m); }

/* ------------------------------------------------------------------ generic path (any input) */
static void generic_path(void) {
    uint64_t n = C.n_points;
    tpPoint *A = malloc(sizeof(tpPoint) * (n + 1)), *B = malloc(sizeof(tpPoint) * (n + 1)), *res = malloc(sizeof(tpPoint) * (n + 1));
    size_t c = 0;
    tpRectangle root = C.map_boundaries;
    /* generation exactly as the reference: x = get_randon(); x *= (x_max - x_min); x += x_min */
    uint32_t W[31 + GEN_BLK]; uint64_t i = 0;
    if (use_emu) rng_window_for_output(0, W);
    while (i < n) {
        if (use_emu) rng_fill(W);
        for (int q = 0; q < GEN_BLK / 2 && i < n; q++, i++) {
            uint32_t kx = use_emu ? (W[31 + 2 * q] >> 1) % MAX_NORMA : KX[i];
            uint32_t ky = use_emu ? (W[32 + 2 * q] >> 1) % MAX_NORMA : KY[i];
            tpPoint p; p.x = fx(kx); p.y = fy(ky);
            if (point_in(root, p)) A[c++] = p;
            else printf("- (% 8.1lf, % 8.1lf) is not inserted ***\n", p.x, p.y);
        }
        if (use_emu) memcpy(W, W + GEN_BLK, 31 * sizeof(uint32_t));
    }
    size_t m = 0;
    build_node(root, A, B, c, res, &m, 1, 1, 0);
    print_results(res, m);
}

/* ------------------------------------------------------------------ fast path */
/* Level-D grid: the x-bounds of a node depend only on its x-path, so the 2^D x-cells (and y-cells)
 * of level D are consecutive intervals of k = rand()%1e6 (coordinates are monotone in k).
 * Phase 1 (parallel, LANES interleaved exact sub-streams, auto-vectorised): generate every point and
 * keep only those in the k-space bounding box of the relevant level-D cells (relevant = intercept()
 * true on the whole root path), then exact cell lookup.  Phase 2: for each relevant cell (DFS order),
 * top-down build of its subtree from its complete point list (generation order) + query. */
#define DMAX 9
typedef uint32_t v4u __attribute__((vector_size(16)));
#define LANES 16
#define ROWS 256             /* rand() values per lane per block (even); ring = (31+ROWS)*LANES*4 B = 18 KB (L1) */
static int D_;
static uint32_t *TXv, *TYv;                 /* thresholds, flat: level l at offset (1<<l)-1 */
static double *XLO, *XHI, *YLO, *YHI;       /* node extents, flat for levels 0..D */
static int32_t *relmap;                     /* cell (yj<<D | xj) -> rank in DFS order, -1 if pruned */
#define REL_GET(i) (relmap[(i)] - 1)            /* calloc'ed map: 0 = pruned, rank+1 otherwise */
#define REL_SET(i, v) (relmap[(i)] = (v) + 1)

typedef struct { int8_t l; int32_t xj, yj, parent; } RNode;
static RNode *rn; static size_t nrn, caprn;
static int32_t *cell_x, *cell_y; static size_t ncell;

static inline size_t LO(int l) { return ((size_t)1 << l) - 1; }
static void relevant_rec(int l, int32_t xj, int32_t yj, int32_t parent) {
    tpRectangle r = { XLO[LO(l) + xj], XHI[LO(l) + xj], YLO[LO(l) + yj], YHI[LO(l) + yj] };
    if (!intercept(r, C.sub_boundaries)) return;
    if (nrn == caprn) { caprn *= 2; rn = realloc(rn, caprn * sizeof(RNode)); }
    int32_t me = (int32_t)nrn;
    rn[nrn++] = (RNode){ (int8_t)l, xj, yj, parent };
    if (l == D_) {
        REL_SET(((size_t)yj << D_) | (size_t)xj, (int32_t)ncell);
        cell_x[ncell] = xj; cell_y[ncell] = yj; ncell++;
        return;
    }
    for (int c = 0; c < 4; c++)   /* NW, NE, SW, SE */
        relevant_rec(l + 1, 2 * xj + (c & 1), 2 * yj + ((c & 2) ? 0 : 1), me);
}
/* full mode (parallel generic path): every node down to level D and every level-D cell, in DFS order;
 * cell_emit[rank] = intercept() held on the whole path above the cell (the cell itself is re-checked) */
static int g_full = 0;
static uint8_t *cell_emit = NULL;
static void relevant_rec_full(int l, int32_t xj, int32_t yj, int32_t parent, int emit) {
    tpRectangle r = { XLO[LO(l) + xj], XHI[LO(l) + xj], YLO[LO(l) + yj], YHI[LO(l) + yj] };
    if (emit && !intercept(r, C.sub_boundaries)) emit = 0;
    if (nrn == caprn) { caprn *= 2; rn = realloc(rn, caprn * sizeof(RNode)); }
    int32_t me = (int32_t)nrn;
    rn[nrn++] = (RNode){ (int8_t)l, xj, yj, parent };
    if (l == D_) {
        REL_SET(((size_t)yj << D_) | (size_t)xj, (int32_t)ncell);
        cell_x[ncell] = xj; cell_y[ncell] = yj; cell_emit[ncell] = (uint8_t)emit; ncell++;
        return;
    }
    for (int c = 0; c < 4; c++)   /* NW, NE, SW, SE */
        relevant_rec_full(l + 1, 2 * xj + (c & 1), 2 * yj + ((c & 2) ? 0 : 1), me, emit);
}
static inline uint32_t xcell(uint32_t kx) { uint32_t j = 0; for (int l = 0; l < D_; l++) j = 2 * j + (kx >= TXv[LO(l) + j]); return j; }
static inline uint32_t ycell(uint32_t ky) { uint32_t j = 0; for (int l = 0; l < D_; l++) j = 2 * j + (ky >= TYv[LO(l) + j]); return j; }

typedef struct { uint64_t *v; size_t n, cap; } KVec;

/* the 31x31 matrix advancing a window by s values: row t = coefficients of x^(s+t) mod P */
static void adv_matrix(uint64_t s, uint32_t M[31][31]) {
    uint32_t res[31] = {0}, base[31] = {0};
    res[0] = 1; base[1] = 1;
    while (s) { if (s & 1) poly_mulmod(res, base, res); poly_mulmod(base, base, base); s >>= 1; }
    for (int t = 0; t < 31; t++) {
        memcpy(M[t], res, sizeof res);
        uint32_t carry = res[30];
        for (int i = 30; i > 0; i--) res[i] = res[i - 1];
        res[0] = carry; res[28] += carry;
    }
}

/* ------------------------------------------------------------------ fast-path parallel jobs */
static void *big_alloc(size_t sz) {
#if defined(__linux__) && defined(MADV_HUGEPAGE)
    /* 2 MB-aligned anonymous mapping + MADV_HUGEPAGE: with THP=madvise (Ubuntu's default) the big blocks get
     * huge pages as with THP=always; with 4 KB pages the exit teardown costs +0.4 ms at 1e8, +1.5 ms at 2e8
     * (ROMEO job 815932, prctl(PR_SET_THP_DISABLE)) */
    if (g_madv && sz >= ((size_t)2 << 20)) {
        size_t al = (size_t)2 << 20, len = (sz + al - 1) / al * al + al;
        char *p = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p != MAP_FAILED) { char *q = (char *)(((uintptr_t)p + al - 1) & ~(uintptr_t)(al - 1)); madvise(q, len - (size_t)(q - p), MADV_HUGEPAGE); return q; }   /* never freed */
    }
#endif
    return malloc(sz ? sz : 1);
}
typedef struct {
    uint64_t n, L; size_t nchunks; int D; uint32_t bx0, bxw, by0, byw;
    KVec *kv; uint32_t *rings; size_t ringsz; uint8_t *flagsall; uint32_t (*Madv)[31];
    char pad0[64]; ATOMIC_SIZE next; ATOMIC_SIZE finished; char pad1[64];   /* contended counters: own cache line */
} P1Ctx;
/* scalar processing of one candidate (point in the k-space box): exact cell lookup + keep */
static inline void p1_cand(P1Ctx *P, const uint32_t *ring, int q, int l, uint64_t blk, uint64_t s0) {
    uint64_t pos = blk * (ROWS / 2) + (uint64_t)q, idx = (s0 + (uint64_t)l) * P->L + pos;
    if (pos >= P->L || idx >= P->n) return;
    uint32_t kx = (ring[(31 + 2 * q) * LANES + l] >> 1) % 1000000u;
    uint32_t ky = (ring[(32 + 2 * q) * LANES + l] >> 1) % 1000000u;
    int32_t rid = REL_GET(((size_t)ycell(ky) << P->D) | xcell(kx));
    if (rid >= 0) {
        KVec *k = &P->kv[s0 + (uint64_t)l];
        if (k->n == k->cap) {   /* rare: pool slice full -> private heap copy */
            size_t nc = 2 * k->cap; uint64_t *nv = malloc(nc * sizeof(uint64_t));
            memcpy(nv, k->v, k->n * sizeof(uint64_t));   /* old block: pool or heap, left to exit */
            k->v = nv; k->cap = nc;
        }
        k->v[k->n++] = ((uint64_t)rid << 40) | ((uint64_t)kx << 20) | ky;
    }
}
#if defined(__x86_64__) && defined(__GNUC__) && !defined(NO_AVX2_PATH)
#include <immintrin.h>
#define HAVE_AVX2_PATH 1
static int g_avx2 = 0;
/* x mod 1e6 for 0 <= x < 2^31: q = (x*1125899907)>>50 is exact (e*x_max = 157376*2^31 < 2^50) */
__attribute__((target("avx2"))) static inline __m256i mod1e6_avx2(__m256i x) {
    const __m256i M = _mm256_set1_epi64x(1125899907LL);
    __m256i pe = _mm256_mul_epu32(x, M);                              /* lanes 0,2,4,6 */
    __m256i po = _mm256_mul_epu32(_mm256_srli_epi64(x, 32), M);       /* lanes 1,3,5,7 */
    __m256i q = _mm256_or_si256(_mm256_srli_epi64(pe, 50), _mm256_slli_epi64(_mm256_srli_epi64(po, 50), 32));
    return _mm256_sub_epi32(x, _mm256_mullo_epi32(q, _mm256_set1_epi32(1000000)));
}
/* 8-bit mask of lanes with (x,y) = (row values >> 1) % 1e6 inside the k-space box */
__attribute__((target("avx2"))) static inline unsigned box_avx2(__m256i x, __m256i y, __m256i BX0, __m256i BXW, __m256i BY0, __m256i BYW) {
    const __m256i MONE = _mm256_set1_epi32(-1);
    __m256i dx = _mm256_sub_epi32(mod1e6_avx2(_mm256_srli_epi32(x, 1)), BX0);
    __m256i dy = _mm256_sub_epi32(mod1e6_avx2(_mm256_srli_epi32(y, 1)), BY0);
    __m256i mx = _mm256_and_si256(_mm256_cmpgt_epi32(BXW, dx), _mm256_cmpgt_epi32(dx, MONE));   /* 0 <= dx < bxw */
    __m256i my = _mm256_and_si256(_mm256_cmpgt_epi32(BYW, dy), _mm256_cmpgt_epi32(dy, MONE));
    return (unsigned)_mm256_movemask_ps(_mm256_castsi256_ps(_mm256_and_si256(mx, my)));
}
/* x-only test (8-bit mask) for the y-skip kernel */
__attribute__((target("avx2"))) static inline unsigned xbox_avx2(__m256i x, __m256i BX0, __m256i BXW) {
    const __m256i MONE = _mm256_set1_epi32(-1);
    __m256i dx = _mm256_sub_epi32(mod1e6_avx2(_mm256_srli_epi32(x, 1)), BX0);
    return (unsigned)_mm256_movemask_ps(_mm256_castsi256_ps(_mm256_and_si256(_mm256_cmpgt_epi32(BXW, dx), _mm256_cmpgt_epi32(dx, MONE))));
}
static int g_yskip = 0;             /* y-skip variant measured slower (branch mispredictions, job 815808); QT_YSKIP=1 enables */
/* exact k-box test on the raw rand() word r (k = (r >> 1) % 1e6), no modulo: with M2 = ceil(2^52 / 2e6) and
 * j = r mod 2e6 = 2k + (r & 1), F = (r * M2) mod 2^52 = j * 2^52/2e6 + r * 0.3147... (no wrap), and
 * f = F >> 20 = floor(j * G + e), G = 2^32/2e6 = 2147.48, 0 <= e < 1289.4: the classes of j are separated, so
 * a <= k < a + w  <=>  Lo(a) <= f < Lo(a + w) with Lo(c) = floor(c * 2^32 / 1e6) (unsigned 32-bit, Lo(1e6) = 2^32) */
#define FRAC_M2 2251799814ULL
__attribute__((target("avx2"))) static inline __m256i frac_avx2(__m256i r) {
    const __m256i M = _mm256_set1_epi64x((long long)FRAC_M2);
    __m256i pe = _mm256_mul_epu32(r, M), po = _mm256_mul_epu32(_mm256_srli_epi64(r, 32), M);
    return _mm256_blend_epi32(_mm256_srli_epi64(_mm256_slli_epi64(pe, 12), 32), _mm256_slli_epi64(po, 12), 0xAA);
}
__attribute__((target("avx2"))) static inline __m256i frac_in(__m256i f, __m256i LO, __m256i WM1) {   /* (f - LO) <u (WM1 + 1) */
    __m256i d = _mm256_sub_epi32(f, LO);
    return _mm256_cmpeq_epi32(_mm256_min_epu32(d, WM1), d);
}
static inline uint32_t frac_lo(uint32_t c) { return c >= MAX_NORMA ? 0 : (uint32_t)(((uint64_t)c << 32) / MAX_NORMA); }
/* test parameters for k in [a, a + w): d = f - lo, inside <=> d <=u wm1; returns 0 for an empty range */
static inline int frac_params(uint32_t a, uint32_t w, uint32_t *lo, uint32_t *wm1) {
    if (w == 0) return 0;
    *lo = frac_lo(a);
    *wm1 = a + w >= MAX_NORMA ? (uint32_t)(0u - *lo) - 1u : frac_lo(a + w) - *lo - 1u;   /* full axis: 2^32 - 1 */
    return 1;
}
__attribute__((target("avx2"))) static void p1_block_frac(P1Ctx *P, uint32_t *ring, uint64_t blk, uint64_t s0) {
    uint32_t lx = 0, ly = 0, wx = 0, wy = 0;
    int any = frac_params(P->bx0, P->bxw, &lx, &wx) & frac_params(P->by0, P->byw, &ly, &wy);   /* empty box: rows only */
    const __m256i LX = _mm256_set1_epi32((int)lx), WX = _mm256_set1_epi32((int)wx), LY = _mm256_set1_epi32((int)ly), WY = _mm256_set1_epi32((int)wy);
    __m256i *R = (__m256i *)ring;
    for (int q = 0; q < ROWS / 2; q++) {
        int r = 31 + 2 * q;
        __m256i x0 = _mm256_add_epi32(R[2 * (r - 31)], R[2 * (r - 3)]);
        __m256i x1 = _mm256_add_epi32(R[2 * (r - 31) + 1], R[2 * (r - 3) + 1]);
        __m256i y0 = _mm256_add_epi32(R[2 * (r - 30)], R[2 * (r - 2)]);
        __m256i y1 = _mm256_add_epi32(R[2 * (r - 30) + 1], R[2 * (r - 2) + 1]);
        R[2 * r] = x0; R[2 * r + 1] = x1; R[2 * r + 2] = y0; R[2 * r + 3] = y1;
        __m256i m0 = _mm256_and_si256(frac_in(frac_avx2(x0), LX, WX), frac_in(frac_avx2(y0), LY, WY));
        __m256i m1 = _mm256_and_si256(frac_in(frac_avx2(x1), LX, WX), frac_in(frac_avx2(y1), LY, WY));
        unsigned m = any ? (unsigned)_mm256_movemask_ps(_mm256_castsi256_ps(m0)) | ((unsigned)_mm256_movemask_ps(_mm256_castsi256_ps(m1)) << 8) : 0;
        while (m) { int l = __builtin_ctz(m); m &= m - 1; p1_cand(P, ring, q, l, blk, s0); }
    }
}
/* one block of ROWS values per lane: fused generation (r = r-31 + r-3) and box test, 16 lanes = 2 x 256 bit */
__attribute__((target("avx2"))) static void p1_block_avx2(P1Ctx *P, uint32_t *ring, uint64_t blk, uint64_t s0) {
    const __m256i BX0 = _mm256_set1_epi32((int)P->bx0), BXW = _mm256_set1_epi32((int)P->bxw);
    const __m256i BY0 = _mm256_set1_epi32((int)P->by0), BYW = _mm256_set1_epi32((int)P->byw);
    __m256i *R = (__m256i *)ring;   /* row r = R[2r], R[2r+1] */
    for (int q = 0; q < ROWS / 2; q++) {
        int r = 31 + 2 * q;
        __m256i x0 = _mm256_add_epi32(R[2 * (r - 31)], R[2 * (r - 3)]);
        __m256i x1 = _mm256_add_epi32(R[2 * (r - 31) + 1], R[2 * (r - 3) + 1]);
        __m256i y0 = _mm256_add_epi32(R[2 * (r - 30)], R[2 * (r - 2)]);
        __m256i y1 = _mm256_add_epi32(R[2 * (r - 30) + 1], R[2 * (r - 2) + 1]);
        R[2 * r] = x0; R[2 * r + 1] = x1; R[2 * r + 2] = y0; R[2 * r + 3] = y1;
        unsigned m;
        if (g_yskip) {   /* the y test is only needed where some x is in the box (exact: same predicate) */
            unsigned m0 = xbox_avx2(x0, BX0, BXW), m1 = xbox_avx2(x1, BX0, BXW);
            if (m0) m0 &= box_avx2(x0, y0, BX0, BXW, BY0, BYW);
            if (m1) m1 &= box_avx2(x1, y1, BX0, BXW, BY0, BYW);
            m = m0 | (m1 << 8);
        } else m = box_avx2(x0, y0, BX0, BXW, BY0, BYW) | (box_avx2(x1, y1, BX0, BXW, BY0, BYW) << 8);
        while (m) { int l = __builtin_ctz(m); m &= m - 1; p1_cand(P, ring, q, l, blk, s0); }
    }
}
#endif
static void phase1_job(int tid, int nt, void *vp) {
    (void)nt;
    P1Ctx *P = (P1Ctx *)vp;
    const uint64_t n = P->n, L = P->L; const int D = P->D;
    const uint32_t bx0 = P->bx0, bxw = P->bxw, by0 = P->by0, byw = P->byw;
    uint32_t *ring = P->rings + P->ringsz * (size_t)tid;
    uint8_t *flags = P->flagsall + (size_t)(ROWS / 2) * LANES * (size_t)tid;
    for (;;) {
        size_t ch = FETCH_ADD(&P->next, 1);
        if (ch >= P->nchunks) break;
        uint64_t s0 = ch * LANES;
        uint64_t nblk = (L + ROWS / 2 - 1) / (ROWS / 2);
        if (use_emu) {
            uint32_t w[31], w2[31];
            rng_window_for_output(2 * s0 * L, w);
            for (int l = 0; l < LANES; l++) {
                for (int t = 0; t < 31; t++) ring[t * LANES + l] = w[t];
                for (int t = 0; t < 31; t++) { uint32_t s = 0; for (int i = 0; i < 31; i++) s += P->Madv[t][i] * w[i]; w2[t] = s; }
                memcpy(w, w2, sizeof w);
            }
        }
#ifdef HAVE_AVX2_PATH
        if (use_emu && g_avx2) {
            for (uint64_t blk = 0; blk < nblk; blk++) {
                if (g_p1k == 2) p1_block_frac(P, ring, blk, s0); else
                p1_block_avx2(P, ring, blk, s0);
                memcpy(ring, ring + ROWS * LANES, sizeof(uint32_t) * 31 * LANES);
            }
            FETCH_ADD(&P->finished, 1);
            continue;
        }
#endif
        for (uint64_t blk = 0; blk < nblk; blk++) {
            if (use_emu) {
                for (int r = 31; r < 31 + ROWS; r++)
                    for (int l = 0; l < LANES / 4; l++)   /* explicit 128-bit vectors (GCC/clang vector extension) */
                        ((v4u *)ring)[r * (LANES / 4) + l] = ((v4u *)ring)[(r - 31) * (LANES / 4) + l] + ((v4u *)ring)[(r - 3) * (LANES / 4) + l];
            } else {   /* real rand() values from arrays (non-glibc libc) */
                for (int q = 0; q < ROWS / 2; q++)
                    for (int l = 0; l < LANES; l++) {
                        uint64_t idx = (s0 + l) * L + blk * (ROWS / 2) + q;
                        uint32_t a = 0, b = 0;
                        if (blk * (ROWS / 2) + q < L && idx < n) { a = KX[idx] << 1; b = KY[idx] << 1; }
                        ring[(31 + 2 * q) * LANES + l] = a; ring[(32 + 2 * q) * LANES + l] = b;
                    }
            }
            const uint32_t *rg = ring + 31 * LANES;
            for (int q = 0; q < ROWS / 2; q++)
                for (int l = 0; l < LANES; l++) {
                    uint32_t kx = (rg[(2 * q) * LANES + l] >> 1) % 1000000u;
                    uint32_t ky = (rg[(2 * q + 1) * LANES + l] >> 1) % 1000000u;
                    flags[q * LANES + l] = (uint8_t)((kx - bx0 < bxw) & (ky - by0 < byw));
                }
            for (int q = 0; q < ROWS / 2; q++) {
                uint64_t w0, w1; memcpy(&w0, flags + q * LANES, 8); memcpy(&w1, flags + q * LANES + 8, 8);
                if (!(w0 | w1)) continue;
                for (int l = 0; l < LANES; l++) {
                    if (!flags[q * LANES + l]) continue;
                    uint64_t pos = blk * (ROWS / 2) + q, idx = (s0 + l) * L + pos;
                    if (pos >= L || idx >= n) continue;
                    uint32_t kx = (rg[(2 * q) * LANES + l] >> 1) % 1000000u;
                    uint32_t ky = (rg[(2 * q + 1) * LANES + l] >> 1) % 1000000u;
                    int32_t rid = REL_GET(((size_t)ycell(ky) << D) | xcell(kx));
                    if (rid >= 0) {
                        KVec *k = &P->kv[s0 + l];
                        if (k->n == k->cap) {   /* rare: pool slice full -> private heap copy */
                            size_t nc = 2 * k->cap; uint64_t *nv = malloc(nc * sizeof(uint64_t));
                            memcpy(nv, k->v, k->n * sizeof(uint64_t));   /* old block: pool or heap, left to exit */
                            k->v = nv; k->cap = nc;
                        }
                        k->v[k->n++] = ((uint64_t)rid << 40) | ((uint64_t)kx << 20) | ky;
                    }
                }
            }
            if (use_emu) memcpy(ring, ring + ROWS * LANES, sizeof(uint32_t) * 31 * LANES);
        }
        FETCH_ADD(&P->finished, 1);
    }
}
typedef struct { KVec *kv; size_t *sfirst; uint32_t *hist; uint64_t *cellcnt; size_t *base; size_t RD; int TS; tpPoint *A; uint32_t *I; uint64_t L; } SortCtx;
static void hist_job(int tid, int nt, void *vp) {
    SortCtx *S = (SortCtx *)vp;
    for (int t = tid; t < S->TS; t += nt) {
        uint32_t *h = S->hist + (size_t)t * S->RD;
        memset(h, 0, sizeof(uint32_t) * S->RD);
        for (size_t s = S->sfirst[t]; s < S->sfirst[t + 1]; s++) for (size_t i = 0; i < S->kv[s].n; i++) h[S->kv[s].v[i] >> 40]++;
    }
}
static void cellcnt_job(int tid, int nt, void *vp) {
    SortCtx *S = (SortCtx *)vp;
    size_t a = S->RD * (size_t)tid / (size_t)nt, b = S->RD * (size_t)(tid + 1) / (size_t)nt;
    for (size_t c = a; c < b; c++) { uint64_t sum = 0; for (int t2 = 0; t2 < S->TS; t2++) sum += S->hist[(size_t)t2 * S->RD + c]; S->cellcnt[c] = sum; }
}
static void offsets_job(int tid, int nt, void *vp) {
    SortCtx *S = (SortCtx *)vp;
    size_t a = S->RD * (size_t)tid / (size_t)nt, b = S->RD * (size_t)(tid + 1) / (size_t)nt;
    for (size_t c = a; c < b; c++) { uint32_t o = (uint32_t)S->base[c]; for (int t2 = 0; t2 < S->TS; t2++) { uint32_t v = S->hist[(size_t)t2 * S->RD + c]; S->hist[(size_t)t2 * S->RD + c] = o; o += v; } }
}
static void scatter_job(int tid, int nt, void *vp) {
    SortCtx *S = (SortCtx *)vp;
    for (int t = tid; t < S->TS; t += nt) {
        uint32_t *h = S->hist + (size_t)t * S->RD;
        for (size_t s = S->sfirst[t]; s < S->sfirst[t + 1]; s++)
            for (size_t i = 0; i < S->kv[s].n; i++) {
                uint64_t v = S->kv[s].v[i];
                tpPoint p; p.x = fx((uint32_t)((v >> 20) & 0xFFFFF)); p.y = fy((uint32_t)(v & 0xFFFFF));
                uint32_t o = h[v >> 40]++;
                S->A[o] = p;
                if (S->I) S->I[o] = (uint32_t)(s * S->L + i);   /* full mode: every point kept -> generation index */
            }
    }
}
typedef struct {
    tpPoint *A, *tmp; size_t tmpstride; tpPoint *res; size_t *base, *rc; size_t RD; int D; uint32_t *I, *itmp;
    char pad0[64]; ATOMIC_SIZE next; char pad1[64];   /* contended cell counter: own cache line */
} P2Ctx;
/* full mode: build of EVERY node (the reference builds the whole tree), printing only the query part, with
 * the reference's failures detected instead of executed.  A node N that receives >= 5 points subdivides when
 * its 5th point (generation order) is inserted; the reference dies at that insertion if N is degenerate
 * (float extent < MAX_ERROR: assert) or if one child equals N and gets all its points (endless recursion,
 * stack overflow).  The earliest such insertion over the whole tree decides the outcome: g_fail keeps
 * min(trigger << 2 | type), type 1 = assert, 2 = endless recursion. */
static _Atomic uint64_t g_fail = UINT64_MAX;
static void fail_record(uint64_t trig, int type) {
    uint64_t v = (trig << 2) | (uint64_t)type, cur = atomic_load_explicit(&g_fail, memory_order_relaxed);
    while (v < cur && !atomic_compare_exchange_weak_explicit(&g_fail, &cur, v, memory_order_relaxed, memory_order_relaxed)) { }
}
static void build_full(tpRectangle b, tpPoint *a, uint32_t *ia, tpPoint *t, uint32_t *it, size_t c, tpPoint *out, size_t *r, int emit) {
    if (emit && !intercept(b, C.sub_boundaries)) emit = 0;
    if (c <= MAX_CHILDREN) {
        if (emit) for (size_t i = 0; i < c; i++) if (point_in(C.sub_boundaries, a[i])) out[(*r)++] = a[i];
        return;
    }
    uint64_t trig = ia[4];   /* lists stay in generation order: the 5th point triggers the subdivision */
    if ((trig << 2) >= atomic_load_explicit(&g_fail, memory_order_relaxed)) return;   /* an earlier failure exists: output is void */
    double d = fabsf(b.x_max - b.x_min);
    if (d < MAX_ERROR) { fail_record(trig, 1); return; }
    d = fabsf(b.y_max - b.y_min);
    if (d < MAX_ERROR) { fail_record(trig, 1); return; }
    double x_ave = (b.x_min + b.x_max) / 2.0;
    double y_ave = (b.y_min + b.y_max) / 2.0;
    size_t cnt[4] = {0, 0, 0, 0};
    for (size_t i = 0; i < c; i++) cnt[(a[i].y < y_ave ? 2 : 0) + (a[i].x > x_ave ? 1 : 0)]++;
    for (int ch = 0; ch < 4; ch++) if (cnt[ch] == c) {
        tpRectangle cr = child_rect(&b, ch, x_ave, y_ave);
        if (cr.x_min == b.x_min && cr.x_max == b.x_max && cr.y_min == b.y_min && cr.y_max == b.y_max) { fail_record(trig, 2); return; }
    }
    size_t off[4] = {0, cnt[0], cnt[0] + cnt[1], cnt[0] + cnt[1] + cnt[2]}, pos[4];
    memcpy(pos, off, sizeof pos);
    for (size_t i = 0; i < c; i++) { int ch = (a[i].y < y_ave ? 2 : 0) + (a[i].x > x_ave ? 1 : 0); size_t o = pos[ch]++; t[o] = a[i]; it[o] = ia[i]; }
    for (int ch = 0; ch < 4; ch++)
        build_full(child_rect(&b, ch, x_ave, y_ave), t + off[ch], it + off[ch], a + off[ch], ia + off[ch], cnt[ch], out, r, emit);
}
/* end the program as the reference would (assert -> SIGABRT; endless recursion -> stack overflow, SIGSEGV) */
static void reproduce_failure(uint64_t f) {
    fflush(stdout);
    if ((f & 3) == 1) { fprintf(stderr, "qt: qt.c: insert_point_quadtree: Assertion `ret >= 0' failed.\n"); abort(); }
    fprintf(stderr, "quadtree: unbounded subdivision (reference overflows its stack)\n");
    raise(SIGSEGV); abort();
}
static void phase2_job(int tid, int nt, void *vp) {
    (void)nt;
    P2Ctx *Q = (P2Ctx *)vp;
    for (;;) {
        size_t c = FETCH_ADD(&Q->next, 1);
        if (c >= Q->RD) break;
        size_t px = LO(Q->D) + (size_t)cell_x[c], py = LO(Q->D) + (size_t)cell_y[c];
        tpRectangle b = { XLO[px], XHI[px], YLO[py], YHI[py] };
        size_t r = 0;
        tpPoint *tmp = Q->tmpstride ? Q->tmp + Q->tmpstride * (size_t)tid : Q->tmp + Q->base[c];
        if (Q->I) {
            build_full(b, Q->A + Q->base[c], Q->I + Q->base[c], tmp, Q->itmp + Q->tmpstride * (size_t)tid,
                       Q->base[c + 1] - Q->base[c], Q->res + Q->base[c], &r, cell_emit[c]);
            Q->rc[c] = r;
            continue;
        }
        build_node(b, Q->A + Q->base[c], tmp, Q->base[c + 1] - Q->base[c], Q->res + Q->base[c], &r, 1, 0, Q->D);
        Q->rc[c] = r;
    }
}

/* ------------------------------------------------------------------ own fused team
 * The master creates T-1 detached pthreads (small stacks, optionally bound at creation through the
 * attribute: no self-migration, no inherited one-CPU mask), every thread runs fused_body() (phase 1
 * starts at once, dynamic chunks), steps are separated by a spinning sense barrier, and each worker
 * leaves as soon as its last step is done, so the threads are gone (or going) when the master exits.
 * env QT_BIND: 2 (default) master + workers on the allowed CPUs in order ("close" from the first),
 *              1 workers only (skip the master's current CPU), 0 no binding.
 * env QT_WEXIT: 1 (default) worker ends with a direct SYS_exit, 0 return from the start routine. */
#include <sys/syscall.h>
#ifndef TEAM_STACK
#define TEAM_STACK (256 * 1024)
#endif
typedef struct FusedCtx {
    P1Ctx *P; KVec *kv; size_t nseg, *soff, tot, maxcell, m, *sfirst, *base, *rc, *fpre, RD;
    uint32_t *hist; uint64_t *cellcnt; tpPoint *A, *scratch;
    int TS, ok, TF, T1, D; uint64_t n;
    SortCtx S; P2Ctx Q2; FmtCtx Fm; char *fbig; char **fbufs; size_t *flens, *fcap0;
    char *arena; size_t szA, szF, lb; double tp;
    uint32_t *I, *itmp; uint64_t L, fail;
    uint64_t *pool; size_t poolsz; int efree; long flt0, flt1, fltpages;
} FusedCtx;
static struct {
    _Atomic unsigned cnt; char p0[60];
    _Atomic unsigned gen; char p1[60];
    _Atomic int ntf; char p2[60];
    _Atomic int done; char p3[60];
    FusedCtx *ctx;
} g_team;
static int g_bind = 2, g_wexit = 1, g_team_ncpu = -1, *g_team_cpus = NULL, g_smt_k = 1, g_smt_s = 0, g_smt_used = 0;
static int *g_smt_cpus = NULL, *g_team_assigned = NULL;   /* SMT-reordered list; CPU given to each rank */
static _Atomic int g_smt_ready = 0;                      /* 0 not read yet, 1 g_smt_cpus valid, 2 not used */
static size_t g_team_stack = TEAM_STACK;
/* minor faults of the calling thread: the master's slice of the arena first touch costs one fault per 2 MB
 * with transparent huge pages and one per 4 KB without them (THP=never, disabled, or not madvised).
 * RUSAGE_THREAD: RUSAGE_SELF walks every thread (+0.2 ms at 68 threads, ROMEO job 815937) */
static long minflt_thread(void) {
#ifdef RUSAGE_THREAD
    struct rusage ru; return getrusage(RUSAGE_THREAD, &ru) == 0 ? ru.ru_minflt : 0;
#else
    return 0;
#endif
}
static void team_barrier(int nt) {
    unsigned g = atomic_load_explicit(&g_team.gen, memory_order_acquire);
    if (atomic_fetch_add_explicit(&g_team.cnt, 1, memory_order_acq_rel) == (unsigned)nt - 1) {
        atomic_store_explicit(&g_team.cnt, 0, memory_order_relaxed);
        atomic_store_explicit(&g_team.gen, g + 1, memory_order_release);
    } else while (atomic_load_explicit(&g_team.gen, memory_order_acquire) == g) CPU_RELAX();
}
static int team_size(void) {   /* final team size, published by the master once all creations are done */
    int v; while ((v = atomic_load_explicit(&g_team.ntf, memory_order_acquire)) == 0) CPU_RELAX();
    return v;
}
static void fused_body(int tid, FusedCtx *F) {
    phase1_job(tid, F->T1, F->P);
    const int nt = team_size();
    team_barrier(nt);
    if (tid == 0) {
        PROF("phase1 gen+filter", F->tp);
        g_T1 = nt;
        size_t tot = 0, nseg = F->nseg, *soff = F->soff, RD = F->RD;
        for (size_t s = 0; s < nseg; s++) { soff[s] = tot; tot += F->kv[s].n; }
        soff[nseg] = tot; F->tot = tot;
        int TS = (int)(tot / (g_tsmin > 0 ? g_tsmin : TS_MIN_ITEMS));
        if (TS > nt) TS = nt;
        if ((size_t)TS * RD > ((size_t)8 << 20)) TS = (int)(((size_t)8 << 20) / RD);   /* histogram <= 32 MB */
        if (TS < 1) TS = 1;
        F->TS = TS;
        size_t *sfirst = malloc(sizeof(size_t) * (TS + 1));
        { size_t s = 0; for (int t = 0; t <= TS; t++) { size_t target = (size_t)((double)tot * t / TS); while (s < nseg && soff[s + 1] <= target && t < TS) s++; sfirst[t] = (t == TS) ? nseg : s; } sfirst[0] = 0; }
        for (int t = 1; t <= TS; t++) if (sfirst[t] < sfirst[t - 1]) sfirst[t] = sfirst[t - 1];
        F->sfirst = sfirst;
        F->hist = malloc(sizeof(uint32_t) * (size_t)TS * RD);
        F->cellcnt = malloc(sizeof(uint64_t) * RD);
        F->base = malloc(sizeof(size_t) * (RD + 1));
        F->S = (SortCtx){ F->kv, sfirst, F->hist, F->cellcnt, F->base, RD, TS, NULL, NULL, F->L };
        F->lb = line_bound();
        F->szA = (sizeof(tpPoint) * (tot + 1) + 4095) & ~(size_t)4095;
        if (g_full) {   /* points + generation indices; the text buffer is sized later from the result count */
            if (tot != F->n) F->ok = 0;   /* every point must have been kept (never happens) */
            F->szF = (sizeof(uint32_t) * (tot + 1) + 4095) & ~(size_t)4095;
        } else F->szF = tot * F->lb + (size_t)nt * (F->lb + 1024) + 4096;
        F->arena = big_alloc(F->szA + F->szF);
        F->A = (tpPoint *)F->arena; F->fbig = F->arena + F->szA;
        if (g_full) { F->I = (uint32_t *)(F->arena + F->szA); F->S.I = F->I; F->fbig = NULL; }
    }
    team_barrier(nt);
    if (g_pretouch) {   /* page-granular first touch, each thread its own slice */
        size_t tot_sz = F->szA + F->szF, per = ((tot_sz / (size_t)nt) + 4095) & ~(size_t)4095;
        size_t a0 = per * (size_t)tid, a1 = a0 + per < tot_sz ? a0 + per : tot_sz;
        long f0 = (tid == 0 && g_earlyfree < 0) ? minflt_thread() : 0;
        for (size_t o = a0; o < a1; o += 4096) F->arena[o] = 0;
        if (tid == 0 && g_earlyfree < 0) { F->flt0 = f0; F->flt1 = minflt_thread(); F->fltpages = (long)((a1 > a0 ? a1 - a0 : 0) >> 12); }
    }
    hist_job(tid, nt, &F->S);
    team_barrier(nt);
    cellcnt_job(tid, nt, &F->S);
    team_barrier(nt);
    if (tid == 0) {   /* validate: every relevant node above level D has >= 5 points (lower bound = kept below it) */
        PROF("  sort: segments+hist+cellcnt", F->tp);
        const int D = F->D; size_t RD = F->RD; uint64_t *cellcnt = F->cellcnt;
        uint64_t *rcnt = calloc(nrn, sizeof(uint64_t));
        for (size_t i = 0; i < nrn; i++) if (rn[i].l == D) rcnt[i] = cellcnt[REL_GET(((size_t)rn[i].yj << D) | (size_t)rn[i].xj)];
        for (size_t i = nrn; i-- > 1;) rcnt[rn[i].parent] += rcnt[i];
        for (size_t i = 0; i < nrn; i++) if (rn[i].l < D && rcnt[i] < 5) F->ok = 0;
        if (F->ok) {
            size_t acc = 0, maxcell = 0, *base = F->base;
            for (size_t c = 0; c < RD; c++) { base[c] = acc; acc += cellcnt[c]; if (cellcnt[c] > maxcell) maxcell = cellcnt[c]; } base[RD] = acc;
            F->maxcell = maxcell;
            F->S.A = F->A;
            F->scratch = big_alloc(sizeof(tpPoint) * (maxcell + 1) * (size_t)nt);
            F->rc = calloc(RD, sizeof(size_t));
            F->Q2 = (P2Ctx){ .A = F->A, .tmp = F->scratch, .tmpstride = maxcell + 1, .res = F->A, .base = base, .rc = F->rc, .RD = RD, .D = D };   /* results in place (LEAN_MEM) */
            if (g_full) { F->itmp = big_alloc(sizeof(uint32_t) * (maxcell + 1) * (size_t)nt); F->Q2.I = F->I; F->Q2.itmp = F->itmp; }
        }
    }
    team_barrier(nt);
    if (!F->ok) return;
    if (g_prof) { if (tid == 0) PROF("  sort: validate+alloc", F->tp); team_barrier(nt); }
    offsets_job(tid, nt, &F->S);
    team_barrier(nt);
    if (g_prof) { if (tid == 0) PROF("  sort: offsets", F->tp); team_barrier(nt); }
    scatter_job(tid, nt, &F->S);
    team_barrier(nt);
    if (g_prof) {
        if (tid == 0) {
            PROF("sort kept by cell", F->tp);
            fprintf(stderr, "  kept points: %zu (%.3f%% of n), sort threads=%d of %d\n", F->tot, 100.0 * F->tot / (F->n ? F->n : 1), F->TS, nt);
        }
        team_barrier(nt);
    }
    phase2_job(tid, nt, &F->Q2);
    team_barrier(nt);
    if (g_full) {   /* a reference failure anywhere: nothing to print, the master reproduces it */
        if (tid == 0) F->fail = atomic_load(&g_fail);
        team_barrier(nt);
        if (F->fail != UINT64_MAX) return;
    }
    if (tid == 0) {
        size_t RD = F->RD, m = 0, *rc = F->rc;
        for (size_t c = 0; c < RD; c++) m += rc[c];
        F->m = m;
        PROF("phase2 build+query", F->tp);
        int TF = (int)(m / (g_tfmin > 0 ? g_tfmin : TF_MIN_LINES)); if (TF > nt) TF = nt;
        if (TF < 1) TF = 1;
        F->TF = TF;
        if (m) {
            size_t *fpre = malloc(sizeof(size_t) * (RD + 1));
            fpre[0] = 0; for (size_t i = 0; i < RD; i++) fpre[i + 1] = fpre[i] + rc[i];
            size_t per = (m + TF - 1) / TF, one = per * F->lb + 1024;   /* TF*one <= szF (TF <= nt, m <= tot) */
            if (g_full) F->fbig = big_alloc(one * (size_t)TF);
            char **fbufs = malloc(sizeof(char *) * (size_t)TF);
            size_t *flens = calloc((size_t)TF, sizeof(size_t)), *fcap0 = malloc(sizeof(size_t) * ((size_t)TF + 1));
            for (int t = 0; t < TF; t++) { fbufs[t] = F->fbig + one * (size_t)t; fcap0[t] = one; }
            fcap0[TF] = 0;
            F->fpre = fpre; F->fbufs = fbufs; F->flens = flens; F->fcap0 = fcap0;
            F->Fm = (FmtCtx){ F->A, F->base, rc, fpre, RD, m, per, TF, F->fbig, fcap0, fbufs, flens };
        }
        /* 4 KB pages (no THP): releasing the dead points and pool in parallel shortens the serial exit
         * (-0.4 ms at 1e8, -1.0 ms at 2e8); with huge pages it costs more than it saves (ROMEO job 815934) */
        F->efree = g_earlyfree >= 0 ? g_earlyfree : (nt > 1 && F->fltpages > 0 && F->flt1 - F->flt0 > F->fltpages / 4);
        if (g_prof) fprintf(stderr, "  early release: %d (master first-touch faults %ld for %ld pages)\n", F->efree, F->flt1 - F->flt0, F->fltpages);
    }
    team_barrier(nt);
    if (F->m) fmt_job(tid, nt, &F->Fm);
#ifdef __linux__
    if (F->efree) {   /* dead points and segment pool released in parallel before the exit (4 KB pages) */
        team_barrier(nt);
        char *rg[2] = { F->arena, (char *)F->pool }; size_t ln[2] = { F->szA, F->poolsz };
        for (int k = 0; k < 2; k++) {
            uintptr_t lo = ((uintptr_t)rg[k] + 4095) & ~(uintptr_t)4095, hi = ((uintptr_t)rg[k] + ln[k]) & ~(uintptr_t)4095;
            if (!rg[k] || hi <= lo) continue;
            size_t pg = (hi - lo) >> 12, p0 = pg * (size_t)tid / (size_t)nt, p1 = pg * (size_t)(tid + 1) / (size_t)nt;
            if (p1 > p0) madvise((void *)(lo + (p0 << 12)), (p1 - p0) << 12, MADV_DONTNEED);
        }
    }
#endif
}
static void smt_worker_step(void);
static void *team_worker(void *a) {
    if ((int)(intptr_t)a == 1) smt_worker_step();
    fused_body((int)(intptr_t)a, g_team.ctx);
    atomic_fetch_add_explicit(&g_team.done, 1, memory_order_release);   /* nothing shared is touched after this */
#if defined(__linux__) && defined(SYS_exit)
    /* ends this worker thread only (process exit is exit_group), skipping glibc's per-thread teardown;
     * nothing shared is touched after g_team.done, and the master waits for every worker */
    if (g_wexit) syscall(SYS_exit, 0);
#endif
    return NULL;
}
#ifdef __linux__
#include <fcntl.h>
/* SMT: the team takes one hardware thread per core first.  Linux lists the siblings of a CPU in
 * <cpu dir>/cpuN/topology/thread_siblings_list ("0,128" when siblings are numbered after all cores,
 * "0-1" when they are adjacent).  The pattern {c, c+s, ..., c+(k-1)s} is read for the first allowed CPU
 * and checked on the last one (two small reads); the hardware-thread rank of CPU c is then (c / s) % k and
 * the allowed list is reordered by rank (stable).  No file or an irregular pattern: list order is kept.
 * The resulting placement is that of OMP_PROC_BIND=close; only this process's own threads are bound.
 * env QT_SYSFS_CPU replaces /sys/devices/system/cpu (tests only). */
static int read_siblings(const char *dir, int cpu, int *out, int maxn) {
    char path[512]; snprintf(path, sizeof path, "%s/cpu%d/topology/thread_siblings_list", dir, cpu);
    int fd = open(path, O_RDONLY | O_CLOEXEC); if (fd < 0) return 0;
    char buf[1024]; ssize_t r = read(fd, buf, sizeof buf - 1); close(fd);
    if (r <= 0) return 0;
    buf[r] = 0;
    int k = 0; char *q = buf;
    while (*q && *q != '\n' && k < maxn) {
        char *e; long a = strtol(q, &e, 10); if (e == q || a < 0) return 0;
        long b = a; if (*e == '-') { q = e + 1; b = strtol(q, &e, 10); if (e == q || b < a) return 0; }
        for (long v = a; v <= b && k < maxn; v++) out[k++] = (int)v;
        q = e; if (*q == ',') q++;
        else if (*q && *q != '\n') return 0;
    }
    return k;
}
static int smt_pattern_ok(const int *sb, int k, int s, int cpu) {
    int found = 0;
    for (int i = 0; i < k; i++) { if (sb[i] != sb[0] + i * s || (sb[i] / s) % k != i) return 0; if (sb[i] == cpu) found = 1; }
    return found;
}
static void smt_reorder(void) {   /* result: g_smt_cpus (published by g_smt_ready = 1) or g_smt_ready = 2 */
    if (g_team_ncpu < 2) return;
    const char *dir = getenv("QT_SYSFS_CPU"); if (!dir) dir = "/sys/devices/system/cpu";
    int sb[64], sb2[64];
    int k = read_siblings(dir, g_team_cpus[0], sb, 64);
    if (k < 2) return;                                    /* no SMT (or no sysfs): keep the order */
    int s = sb[1] - sb[0];
    if (s <= 0 || !smt_pattern_ok(sb, k, s, g_team_cpus[0])) return;
    int last = g_team_cpus[g_team_ncpu - 1];
    if (read_siblings(dir, last, sb2, 64) != k || !smt_pattern_ok(sb2, k, s, last)) return;
    int *o = malloc(sizeof(int) * (size_t)g_team_ncpu), n = 0;
    for (int rk = 0; rk < k; rk++) for (int i = 0; i < g_team_ncpu; i++) if ((g_team_cpus[i] / s) % k == rk) o[n++] = g_team_cpus[i];
    if (n == g_team_ncpu) { g_smt_cpus = o; g_smt_k = k; g_smt_s = s; g_smt_used = 1; }
    else free(o);
}
#endif
static void team_cpus_init(void) {
    if (g_team_ncpu >= 0) return;
    g_team_ncpu = 0;
#ifdef __linux__
    cpu_set_t cs; CPU_ZERO(&cs);
    if (sched_getaffinity(0, sizeof cs, &cs) != 0) return;
    g_team_cpus = malloc(sizeof(int) * CPU_SETSIZE);
    for (int c = 0; c < CPU_SETSIZE; c++) if (CPU_ISSET(c, &cs)) g_team_cpus[g_team_ncpu++] = c;
    if (getenv("QT_NOSMT")) atomic_store(&g_smt_ready, 2);
#endif
}
/* worker 1 reads the SMT pattern while the master goes on creating workers (in list order until it is ready) */
static void smt_worker_step(void) {
#ifdef __linux__
    if (atomic_load_explicit(&g_smt_ready, memory_order_acquire) != 0) return;
    smt_reorder();
    atomic_store_explicit(&g_smt_ready, g_smt_cpus ? 1 : 2, memory_order_release);
#endif
}
/* run fused_body on the master + up to T-1 workers; returns once every worker has finished its steps */
static void team_run(int T, FusedCtx *F) {
    g_team.ctx = F;
    atomic_store(&g_team.cnt, 0); atomic_store(&g_team.done, 0); atomic_store(&g_team.ntf, 0);
    int created = 0;
    if (T > 1) {
        team_cpus_init();
        int bind = g_team_ncpu >= T ? g_bind : 0, skip = -1;
#ifndef __linux__
        bind = 0;
#else
        if (bind == 2) {   /* master on the first allowed CPU (as libgomp's close binding does) */
            cpu_set_t cs; CPU_ZERO(&cs); CPU_SET(g_team_cpus[0], &cs);
            if (sched_setaffinity(0, sizeof cs, &cs) != 0) bind = 0;
        } else if (bind == 1) {
            int c = sched_getcpu(); skip = c;
        }
#endif
        pthread_attr_t at; int attr_ok = pthread_attr_init(&at) == 0;
        if (attr_ok) { pthread_attr_setstacksize(&at, g_team_stack); pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED); }
        int next_cpu = 0, *order = g_team_cpus, switched = 0;
        static unsigned char used[4096];                   /* CPU ids come from a cpu_set_t (< 1024) */
        memset(used, 0, sizeof used);
        if (!bind) atomic_store(&g_smt_ready, 2);          /* placement irrelevant: no sysfs read */
        g_team_assigned = realloc(g_team_assigned, sizeof(int) * ((size_t)T + 1));
        if (bind == 2) used[g_team_cpus[0]] = 1;
        for (int i = 1; i < T; i++) {
            int bound = 0;
#ifdef __linux__
            if (bind && attr_ok) {
                if (!switched && atomic_load_explicit(&g_smt_ready, memory_order_acquire) == 1) { order = g_smt_cpus; next_cpu = 0; switched = 1; }
                while (next_cpu < g_team_ncpu && (used[order[next_cpu]] || order[next_cpu] == skip)) next_cpu++;
                if (next_cpu < g_team_ncpu) {
                    cpu_set_t cs; CPU_ZERO(&cs); CPU_SET(order[next_cpu], &cs);
                    bound = pthread_attr_setaffinity_np(&at, sizeof cs, &cs) == 0;
                }
            }
#endif
            pthread_t th;
            int rc = pthread_create(&th, attr_ok ? &at : NULL, team_worker, (void *)(intptr_t)(created + 1));
            if (rc != 0 && bound) {   /* binding refused: retry unbound, stop binding */
#ifdef __linux__
                /* cpusetsize 0 / NULL clears the attribute's affinity (glibc pthread_attr_setaffinity_np);
                 * the prototype marks the pointer nonnull, hence the local diagnostic exemption */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wnonnull"
                pthread_attr_setaffinity_np(&at, 0, NULL);
#pragma GCC diagnostic pop
#endif
                bind = 0; bound = 0;
                rc = pthread_create(&th, attr_ok ? &at : NULL, team_worker, (void *)(intptr_t)(created + 1));
            }
            if (rc != 0) break;
            created++;
            if (bound) { used[order[next_cpu]] = 1; if (created <= T) g_team_assigned[created] = order[next_cpu]; next_cpu++; }
            else if (created <= T) g_team_assigned[created] = -1;
        }
        if (attr_ok) pthread_attr_destroy(&at);
        if (g_prof) {
            int ready = atomic_load(&g_smt_ready);
            fprintf(stderr, "  cpu order (%d allowed, SMT %s k=%d s=%d): master %d, ranks 1..:", g_team_ncpu,
                    ready == 1 ? "reordered" : ready == 2 ? "not used" : "not read yet", g_smt_k, g_smt_s, bind == 2 ? g_team_cpus[0] : -1);
            for (int r = 1; r <= created && r <= 8; r++) fprintf(stderr, " %d", g_team_assigned[r]);
            if (created > 8) fprintf(stderr, " ... %d", g_team_assigned[created]);
            fprintf(stderr, "\n");
        }
    }
    atomic_store_explicit(&g_team.ntf, created + 1, memory_order_release);
    fused_body(0, F);
    while (atomic_load_explicit(&g_team.done, memory_order_acquire) < created) CPU_RELAX();
}

/* ------------------------------------------------------------------ Fortran core (qtcore.f90) */
#include <omp.h>
int qtf_run(int64_t n, int64_t lseg, int64_t nchunks, int d, int t1, int32_t bx0, int32_t bxw, int32_t by0, int32_t byw,
            int ntab, const int32_t *tx, const int32_t *ty, int64_t ncells_all, const int32_t *relmap,
            int64_t rd, const int32_t *cell_x, const int32_t *cell_y, int64_t nnodes, const double *xlo, const double *xhi,
            const double *ylo, const double *yhi, double wx, double wy, double xmin, double ymin, const double *sub,
            int64_t nrn, const int32_t *rn_l, const int32_t *rn_xj, const int32_t *rn_yj, const int32_t *rn_parent,
            int64_t capseg, int64_t *m_out);
void qtf_results(void **res, void **base, void **rc);
/* called by the Fortran build when the reference would fail (same ends as the C version) */
void qt_shim_assert(void) { fprintf(stderr, "qt: qt.c: insert_point_quadtree: Assertion `ret >= 0' failed.\n"); abort(); }
void qt_shim_endless(void) { fprintf(stderr, "quadtree: unbounded subdivision (reference overflows its stack)\n"); raise(SIGSEGV); abort(); }
static int g_ftn = 1;   /* env QT_NOFTN=1: C pipeline */
/* libgomp ends the program if it cannot create its threads (gomp_fatal); under a small process limit the
 * C pipeline is used instead, whose team simply shrinks when pthread_create fails */
static int ftn_threads_ok(void) {
    struct rlimit rl;
    if (getrlimit(RLIMIT_NPROC, &rl) == 0 && rl.rlim_cur != RLIM_INFINITY && rl.rlim_cur < 4096) return 0;
    return 1;
}
/* fast path through the Fortran core: 1 done (output written), 0 retry with D = 0, -1 use the C pipeline */
static int ftn_fast(uint64_t n, uint64_t L, size_t nchunks, int D, int T1, uint32_t bx0, uint32_t bxw, uint32_t by0, uint32_t byw,
                    size_t RD, size_t capseg, double tp) {
    size_t tot_nodes = ((size_t)1 << (D + 1)) - 1, ncells_all = (size_t)1 << (2 * D);
    int32_t *rl = malloc(sizeof(int32_t) * (nrn + 1) * 4), *rx = rl + nrn + 1, *ry = rx + nrn + 1, *rp = ry + nrn + 1;
    for (size_t i = 0; i < nrn; i++) { rl[i] = rn[i].l; rx[i] = rn[i].xj; ry[i] = rn[i].yj; rp[i] = rn[i].parent; }
    double sub[4] = { C.sub_boundaries.x_min, C.sub_boundaries.x_max, C.sub_boundaries.y_min, C.sub_boundaries.y_max };
    int64_t m = 0;
    int r = qtf_run((int64_t)n, (int64_t)L, (int64_t)nchunks, D, T1, (int32_t)bx0, (int32_t)bxw, (int32_t)by0, (int32_t)byw,
                    (int)tot_nodes, (const int32_t *)TXv, (const int32_t *)TYv, (int64_t)ncells_all, relmap,
                    (int64_t)RD, cell_x, cell_y, (int64_t)tot_nodes, XLO, XHI, YLO, YHI, Wx, Wy,
                    C.map_boundaries.x_min, C.map_boundaries.y_min, sub, (int64_t)nrn, rl, rx, ry, rp, (int64_t)capseg, &m);
    free(rl);
    if (r != 1) return r;
    PROF("fortran core (phase 1, sort, build/query)", tp);
    fflush(stdout);
    if (m == 0) { write_all("Empty\n", 6); return 1; }
    void *vres, *vbase, *vrc; qtf_results(&vres, &vbase, &vrc);
    const tpPoint *res = vres; const size_t *base = vbase, *rc = vrc;
    size_t *pre = malloc(sizeof(size_t) * (RD + 1));
    pre[0] = 0; for (size_t i = 0; i < RD; i++) pre[i + 1] = pre[i] + rc[i];
    int TF = (int)((size_t)m / 1024); if (TF > T1) TF = T1; if (TF < 1) TF = 1;
    size_t lb = line_bound(), per = ((size_t)m + TF - 1) / TF, one = per * lb + 1024;
    char *big = malloc(one * (size_t)TF); char **bufs = malloc(sizeof(char *) * (size_t)TF);
    size_t *lens = calloc((size_t)TF, sizeof(size_t)), *cap0 = malloc(sizeof(size_t) * ((size_t)TF + 1));
    for (int t = 0; t < TF; t++) { bufs[t] = big + one * (size_t)t; cap0[t] = one; }
    cap0[TF] = 0;
    FmtCtx Fm = { res, base, rc, pre, RD, (size_t)m, per, TF, big, cap0, bufs, lens };
#pragma omp parallel for num_threads(TF) schedule(static, 1)
    for (int t = 0; t < TF; t++) fmt_job(t, TF, &Fm);
    for (int t = 0; t < TF; t++) if (lens[t]) write_all(bufs[t], lens[t]);
    PROF("format+write", tp);
    return 1;
}

static int fast_path(int D) {
    double t_fp0 = tnow();
    uint64_t n = C.n_points;
    D_ = D;
    size_t tot_nodes = ((size_t)1 << (D + 1)) - 1;
    TXv = malloc(sizeof(uint32_t) * tot_nodes); TYv = malloc(sizeof(uint32_t) * tot_nodes);
    XLO = malloc(sizeof(double) * tot_nodes); XHI = malloc(sizeof(double) * tot_nodes);
    YLO = malloc(sizeof(double) * tot_nodes); YHI = malloc(sizeof(double) * tot_nodes);
    uint32_t *KX0 = malloc(sizeof(uint32_t) * tot_nodes), *KX1 = malloc(sizeof(uint32_t) * tot_nodes);
    uint32_t *KY0 = malloc(sizeof(uint32_t) * tot_nodes), *KY1 = malloc(sizeof(uint32_t) * tot_nodes);
    XLO[0] = C.map_boundaries.x_min; XHI[0] = C.map_boundaries.x_max;
    YLO[0] = C.map_boundaries.y_min; YHI[0] = C.map_boundaries.y_max;
    KX0[0] = KY0[0] = 0; KX1[0] = KY1[0] = MAX_NORMA;
    for (int l = 0; l < D; l++)
        for (size_t j = 0; j < ((size_t)1 << l); j++) {
            size_t p = LO(l) + j, c0 = LO(l + 1) + 2 * j, c1 = c0 + 1;
            double xa = (XLO[p] + XHI[p]) / 2.0, ya = (YLO[p] + YHI[p]) / 2.0;
            double d = fabsf(XHI[p] - XLO[p]); if (d < MAX_ERROR) return 0;
            d = fabsf(YHI[p] - YLO[p]); if (d < MAX_ERROR) return 0;
            /* full mode: the levels above D are subdivided without checks, so they must split strictly */
            if (g_full && !(xa > XLO[p] && xa < XHI[p] && ya > YLO[p] && ya < YHI[p])) return 0;
            TXv[p] = kthr(1, xa, 1);  /* x > xa  <=> kx >= TX : right child  */
            TYv[p] = kthr(0, ya, 0);  /* y >= ya <=> ky >= TY : upper child  */
            XLO[c0] = XLO[p]; XHI[c0] = xa; XLO[c1] = xa; XHI[c1] = XHI[p];
            YLO[c0] = YLO[p]; YHI[c0] = ya; YLO[c1] = ya; YHI[c1] = YHI[p];
            if (TXv[p] < KX0[p] || TXv[p] > KX1[p] || TYv[p] < KY0[p] || TYv[p] > KY1[p]) return 0;  /* never (nesting) */
            KX0[c0] = KX0[p]; KX1[c0] = TXv[p]; KX0[c1] = TXv[p]; KX1[c1] = KX1[p];
            KY0[c0] = KY0[p]; KY1[c0] = TYv[p]; KY0[c1] = TYv[p]; KY1[c1] = KY1[p];
        }
    size_t ncells_all = (size_t)1 << (2 * D);
    relmap = calloc(ncells_all, sizeof(int32_t));     /* lazily zeroed pages: only touched cells fault */
    caprn = 1024; nrn = 0; rn = malloc(caprn * sizeof(RNode));
    cell_x = malloc(sizeof(int32_t) * ncells_all); cell_y = malloc(sizeof(int32_t) * ncells_all); ncell = 0;
    if (g_full) { cell_emit = malloc(ncells_all); relevant_rec_full(0, 0, 0, -1, 1); }
    else
    relevant_rec(0, 0, 0, -1);
    size_t RD = ncell;
    double tp = tnow();
    if (g_prof) fprintf(stderr, "  tables (D=%d)                %.5f s\n", D, tp - t_fp0);
    if (g_prof) fprintf(stderr, "  D=%d relevant nodes=%zu cells=%zu\n", D, nrn, RD);
    if (RD == 0) { ramp_cancel(); print_results(NULL, 0); return 1; }
    /* k-space bounding box of the relevant cells */
    uint32_t bx0 = MAX_NORMA, bx1 = 0, by0 = MAX_NORMA, by1 = 0;
    double karea = 0;                                   /* relevant area in k-space, units of 1e6 x 1e6 */
    for (size_t c = 0; c < RD; c++) {
        size_t px = LO(D) + (size_t)cell_x[c], py = LO(D) + (size_t)cell_y[c];
        karea += (double)(KX1[px] - KX0[px]) * (double)(KY1[py] - KY0[py]) * 1e-12;
        if (KX0[px] < bx0) bx0 = KX0[px];
        if (KX1[px] > bx1) bx1 = KX1[px];
        if (KY0[py] < by0) by0 = KY0[py];
        if (KY1[py] > by1) by1 = KY1[py];
    }
    uint32_t bxw = bx1 > bx0 ? bx1 - bx0 : 0, byw = by1 > by0 ? by1 - by0 : 0;

    /* --- phase 1 */
    int T = nthreads();
    /* threads are capped by the work: each extra thread costs ~67 us to create and tear down (2x96-core EPYC) */
    int T1 = team_threads(n, (double)n * karea, T);
    if (g_ppt) { T1 = (int)(n / g_ppt); if (T1 < 1) T1 = 1; if (T1 > T) T1 = T; }   /* env QT_PPT override */
    size_t nchunks = n < 200000 ? 1 : (size_t)T1 * 4;
    size_t nseg = nchunks * LANES;
    uint64_t L = (n + nseg - 1) / nseg;                     /* points per segment (lane) */
    /* kept-point pool preallocated by the master (no malloc in the parallel region): capacity per
     * segment = expected candidates in the k-space box * 1.25 + 64 (overflow -> heap growth) */
    double fbox = ((double)bxw / MAX_NORMA) * ((double)byw / MAX_NORMA);
    size_t capseg = (size_t)((double)L * fbox * 1.25) + 64;
    if (capseg > L + 64) capseg = L + 64;
#ifdef HAVE_AVX2_PATH
    if (g_ftn && use_emu && g_avx2 && !g_full && (T1 <= 1 || ftn_threads_ok())) {   /* the Fortran core is compiled for AVX2 */
        int r = ftn_fast(n, L, nchunks, D, T1, bx0, bxw, by0, byw, RD, capseg, tp);
        if (r == 1) return 1;
        if (r == 0) return fast_path(0);   /* sparse: redo with D=0 (always exact) */
    }
#endif
    uint64_t *pool = big_alloc(sizeof(uint64_t) * nseg * capseg);
    KVec *kv = calloc(nseg, sizeof(KVec));
    for (size_t s = 0; s < nseg; s++) { kv[s].v = pool + s * capseg; kv[s].cap = capseg; kv[s].n = 0; }
    size_t ringsz = (size_t)(31 + ROWS) * LANES;                /* uint32 per thread */
    uint32_t *rings = aligned_alloc(64, sizeof(uint32_t) * ringsz * (size_t)T1);   /* 18368 B = 287*64 per thread */
    uint8_t *flagsall = aligned_alloc(64, (size_t)(ROWS / 2) * LANES * (size_t)T1);
    static uint32_t Madv[31][31];
    if (use_emu) adv_matrix(2 * L, Madv);
    if (g_prof) fprintf(stderr, "  phase1 threads=%d chunks=%zu segment=%llu pts cap/seg=%zu\n", T1, nchunks, (unsigned long long)L, capseg);
    /* phase-1 context, shared by the team */
    P1Ctx *P = calloc(1, sizeof(P1Ctx));
    *P = (P1Ctx){ .n = n, .L = L, .nchunks = nchunks, .D = D, .bx0 = bx0, .bxw = bxw, .by0 = by0, .byw = byw, .kv = kv, .rings = rings, .ringsz = ringsz, .flagsall = flagsall, .Madv = Madv };
    /* One team for the whole pipeline (phase 1 -> sort -> build/query -> format): the T1 threads are
     * created once and every later step reuses them (barriers between steps).  All steps partition by
     * the granted team size nt (strided / dynamic). */
    size_t *soff = malloc(sizeof(size_t) * (nseg + 1)), tot = 0, maxcell = 0, m = 0, *sfirst = NULL, *base = NULL, *rc = NULL, *fpre = NULL;
    uint32_t *hist = NULL; uint64_t *cellcnt = NULL; tpPoint *A = NULL, *scratch = NULL;
    int TS = 1, ok = 1, TF = 1;
    SortCtx S; P2Ctx Q2; FmtCtx Fm; char *fbig = NULL; char **fbufs = NULL; size_t *flens = NULL, *fcap0 = NULL;
    char *arena = NULL; size_t szA = 0, szF = 0, lb = 48;
    memset(&S, 0, sizeof S); memset(&Q2, 0, sizeof Q2); memset(&Fm, 0, sizeof Fm);
    {
        FusedCtx *F = calloc(1, sizeof *F);
        F->pool = pool; F->poolsz = sizeof(uint64_t) * nseg * capseg;
        F->P = P; F->kv = kv; F->nseg = nseg; F->soff = soff; F->RD = RD; F->ok = 1; F->TF = 1; F->TS = 1;
        F->T1 = T1; F->D = D; F->n = n; F->lb = 48; F->tp = tp; F->L = L; F->fail = UINT64_MAX;
        if (g_full) g_team_stack = (size_t)8 << 20;   /* full builds may recurse deep (pathological domains) */
        team_run(T1, F);
        if (F->fail != UINT64_MAX) reproduce_failure(F->fail);
        tp = F->tp; ok = F->ok; m = F->m; TF = F->TF; fbufs = F->fbufs; flens = F->flens;
        (void)tot; (void)maxcell; (void)sfirst; (void)base; (void)rc; (void)fpre; (void)hist; (void)cellcnt; (void)A; (void)scratch;
        (void)TS; (void)S; (void)Q2; (void)Fm; (void)fbig; (void)fcap0; (void)arena; (void)szA; (void)szF; (void)lb;
        if (g_prof) PROF("format (in region)", tp);
    }
    if (!ok && g_full) return 0;     /* full mode: a node above D is a leaf -> serial generic path */
    if (!ok) return fast_path(0);   /* sparse: redo with D=0 (always exact) */
    if (g_prof) fprintf(stderr, "  threads: team=%d format buffers=%d (results %zu)\n", g_T1, TF, m);
    fflush(stdout);
    if (m == 0) write_all("Empty\n", 6);
    else for (int t = 0; t < TF; t++) if (flens[t]) write_all(fbufs[t], flens[t]);
    PROF("format+write", tp);
    return 1;
}

static long long g_t_main = 0;
static long long now_ns(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (long long)t.tv_sec * 1000000000LL + t.tv_nsec; }
/* normal end of the program (optional timestamps on stderr with env QT_TS) */
static int finish(void) {
    if (getenv("QT_TS")) {
        struct rusage ru; getrusage(RUSAGE_SELF, &ru);
        fprintf(stderr, "QTTS %lld %lld %ld %ld\n", g_t_main, now_ns(), (long)ru.ru_minflt, (long)ru.ru_majflt);
    }
    return EXIT_SUCCESS;
}

/* ------------------------------------------------------------------ exactness of the query-limited build
 * The fast path builds only the nodes whose path intercepts the query, so it is exact iff the reference
 * cannot fail (assert or endless recursion) in the nodes it skips.  Sufficient condition, per axis, with
 * u = 2^-53, M = max(|lo|, |hi|), W = fl(hi - lo), W0 = hi - lo exactly, grid v(k) = fl(fl(fl(k/1e6) W) + lo):
 *  - midpoints m = fl(a + b)/2 err by <= eps = u M, so every interval at depth d has width
 *    W0/2^d +- 2 eps;
 *  - |v(k) - (k W/1e6 + lo)| <= eta = 2uW + uM, so consecutive grid values differ by >= g = W/1e6 - 2 eta;
 *  - R = first depth with W0/2^d + 2 eps < g: from there an interval holds at most one grid value, so a
 *    node holds only copies of one (kx, ky) pair: at most 4, never 5 -> never split (max multiplicity of
 *    identical pairs in the seed-42 sequence over n <= 2^31-1, real glibc, ROMEO job 815861: 2 301 101
 *    pairs, 1 635 triples, one 4-fold pair completed at point 1 028 175 212, no 5-fold);
 *  - every node above depth R splits strictly and passes the assert if W0/2^(R-1) - 2 eps > max(1.000001e-10,
 *    2 eps) on both axes (float rounding of the extent < 1e-7 relative).
 * Safety factors (1.01, 2.02, 4u on W0) make every bound conservative; it fails only for domains whose
 * extent is below ~5e-5 of the grid or whose offset leaves < ~4 ulps per grid step. */
static int axis_proof(double lo, double hi, double W, int *R, double *wmin_eps, double *T) {
    const double u = 0x1p-53, tiny = 0x1p-1060;
    double M = dmax(fabs(lo), fabs(hi));
    if (!(M < 1e307) || !(W > 0) || !(W < 1e307)) return 0;   /* a + b cannot overflow */
    double eps = 1.01 * u * M + tiny;
    double eta = 2.02 * u * W + 1.01 * u * M + tiny;
    double g = W * 1e-6 * (1.0 - 1e-9) - 2.02 * eta;
    double W0hi = W * (1.0 + 4 * u);
    if (!(g > 2.02 * eps)) return 0;
    int d = 0; double w = W0hi;
    while (!(w + 2.02 * eps < g)) { w *= 0.5; if (++d > 4000) return 0; }
    *R = d; *wmin_eps = 2.02 * eps;
    *T = dmax(1.000001e-10, 2.02 * eps);
    return 1;
}
static int axis_ok_at(double W, int d, double weps, double T) {   /* all depth-d widths > T */
    double w = W * (1.0 - 4 * 0x1p-53); for (int i = 0; i < d; i++) w *= 0.5;
    return w - weps > T;
}
static int no_failure_proof(void) {
    int Rx, Ry; double ex, ey, Tx, Ty;
    if (!axis_proof(C.map_boundaries.x_min, C.map_boundaries.x_max, Wx, &Rx, &ex, &Tx)) return 0;
    if (!axis_proof(C.map_boundaries.y_min, C.map_boundaries.y_max, Wy, &Ry, &ey, &Ty)) return 0;
    if (C.n_points > 0x7fffffffULL) return 0;              /* multiplicity bound measured up to 2^31-1 */
    int R = Rx > Ry ? Rx : Ry;
    if (R == 0) return 1;
    return axis_ok_at(Wx, R - 1, ex, Tx) && axis_ok_at(Wy, R - 1, ey, Ty);
}
/* Developer test / profiling switches, all off unless set (the script C sets none):
 *   QT_PROF (phase times on stderr), QT_TS (timestamps on stderr), QT_FORCE_GENERIC / QT_FORCE_FULL /
 *   QT_FULLD (force the exact slower paths), QT_NOAVX2 / QT_P1K / QT_YSKIP (phase-1 kernel variants),
 *   QT_PPT / QT_P1A / QT_P1C / QT_KEPTNS / QT_TSMIN / QT_TFMIN (team-size and work-split constants),
 *   QT_BIND / QT_NOSMT / QT_SYSFS_CPU (thread placement), QT_WEXIT / QT_EARLYFREE / QT_NOPRETOUCH /
 *   QT_NOMADV / QT_NOTHP / QT_FASTSETUP (memory and start-up variants).  Every combination gives the
 *   same output. */
int main(int ac, char **av) {
#ifdef __linux__
    if (getenv("QT_NOTHP")) prctl(PR_SET_THP_DISABLE, 1, 0, 0, 0);   /* 4 KB-page experiment */
#endif
    (void)ac; (void)av;
    g_t_main = now_ns();
    g_prof = getenv("QT_PROF") != NULL;
    if (getenv("QT_PPT")) { long long v = atoll(getenv("QT_PPT")); if (v > 0) g_ppt = (uint64_t)v; }
    if (getenv("QT_P1A")) g_p1a = atof(getenv("QT_P1A"));
    if (getenv("QT_P1C")) g_p1c = atof(getenv("QT_P1C"));
    if (getenv("QT_TSMIN")) g_tsmin = atof(getenv("QT_TSMIN"));
    if (getenv("QT_NOPRETOUCH")) g_pretouch = 0;
    if (getenv("QT_FASTSETUP")) g_fastsetup = g_fastsetup_early = atoi(getenv("QT_FASTSETUP"));
    if (getenv("QT_NOMADV")) g_madv = 0;
    if (getenv("QT_EARLYFREE")) g_earlyfree = atoi(getenv("QT_EARLYFREE"));
    if (getenv("QT_P1K")) g_p1k = atoi(getenv("QT_P1K"));
    if (getenv("QT_TFMIN")) g_tfmin = atof(getenv("QT_TFMIN"));
    if (getenv("QT_BIND")) g_bind = atoi(getenv("QT_BIND"));
    if (getenv("QT_WEXIT")) g_wexit = atoi(getenv("QT_WEXIT"));
    if (getenv("QT_KEPTNS")) g_keptns = atof(getenv("QT_KEPTNS"));
    if (getenv("QT_NOFTN")) g_ftn = 0;
#ifdef HAVE_AVX2_PATH
    g_avx2 = __builtin_cpu_supports("avx2") && !getenv("QT_NOAVX2");
    if (getenv("QT_YSKIP")) g_yskip = 1;
#endif
    double tm = tnow();
    C = load_config_ini();
    Wx = (C.map_boundaries.x_max - C.map_boundaries.x_min);
    Wy = (C.map_boundaries.y_max - C.map_boundaries.y_min);
    uint64_t n = C.n_points;
    /* num_points > INT_MAX: atoi() wraps negative, the reference's malloc(8*n) fails and bzero(NULL,..)
     * segfaults -> reproduce the same end (SIGSEGV, empty stdout) */
    if (n > 0x7fffffffULL) { fprintf(stderr, "num_points out of range\n"); raise(SIGSEGV); abort(); }
    rng_base_window(42, g_B);
    use_emu = libc_rand_is_glibc();
    if (g_prof) {
#ifdef HAVE_AVX2_PATH
        fprintf(stderr, "  phase-1 kernel: %s\n", g_avx2 ? "AVX2" : "SSE2/generic");
#endif
    }
    if (g_prof) fprintf(stderr, "  rng: %s\n", use_emu ? "built-in glibc emulation (libc rand() checked == glibc)" : "libc rand() is NOT glibc: sequential libc rand()");
    PROF("read input + rng init", tm);
    if (!use_emu) {   /* non-glibc libc: use its rand() sequentially (exactly what the reference does) */
        KX = malloc(sizeof(uint32_t) * (n + 1)); KY = malloc(sizeof(uint32_t) * (n + 1));
        srand(42);
        for (uint64_t i = 0; i < n; i++) { KX[i] = (uint32_t)(rand() % MAX_NORMA); KY[i] = (uint32_t)(rand() % MAX_NORMA); }
    }
    const tpRectangle *M = &C.map_boundaries, *Q = &C.sub_boundaries;
    /* valid domain for the k-space machinery: finite bounds, positive finite extents (x(k) is then
     * non-decreasing in k, so every threshold test is an integer test on k), no NaN in the query, and
     * every generated point inside the root (no "is not inserted" line) */
    int valid = !getenv("QT_FORCE_GENERIC");
    if (!(isfinite(M->x_min) && isfinite(M->x_max) && isfinite(M->y_min) && isfinite(M->y_max))) valid = 0;
    if (!(isfinite(Wx) && isfinite(Wy) && Wx > 0 && Wy > 0)) valid = 0;
    if (isnan(Q->x_min) || isnan(Q->x_max) || isnan(Q->y_min) || isnan(Q->y_max)) valid = 0;
    if (valid && !(fx(0) >= M->x_min && fx(MAX_NORMA - 1) <= M->x_max && fy(0) >= M->y_min && fy(MAX_NORMA - 1) <= M->y_max)) valid = 0;
    /* query-limited fast path only when no node outside the query can make the reference fail */
    int proof = valid && no_failure_proof();
    if (g_prof) fprintf(stderr, "  path: %s\n", !valid ? "serial generic" : proof ? "fast (no-failure proof holds)" : "full parallel build");
    int D = 0;
    while (D < DMAX && ((uint64_t)64 << (2 * (D + 1))) <= n) D++;   /* >= 64 points per level-D cell on average */
    if (!valid) { generic_path(); return finish(); }
    if (!proof || getenv("QT_FORCE_FULL")) {
        /* full build: every cell is sorted and built, so larger cells (>= 2048 points on average) keep the
         * counting sort local (per-thread histograms of 4^D counters); 3e7 points: D=9 146 ms, 8 81, 7 56,
         * 6 44 ms (ROMEO job 815880) */
        int Df = 0;
        while (Df < DMAX && ((uint64_t)2048 << (2 * (Df + 1))) <= n) Df++;
        if (getenv("QT_FULLD")) { Df = atoi(getenv("QT_FULLD")); if (Df < 0) Df = 0; if (Df > DMAX) Df = DMAX; }
        g_full = 1;
        if (!fast_path(Df)) { g_full = 0; generic_path(); }
        return finish();
    }
    if (!intercept(*M, *Q)) { print_results(NULL, 0); return finish(); }   /* root pruned: "Empty" */
    if (!fast_path(D)) { ramp_cancel(); generic_path(); }
    return finish();
}
