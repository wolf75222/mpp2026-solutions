#include <stdint.h>
#include <stdio.h>
#if defined(__SSE2__)
#include <emmintrin.h>
#endif
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <stdint.h>
#include <vector>
#include <thread>
#include <chrono>
#include <sys/uio.h>
#include <mutex>
#include <condition_variable>
#ifdef _OPENMP
#include <omp.h>
#endif
#include "fastio.h"

#ifndef PROF
#define PROF 0
#endif
#ifndef WALK_CHUNK
#define WALK_CHUNK 1
#endif
#ifndef RES_BLOCK
#define RES_BLOCK 16384
#endif
#ifndef WALK_DEFER
#define WALK_DEFER 256
#endif
#ifndef IN_PREAD
#define IN_PREAD 0
#endif
#ifndef IN_MMAP
#define IN_MMAP 1
#endif
#ifndef OUT_ASYNC
#define OUT_ASYNC 1
#endif
#ifndef WALK_BLOCK
#define WALK_BLOCK 4096
#endif
#ifndef WALK_PERM
#define WALK_PERM 1
#endif
#ifndef MW
#define MW 8
#endif
#ifndef OUT_MMAP
#define OUT_MMAP 0
#endif
#ifndef OUT_POOL
#define OUT_POOL 1
#endif
#ifndef THP_ADVISE
#define THP_ADVISE 1
#endif
#ifndef T_AUTO
#define T_AUTO 1
#endif
#ifndef T_MAX
#define T_MAX 112
#endif
#ifndef T_MID
#define T_MID 64
#endif
#ifndef T_BIG_CELLS
#define T_BIG_CELLS 12000000L
#endif
#ifndef T_CPT
#define T_CPT 125000L
#endif
#ifndef T_SQRT_K
#define T_SQRT_K 16
#endif
#ifndef NB_CELLS
#define NB_CELLS 16384L
#endif
#ifndef BIG_MIN
#define BIG_MIN ((size_t)4 << 20)
#endif
#ifndef REL_MIN
#define REL_MIN ((size_t)64 << 20)
#endif
#ifndef FAST_EXIT
#define FAST_EXIT 0
#endif
#ifndef OUT_HUGE
#define OUT_HUGE 1
#endif
#ifndef OUT_HUGE_MIN
#define OUT_HUGE_MIN ((size_t)4 << 20)
#endif
#ifndef OUT_NOHUGE
#define OUT_NOHUGE 0
#endif
#ifndef FASTREL
#define FASTREL 1
#endif
#ifndef PARSE_FULL
#define PARSE_FULL 0
#endif
#ifndef LAB_CACHE
#define LAB_CACHE 1
#endif
#ifndef OUT_LF
#define OUT_LF 0
#endif
#ifndef PARSE1
#define PARSE1 1
#endif
#ifndef FMTD_SIMD
#define FMTD_SIMD 1
#endif
#ifndef SIMD_COUNT
#define SIMD_COUNT 1
#endif
#ifndef TPOOL
#define TPOOL 1
#endif
#ifndef BPT
#define BPT 2
#endif
#ifndef FMT_STATIC
#define FMT_STATIC 0
#endif
#ifndef RES_STATIC
#define RES_STATIC 1
#endif
#ifndef WS_HALVE2
#define WS_HALVE2 0
#endif
#ifndef NUMA_STATIC
#define NUMA_STATIC 1
#endif
#if NUMA_STATIC
#define SCHED_LOC schedule(static)
#else
#define SCHED_LOC schedule(dynamic, 1)
#endif
#ifndef WS_HALVE
#define WS_HALVE 1
#endif
#ifndef WS3
#define WS3 0
#endif
#ifndef WS2
#define WS2 1
#endif

static double wtime() {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + 1e-9 * ts.tv_nsec;
}
static inline int nthreads(long V) {
    (void)V;
#ifdef _OPENMP
#if T_AUTO
    const char* e = getenv("OMP_NUM_THREADS");
    if (!e || !*e) {
        const int c = omp_get_num_procs();
        int t = c - 16 > 3 * c / 4 ? c - 16 : 3 * c / 4, cap = T_MAX;
        const char* m = getenv("DTM_TMAX");
        bool all = false;
        if (m && *m) { const int v = atoi(m); if (v > 0) cap = v; else { t = c; cap = INT_MAX; all = true; } }
        else cap = V >= T_BIG_CELLS ? T_MAX : T_MID;
        if (t > cap) t = cap;
        if ((T_SQRT_K > 0 || T_CPT > 0) && !all) {
            const double ws = T_SQRT_K > 0 ? T_SQRT_K * sqrt((double)V / 1e6) : 0;
            long w = (long)(ws + 0.5);
            if (T_CPT > 0) { const long wl = (V + T_CPT - 1) / T_CPT; if (wl > w) w = wl; }
            if (w < 1) w = 1;
            if (w < t) t = (int)w;
        }
        omp_set_num_threads(t < 1 ? 1 : t);
    }
#endif
    return omp_get_max_threads();
#else
    return 1;
#endif
}
static inline void split(long n, int T, int k, long* lo, long* hi) { *lo = n * k / T; *hi = n * (k + 1) / T; }

static const signed char NODIR = -9;

static void write_all(const char* b, size_t len) {
    while (len) {
        ssize_t w = write(1, b, len);
        if (w < 0) { if (errno == EINTR) continue; perror("write"); exit(1); }
        b += w; len -= (size_t)w;
    }
}

struct Region { char* p; size_t len; };
static std::vector<Region> g_regions, g_pool;
static std::mutex g_regmu;
static void* small_alloc(size_t bytes) {
    const size_t pg = (size_t)sysconf(_SC_PAGESIZE);
    const size_t len = (bytes + pg - 1) / pg * pg;
    void* m = mmap(0, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (m == MAP_FAILED) { void* q = malloc(bytes); if (!q) { perror("alloc"); exit(1); } return q; }
    std::lock_guard<std::mutex> g(g_regmu);
    Region r = {(char*)m, len};
    g_regions.push_back(r);
    return m;
}
static void* big_alloc(size_t bytes, bool pool = false) {
    if (bytes < BIG_MIN && !pool) return small_alloc(bytes);
    const size_t A = (size_t)2 << 20;
    size_t len = (bytes + A - 1) / A * A;
    void* m = mmap(0, len + A, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (m == MAP_FAILED) { void* q = malloc(bytes); if (!q) { perror("alloc"); exit(1); } return q; }
    char* a = (char*)(((uintptr_t)m + A - 1) & ~(uintptr_t)(A - 1));
    size_t head = (size_t)(a - (char*)m), tail = A - head;
    if (head) munmap(m, head);
    if (tail) munmap(a + len, tail);
#if THP_ADVISE && defined(MADV_HUGEPAGE)
    madvise(a, len, MADV_HUGEPAGE);
#endif
    std::lock_guard<std::mutex> g(g_regmu);
    Region r = {a, len};
    (pool ? g_pool : g_regions).push_back(r);
    return a;
}
static void* pool_alloc(size_t bytes) {
#if OUT_HUGE
    if (bytes >= (size_t)OUT_HUGE_MIN) return big_alloc(bytes, true);
#endif
    const size_t pg = (size_t)sysconf(_SC_PAGESIZE);
    size_t len = (bytes + pg - 1) / pg * pg;
    void* m = mmap(0, len, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    if (m == MAP_FAILED) { perror("mmap"); exit(1); }
#if OUT_NOHUGE && defined(MADV_NOHUGEPAGE)
    madvise(m, len, MADV_NOHUGEPAGE);
#endif
    std::lock_guard<std::mutex> g(g_regmu);
    Region r = {(char*)m, len};
    g_pool.push_back(r);
    return m;
}
static inline void release_parallel(const std::vector<Region>& rs, int nth) {
    const size_t S = (size_t)32 << 20;
    std::vector<Region> sl;
    for (size_t i = 0; i < rs.size(); i++)
        for (size_t o = 0; o < rs[i].len; o += S) { Region r = {rs[i].p + o, rs[i].len - o < S ? rs[i].len - o : S}; sl.push_back(r); }
    if (nth < 1) nth = 1;
#pragma omp parallel for schedule(dynamic, 1) num_threads(nth)
    for (long i = 0; i < (long)sl.size(); i++) madvise(sl[(size_t)i].p, sl[(size_t)i].len, MADV_DONTNEED);
}

#if OUT_LF && !OUT_ASYNC
#error "OUT_LF needs the writer thread (OUT_ASYNC=1)"
#endif
#if OUT_LF
struct Out {
    struct Blk { const char* p; size_t len; char* tofree; size_t cap; int owner; unsigned char ready; };
    enum { RING = 64 };
    struct Ring { std::pair<char*, size_t> e[RING]; unsigned head, tail; char pad[56]; };
    std::vector<Blk> blk;
    size_t next_write;
    std::mutex mu;
    std::condition_variable cv;
    std::thread th;
    bool async;
    int wsleep;
    std::vector<std::pair<char*, size_t> > pool;
    std::vector<Ring> ring;
    std::vector<std::vector<std::pair<char*, size_t> > > tpool;
    double t_wait, t_write, t_free;
    explicit Out(bool a) : next_write(0), async(a), wsleep(0), t_wait(0), t_write(0), t_free(0) {}
    size_t reserve(size_t k) { size_t b = blk.size(); Blk z = {0, 0, 0, 0, -1, 0}; blk.resize(b + k, z); return b; }
    void init_rings(int T) { Ring z = Ring(); ring.assign((size_t)(T > 0 ? T : 1), z); }
    char* get(size_t need, size_t* cap, int tid = -1) {
        if (tid >= 0 && (size_t)tid < ring.size()) {
            Ring& r = ring[(size_t)tid];
            for (;;) {
                const unsigned t = r.tail, h = __atomic_load_n(&r.head, __ATOMIC_ACQUIRE);
                if (t == h) break;
                std::pair<char*, size_t> e = r.e[t % RING];
                __atomic_store_n(&r.tail, t + 1, __ATOMIC_RELEASE);
                if (e.second >= need) { *cap = e.second; return e.first; }
                std::lock_guard<std::mutex> g(mu); pool.push_back(e);
            }
        }
        {
            std::lock_guard<std::mutex> g(mu);
            for (size_t i = pool.size(); i-- > 0;)
                if (pool[i].second >= need) { char* b = pool[i].first; *cap = pool[i].second; pool[i] = pool.back(); pool.pop_back(); return b; }
        }
        *cap = need;
        return (char*)pool_alloc(need);
    }
    void ready(size_t i, const char* p, size_t len, char* tofree, size_t cap = 0, int owner = -1) {
        Blk& b = blk[i];
        b.p = p; b.len = len; b.tofree = tofree; b.cap = cap; b.owner = owner;
        __atomic_store_n(&b.ready, (unsigned char)1, __ATOMIC_SEQ_CST);
        if (__atomic_load_n(&wsleep, __ATOMIC_SEQ_CST)) { std::lock_guard<std::mutex> g(mu); cv.notify_one(); }
    }
    bool isready(size_t i) { return __atomic_load_n(&blk[i].ready, __ATOMIC_ACQUIRE) != 0; }
    void give_back(const Blk& b) {
        if (!b.tofree) return;
        if (!b.cap) { free(b.tofree); return; }
        if (b.owner >= 0 && (size_t)b.owner < ring.size()) {
            Ring& r = ring[(size_t)b.owner];
            const unsigned h = r.head, t = __atomic_load_n(&r.tail, __ATOMIC_ACQUIRE);
            if (h - t < (unsigned)RING) { r.e[h % RING] = std::make_pair(b.tofree, b.cap); __atomic_store_n(&r.head, h + 1, __ATOMIC_RELEASE); return; }
        }
        std::lock_guard<std::mutex> g(mu); pool.push_back(std::make_pair(b.tofree, b.cap));
    }
    void run(size_t total) {
        std::vector<struct iovec> iov(256);
        size_t i = 0;
        while (i < total) {
            double t0 = PROF ? wtime() : 0;
            if (!isready(i)) {
                for (int spin = 0; spin < 20000 && !isready(i); spin++) {
#if defined(__SSE2__)
                    _mm_pause();
#endif
                }
                if (!isready(i)) {
                    std::unique_lock<std::mutex> g(mu);
                    __atomic_store_n(&wsleep, 1, __ATOMIC_SEQ_CST);
                    while (!isready(i)) cv.wait_for(g, std::chrono::milliseconds(2));
                    __atomic_store_n(&wsleep, 0, __ATOMIC_SEQ_CST);
                }
            }
            size_t j = i, k = 0;
            while (j < total && k < iov.size() && isready(j)) { iov[k].iov_base = (void*)blk[j].p; iov[k].iov_len = blk[j].len; ++k; ++j; }
            double t1 = PROF ? wtime() : 0;
            size_t first = 0;
            while (first < k) {
                ssize_t w = writev(1, &iov[first], (int)(k - first));
                if (w < 0) { if (errno == EINTR) continue; perror("write"); exit(1); }
                size_t left = (size_t)w;
                while (first < k && left >= iov[first].iov_len) { left -= iov[first].iov_len; ++first; }
                if (first < k && left) { iov[first].iov_base = (char*)iov[first].iov_base + left; iov[first].iov_len -= left; }
            }
            double t2 = PROF ? wtime() : 0;
            for (size_t q = i; q < j; q++) give_back(blk[q]);
            if (PROF) { double t3 = wtime(); t_wait += t1 - t0; t_write += t2 - t1; t_free += t3 - t2; }
            i = j;
        }
    }
};
#else
struct Out {
    struct Blk { const char* p; size_t len; char* tofree; size_t cap; int owner; bool ready; };
    std::vector<Blk> blk;
    size_t next_write;
    std::mutex mu;
    std::condition_variable cv;
    std::thread th;
    bool async;
    std::vector<std::pair<char*, size_t> > pool;
    std::vector<std::vector<std::pair<char*, size_t> > > tpool;
    double t_wait, t_write, t_free;
    explicit Out(bool a) : next_write(0), async(a), t_wait(0), t_write(0), t_free(0) {}
    size_t reserve(size_t k) { size_t b = blk.size(); Blk z = {0, 0, 0, 0, -1, false}; blk.resize(b + k, z); return b; }
    char* get(size_t need, size_t* cap, int tid = -1) {
        if (OUT_POOL) {
            std::lock_guard<std::mutex> g(mu);
            if (TPOOL && tid >= 0 && (size_t)tid < tpool.size()) {
                std::vector<std::pair<char*, size_t> >& tp = tpool[(size_t)tid];
                for (size_t i = tp.size(); i-- > 0;)
                    if (tp[i].second >= need) { char* b = tp[i].first; *cap = tp[i].second; tp.erase(tp.begin() + (long)i); return b; }
            }
            for (size_t i = pool.size(); i-- > 0;)
                if (pool[i].second >= need) { char* b = pool[i].first; *cap = pool[i].second; pool[i] = pool.back(); pool.pop_back(); return b; }
        }
        *cap = need;
        return (char*)(OUT_POOL ? pool_alloc(need) : malloc(need));
    }
    void ready(size_t i, const char* p, size_t len, char* tofree, size_t cap = 0, int owner = -1) {
        std::lock_guard<std::mutex> g(mu);
        blk[i].p = p; blk[i].len = len; blk[i].tofree = tofree; blk[i].cap = cap; blk[i].owner = owner; blk[i].ready = true;
        cv.notify_one();
    }
    void run(size_t total) {
        for (size_t i = 0; i < total; i++) {
            Blk b;
            double t0 = PROF ? wtime() : 0;
            {
                std::unique_lock<std::mutex> g(mu);
                while (!blk[i].ready) cv.wait(g);
                b = blk[i];
            }
            double t1 = PROF ? wtime() : 0;
            write_all(b.p, b.len);
            double t2 = PROF ? wtime() : 0;
            if (b.tofree) {
                if (OUT_POOL && b.cap) {
                    std::lock_guard<std::mutex> g(mu);
                    if (TPOOL && b.owner >= 0 && (size_t)b.owner < tpool.size()) tpool[(size_t)b.owner].push_back(std::make_pair(b.tofree, b.cap));
                    else pool.push_back(std::make_pair(b.tofree, b.cap));
                }
                else free(b.tofree);
            }
            if (PROF) { double t3 = wtime(); t_wait += t1 - t0; t_write += t2 - t1; t_free += t3 - t2; }
        }
    }
};
#endif

static inline long count_token_starts(const char* s, const char* e) {
    long c = 0;
    const char* q = s;
#if SIMD_COUNT && defined(__SSE2__)
    const __m128i sp = _mm_set1_epi8(' ');
    const __m128i zero = _mm_setzero_si128();
    while (e - q >= 16) {
        long iters = (e - q) / 16; if (iters > 255) iters = 255;
        __m128i acc = zero;
        for (long it = 0; it < iters; it++, q += 16) {
            const __m128i cur = _mm_loadu_si128((const __m128i*)q);
            const __m128i prv = _mm_loadu_si128((const __m128i*)(q - 1));
            const __m128i wsc = _mm_cmpeq_epi8(_mm_max_epu8(cur, sp), sp);
            const __m128i wsp = _mm_cmpeq_epi8(_mm_max_epu8(prv, sp), sp);
            acc = _mm_sub_epi8(acc, _mm_andnot_si128(wsc, wsp));
        }
        const __m128i sad = _mm_sad_epu8(acc, zero);
        c += _mm_cvtsi128_si64(sad) + _mm_cvtsi128_si64(_mm_unpackhi_epi64(sad, sad));
    }
#endif
    for (; q < e; ++q) c += ((unsigned char)q[0] > ' ') & ((unsigned char)q[-1] <= ' ');
    return c;
}

struct WCont { long c; int a; int src; int mn; };
struct SrcScan {
    long nx, e; const unsigned char* indeg; const signed char* D; int* SEG;
    inline bool operator()(long& c, int& a, int& src, int& mn) {
        while (nx < e) {
            long s_ = nx++;
            if (__atomic_load_n(&indeg[s_], __ATOMIC_RELAXED) == 0 && D[s_] != NODIR) {
                c = s_; a = 1; src = (int)s_; mn = (int)s_; SEG[s_] = (int)s_; return true;
            }
        }
        return false;
    }
};
struct ContList {
    const WCont* p; long i, e;
    inline bool operator()(long& c, int& a, int& src, int& mn) {
        if (i >= e) return false;
        c = p[i].c; a = p[i].a; src = p[i].src; mn = p[i].mn; ++i; return true;
    }
};
template <class Next>
static inline void walk_run(Next& next, const signed char* D, unsigned char* indeg, int* acc, int* SEG,
                            int* STOP, const long* off, std::vector<WCont>* park, int kd, int* SMIN) {
    long wc[MW]; int wa[MW]; int wsrc[MW]; int wst[MW]; int wmn[MW];
    int nact = 0;
    for (;;) { if (nact == MW) break; if (!next(wc[nact], wa[nact], wsrc[nact], wmn[nact])) break; wst[nact] = 0; nact++; }
    while (nact > 0) {
        for (int k = 0; k < nact;) {
            const long c = wc[k];
            int a = wa[k];
            const int d = D[c];
            bool done = false;
            if (d == 0) { STOP[wsrc[k]] = -(int)c - 1; if (SMIN) SMIN[wsrc[k]] = wmn[k]; done = true; }
            else {
                const long x = c + off[d];
                unsigned char cur = __atomic_load_n(&indeg[x], __ATOMIC_ACQUIRE);
                if (cur == 0x81) {
                    a += acc[x];
                    acc[x] = a;
                    __atomic_store_n(&indeg[x], (unsigned char)0x80, __ATOMIC_RELAXED);
                } else {
                    __atomic_fetch_add(&acc[x], a, __ATOMIC_RELAXED);
                    if (__atomic_sub_fetch(&indeg[x], 1, __ATOMIC_ACQ_REL) != 0x80) { STOP[wsrc[k]] = (int)x; if (SMIN) SMIN[wsrc[k]] = wmn[k]; done = true; }
                    else a = __atomic_load_n(&acc[x], __ATOMIC_RELAXED);
                }
                if (!done) {
                    SEG[x] = wsrc[k]; wc[k] = x; wa[k] = a;
                    if ((int)x < wmn[k]) wmn[k] = (int)x;
                    if (kd && ++wst[k] >= kd) { WCont w = {x, a, wsrc[k], wmn[k]}; park->push_back(w); done = true; }
                }
            }
            if (done) {
                if (!next(wc[k], wa[k], wsrc[k], wmn[k])) { --nact; wc[k] = wc[nact]; wa[k] = wa[nact]; wsrc[k] = wsrc[nact]; wst[k] = wst[nact]; wmn[k] = wmn[nact]; continue; }
                wst[k] = 0;
            }
            ++k;
        }
    }
}

#ifndef PROF_TEAM
#define PROF_TEAM 0
#endif
static inline long long rt_ns() { struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts); return ts.tv_sec * 1000000000LL + ts.tv_nsec; }
static inline long minflt() { struct rusage ru; getrusage(RUSAGE_SELF, &ru); return ru.ru_minflt; }

int main() {
    const long long rt0 = PROF ? rt_ns() : 0;
    double t0 = wtime(), tA = t0, tB;
    double ph[48]; const char* pn[48]; long pf[48]; int np = 0; long fA = PROF ? minflt() : 0, fB;
#define PM(name) do { if (PROF) { tB = wtime(); fB = minflt(); pn[np] = name; pf[np] = fB - fA; ph[np++] = tB - tA; tA = tB; fA = fB; } } while (0)
#define MARK() PM("?")
#if PROF && PROF_TEAM
    PM("start");
#pragma omp parallel
    { }
    PM("team");
#endif

    const char* buf = 0; size_t len = 0; char* owned = 0; void* mapped = 0; size_t maplen = 0;
    {
        struct stat st;
        bool reg = fstat(0, &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0;
#if IN_PREAD
        if (reg) {
            off_t cur = lseek(0, 0, SEEK_CUR);
            if (cur >= 0 && cur < st.st_size) {
                const size_t L = (size_t)(st.st_size - cur), CH = (size_t)8 << 20;
                char* b = (char*)big_alloc(L + 64);
                const long nch = (long)((L + CH - 1) / CH);
                int ok = 1;
#pragma omp parallel for schedule(dynamic, 1) reduction(min : ok)
                for (long k = 0; k < nch; k++) {
                    size_t o = (size_t)k * CH, l = L - o < CH ? L - o : CH, done = 0;
                    while (done < l) {
                        ssize_t r = pread(0, b + o + done, l - done, cur + (off_t)(o + done));
                        if (r < 0 && errno == EINTR) continue;
                        if (r <= 0) { ok = 0; break; }
                        done += (size_t)r;
                    }
                }
                if (ok) { b[L] = '\0'; buf = b; len = L; }
            }
        }
#endif
#if IN_MMAP
        if (reg && !buf) {
            off_t cur = lseek(0, 0, SEEK_CUR);
            if (cur >= 0 && cur < st.st_size) {
                void* mp = mmap(0, (size_t)st.st_size, PROT_READ, MAP_PRIVATE, 0, 0);
                if (mp != MAP_FAILED) {
                    const char* c = (const char*)mp;
                    if (fio::is_ws((unsigned char)c[st.st_size - 1])) {
                        mapped = mp; maplen = (size_t)st.st_size; buf = c + cur; len = (size_t)(st.st_size - cur);
                    } else munmap(mp, (size_t)st.st_size);
                }
            }
        }
#endif
        if (!buf) {
            size_t cap = reg ? (size_t)st.st_size + 1 : (size_t)1 << 20, n = 0;
            owned = (char*)malloc(cap + 1);
            for (;;) {
                if (n == cap) { cap *= 2; owned = (char*)realloc(owned, cap + 1); }
                ssize_t r = read(0, owned + n, cap - n);
                if (r < 0) { if (errno == EINTR) continue; perror("read"); exit(1); }
                if (r == 0) break;
                n += (size_t)r;
            }
            owned[n] = '\0'; buf = owned; len = n;
        }
    }
    PM("read");
    const char* p = buf;
    const char* end = buf + len;
    long hv[5];
    for (int k = 0; k < 5; k++) {
        while (p < end && fio::is_ws((unsigned char)*p)) ++p;
        char* e; hv[k] = strtol(p, &e, 10); p = e;
    }
    const int n = (int)hv[0], m = (int)hv[1];
    float nv;
    while (p < end && fio::is_ws((unsigned char)*p)) ++p;
    p = fio::parse_float(p, &nv);
    const long V = (long)n * m;
    const long M = m;
    const int T = nthreads(V);
    PM("hdr0");
    Out out(OUT_ASYNC != 0);
    long NB = n < (long)BPT * T ? n : (long)BPT * T;
    if (NB_CELLS > 0) { const long nb = (V + NB_CELLS - 1) / NB_CELLS; if (nb < NB) NB = nb < 1 ? 1 : nb; }
    if (TPOOL) out.tpool.resize((size_t)(T > 0 ? T : 1));
#if OUT_LF
    out.init_rings(T);
#endif
    std::vector<long> blo(NB + 1);
    for (long b = 0; b <= NB; b++) blo[b] = (long)((long long)n * b / NB);
    size_t secbase[4];
    for (int s = 0; s < 4; s++) secbase[s] = out.reserve(s == 0 ? 1 + NB : 3 + NB);
    const size_t total_blocks = out.blk.size();
    char* omap = 0; size_t omap_len = 0, opos = 0; off_t obase = 0; int ofd = -1;
#if OUT_MMAP
    {
        struct stat so;
        int fl = fcntl(1, F_GETFL);
        off_t cur = lseek(1, 0, SEEK_CUR);
        if (fstat(1, &so) == 0 && S_ISREG(so.st_mode) && fl >= 0 && !(fl & O_APPEND) && cur >= 0 && cur % 65536 == 0) {
            int fd = open("/proc/self/fd/1", O_RDWR);
            if (fd >= 0) {
                size_t ub = 128 + (size_t)n * (13 * (size_t)M + 1) + 3 * (size_t)(n + 2) * (12 * (size_t)M + 1);
                if (ftruncate(fd, cur + (off_t)ub) == 0) {
                    void* mp = mmap(0, ub, PROT_READ | PROT_WRITE, MAP_SHARED, fd, cur);
                    if (mp != MAP_FAILED) { omap = (char*)mp; omap_len = ub; obase = cur; ofd = fd; }
                    else if (ftruncate(fd, cur) != 0) {   }
                }
                if (!omap) close(fd);
            }
        }
    }
    if (omap) out.async = false;
#endif
    if (out.async) out.th = std::thread(&Out::run, &out, total_blocks);
    static const char* hdr[4] = {"the terrain\n", "the directions\n", "flow accumulation \n", "watersheds\n"};
    for (int s = 0; s < 4; s++) out.ready(secbase[s], hdr[s], strlen(hdr[s]), 0);
    std::vector<char*> ghosts;
    for (int s = 1; s < 4; s++) {
        for (int w = 0; w < 2; w++) {
            const char* g = s == 1 ? (w ? "5 " : "1 ") : s == 2 ? "0 " : "-1 ";
            size_t gl = strlen(g);
            char* gb = (char*)malloc(gl * (size_t)M + 2);
            size_t L = 0;
            for (long j = 0; j < M; j++) { memcpy(gb + L, g, gl); L += gl; }
            gb[L++] = '\n';
            out.ready(secbase[s] + (w ? 2 + NB : 1), gb, L, gb);
        }
    }

    float* tp = (float*)big_alloc(sizeof(float) * (size_t)(V + 2 * M));
    PM("hdr");
    float* t = tp + M;
    {
        const int TP = PARSE_FULL ? (omp_get_num_procs() > T ? omp_get_num_procs() : T) : T;
        const int C = 4 * TP;
        const char* beg = p;
        std::vector<const char*> cut(C + 1);
        std::vector<long> cnt(C + 1, 0);
        cut[0] = beg; cut[C] = end;
        for (int k = 1; k < C; k++) {
            const char* b = beg + (end - beg) * k / C;
            if (b < cut[k - 1]) b = cut[k - 1];
            while (b < end && !fio::is_ws((unsigned char)*b)) ++b;
            cut[k] = b;
        }
#if PARSE1
        std::vector<size_t> soff(C + 1, 0);
        for (int k = 0; k < C; k++) soff[k + 1] = soff[k] + (size_t)((cut[k + 1] - cut[k]) / 2 + 2);
        float* stg = (float*)big_alloc(sizeof(float) * soff[C]);
        PM("cut");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {
            float* o = stg + soff[k];
            const long capk = (long)(soff[k + 1] - soff[k]);
            long nk = 0;
            const char* q = cut[k];
            const char* e = cut[k + 1];
            while (nk < capk) {
                while (q < e && fio::is_ws((unsigned char)*q)) ++q;
                if (q >= e) break;
                q = fio::parse_float(q, &o[nk++]);
            }
            cnt[k + 1] = nk;
        }
        for (int k = 1; k <= C; k++) cnt[k] += cnt[k - 1];
        PM("parse");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {
            const long a = cnt[k], b = cnt[k + 1] < V ? cnt[k + 1] : V;
            if (a < b) memcpy(t + a, stg + soff[k], (size_t)(b - a) * sizeof(float));
        }
        PM("copy");
#else
        PM("cut");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {
            cnt[k + 1] = count_token_starts(cut[k], cut[k + 1]);
        }
        for (int k = 1; k <= C; k++) cnt[k] += cnt[k - 1];
        PM("count");
#pragma omp parallel for SCHED_LOC num_threads(TP)
        for (int k = 0; k < C; k++) {
            long idx = cnt[k];
            const char* q = cut[k];
            const char* e = cut[k + 1];
            while (idx < V) {
                while (q < e && fio::is_ws((unsigned char)*q)) ++q;
                if (q >= e) break;
                q = fio::parse_float(q, &t[idx++]);
            }
        }
        PM("parse");
#endif
        for (long i = cnt[C] < V ? cnt[C] : V; i < V; i++) t[i] = 0.0f;
    }
    std::vector<Region> late;
    if (mapped) {
        if (FASTREL) { size_t pg = (size_t)sysconf(_SC_PAGESIZE); Region r = {(char*)mapped, (maplen + pg - 1) / pg * pg}; late.push_back(r); }
        else munmap(mapped, maplen);
    }
    if (owned) free(owned);
    for (long j = 0; j < M; j++) { tp[j] = nv; t[V + j] = nv; }
    PM("ghost");

    const int* gi = 0;
    const int* glab = 0;
    const int* gstop = 0; const int* gseg = 0;
    signed char* D = 0;
    auto format_section = [&](int sec) {
        const size_t wmax = sec == 0 ? 13 : sec == 1 ? 3 : 12;
        const size_t first = secbase[sec] + (sec == 0 ? 1 : 2);
#if FMT_STATIC
#pragma omp parallel for schedule(static)
#else
#pragma omp parallel for schedule(dynamic, 1)
#endif
        for (long b = 0; b < NB; b++) {
            size_t bcap;
            const int me = omp_get_thread_num();
            char* bb = out.get((size_t)(blo[b + 1] - blo[b]) * (wmax * (size_t)M + 1) + 16, &bcap, me);
            char* q = bb;
            for (long i = blo[b]; i < blo[b + 1]; i++) {
                const long o = i * M;
                if (sec == 0) {
                    const float* r = t + o;
                    for (long j = 0; j < M; j++) { q = fio::put_g6(q, r[j]); *q++ = ' '; }
                } else if (sec == 1) {
                    const signed char* r = D + o;
                    long j = 0;
#if FMTD_SIMD && defined(__SSE2__)
                    const __m128i z0 = _mm_set1_epi8('0'), spc = _mm_set1_epi8(' ');
                    for (; j + 16 <= M; j += 16) {
                        const __m128i v = _mm_loadu_si128((const __m128i*)(r + j));
                        if (_mm_movemask_epi8(v)) {
                            for (int k = 0; k < 16; k++) {
                                int d = r[j + k];
                                if (d >= 0) { q[0] = (char)('0' + d); q[1] = ' '; q += 2; }
                                else { q[0] = '-'; q[1] = '9'; q[2] = ' '; q += 3; }
                            }
                            continue;
                        }
                        const __m128i c = _mm_add_epi8(v, z0);
                        _mm_storeu_si128((__m128i*)q, _mm_unpacklo_epi8(c, spc));
                        _mm_storeu_si128((__m128i*)(q + 16), _mm_unpackhi_epi8(c, spc));
                        q += 32;
                    }
#endif
                    for (; j < M; j++) {
                        int d = r[j];
                        if (d >= 0) { q[0] = (char)('0' + d); q[1] = ' '; q += 2; }
                        else { q[0] = '-'; q[1] = '9'; q[2] = ' '; q += 3; }
                    }
                } else {
                    const int* r = gi + o;
                    if (sec == 3 && gstop) {
                        const signed char* dr = D + o;
                        const int* sg = gseg + o;
#if LAB_CACHE
                        int lseg = -1; uint32_t llab = 0xffffffffu; char lbuf[16] = {0}; int llen = 0;
                        for (long j = 0; j < M; j++) {
                            if (dr[j] == NODIR) { q[0] = '-'; q[1] = '1'; q[2] = ' '; q += 3; continue; }
                            const int sj = sg[j];
                            if (sj != lseg) {
                                lseg = sj;
                                const uint32_t lab = (uint32_t)glab[-gstop[sj] - 1];
                                if (lab != llab) { llab = lab; llen = (int)(fio::put_u32(lbuf, lab) - lbuf); lbuf[llen] = ' '; }
                            }
                            memcpy(q, lbuf, 16); q += llen + 1;
                        }
#else
                        for (long j = 0; j < M; j++) {
                            if (dr[j] != NODIR) q = fio::put_u32(q, (uint32_t)glab[-gstop[sg[j]] - 1]);
                            else { q[0] = '-'; q[1] = '1'; q += 2; }
                            *q++ = ' ';
                        }
#endif
                    } else if (sec == 3 && glab) {
#if LAB_CACHE
                        int lr = -2; char lbuf[16] = {0}; int llen = 0;
                        for (long j = 0; j < M; j++) {
                            const int v = r[j];
                            if (v < 0) { q[0] = '-'; q[1] = '1'; q[2] = ' '; q += 3; continue; }
                            if (v != lr) { lr = v; llen = (int)(fio::put_u32(lbuf, (uint32_t)glab[v]) - lbuf); lbuf[llen] = ' '; }
                            memcpy(q, lbuf, 16); q += llen + 1;
                        }
#else
                        for (long j = 0; j < M; j++) {
                            int v = r[j];
                            if (v >= 0) q = fio::put_u32(q, (uint32_t)glab[v]);
                            else { q[0] = '-'; q[1] = '1'; q += 2; }
                            *q++ = ' ';
                        }
#endif
                    } else
                    for (long j = 0; j < M; j++) {
                        int v = r[j];
                        q = v >= 0 ? fio::put_u32(q, (uint32_t)v) : fio::put_i32(q, v);
                        *q++ = ' ';
                    }
                }
                *q++ = '\n';
            }
            out.ready(first + (size_t)b, bb, (size_t)(q - bb), bb, bcap, me);
        }
    };
    auto flush_upto = [&](size_t upto) {
        for (; out.next_write < upto; out.next_write++) {
            Out::Blk& b = out.blk[out.next_write];
            write_all(b.p, b.len);
            if (b.tofree) free(b.tofree);
        }
    };
    (void)flush_upto;
    auto mmap_section = [&](int sec) {
        const size_t lo = secbase[sec], hi = sec == 3 ? total_blocks : secbase[sec + 1];
        std::vector<size_t> offs(hi - lo + 1);
        offs[0] = opos;
        for (size_t i = lo; i < hi; i++) offs[i - lo + 1] = offs[i - lo] + out.blk[i].len;
#pragma omp parallel for schedule(dynamic, 1)
        for (long i = (long)lo; i < (long)hi; i++) {
            Out::Blk& bk = out.blk[(size_t)i];
            memcpy(omap + offs[(size_t)i - lo], bk.p, bk.len);
            if (bk.tofree) free(bk.tofree);
        }
        opos = offs[hi - lo];
    };
    (void)mmap_section;
#define FORMAT(sec) do { format_section(sec); \
        if (omap) mmap_section(sec); \
        else if (!out.async) flush_upto((sec) == 3 ? total_blocks : secbase[(sec) + 1]); } while (0)

    PM("plan");
    FORMAT(0);
    PM("fmtT");

    signed char* dpad = (signed char*)big_alloc((size_t)(V + 2 * M + 2));
    D = dpad + 1 + M;
    memset(dpad, NODIR, (size_t)(M + 1));
    memset(D + V, NODIR, (size_t)(M + 1));
#pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
        const float* r = t + (long)i * M;
        const float* up = r - M;
        const float* dn = r + M;
        signed char* dr = D + (long)i * M;
        {
            float v = r[0], mn = v; int code = 0;
            const float nb[5] = {up[0], up[1], r[1], dn[1], dn[0]};
            for (int k = 0; k < 5; k++) if (nb[k] != nv && nb[k] < mn) { mn = nb[k]; code = k + 1; }
            dr[0] = v != nv ? (signed char)code : NODIR;
        }
        for (int j = 1; j < m - 1; j++) {
            float v = r[j], mn = v; int code = 0;
#define STEPD(x, kk) { float xx = (x); bool c = (xx != nv) & (xx < mn); mn = c ? xx : mn; code = c ? (kk) : code; }
            STEPD(up[j], 1) STEPD(up[j + 1], 2) STEPD(r[j + 1], 3) STEPD(dn[j + 1], 4)
            STEPD(dn[j], 5) STEPD(dn[j - 1], 6) STEPD(r[j - 1], 7) STEPD(up[j - 1], 8)
#undef STEPD
            dr[j] = v != nv ? (signed char)code : NODIR;
        }
        if (m > 1) {
            int j = m - 1;
            float v = r[j], mn = v; int code = 0;
            const float nb[5] = {dn[j], dn[j - 1], r[j - 1], up[j - 1], up[j]};
            static const int cd[5] = {5, 6, 7, 8, 1};
            for (int k = 0; k < 5; k++) if (nb[k] != nv && nb[k] < mn) { mn = nb[k]; code = cd[k]; }
            dr[j] = v != nv ? (signed char)code : NODIR;
        }
    }
    PM("dir");
    FORMAT(1);
    PM("fmtD");

    const long off[9] = {0, -M, -M + 1, 1, M + 1, M, M - 1, -1, -M - 1};
    int* acc = (int*)big_alloc(sizeof(int) * (size_t)V);
    unsigned char* indeg = (unsigned char*)big_alloc((size_t)V);
#pragma omp parallel for schedule(static)
    for (long i = 0; i < n; i++) {
        const long b = i * M, e = b + M;
        for (long c = b; c < e; c++) {
            int k = (D[c - M] == 5) + (D[c - M + 1] == 6) + (D[c + 1] == 7) + (D[c + M + 1] == 8)
                  + (D[c + M] == 1) + (D[c + M - 1] == 2) + (D[c - 1] == 3) + (D[c - M - 1] == 4);
            indeg[c] = (unsigned char)(k ? (0x80 | k) : 0);
            acc[c] = D[c] == NODIR ? -1 : 1;
        }
    }
    PM("accinit");
    const long WB = WALK_BLOCK, NWB = (V + WB - 1) / WB;
    long PST = WALK_PERM ? (NWB / (T > 1 ? T : 1)) | 1 : 1;
    while (WALK_PERM && NWB > 1) { long a = PST, b2 = NWB; while (b2) { long t2 = a % b2; a = b2; b2 = t2; } if (a == 1) break; PST += 2; }
    int* SEG = (int*)tp;
    int* STOP = (int*)big_alloc(sizeof(int) * (size_t)V);
    int* SMIN = WS3 ? (int*)big_alloc(sizeof(int) * (size_t)V) : (int*)0;
    const int TMAX = omp_get_max_threads();
    std::vector<std::vector<WCont> > parked((size_t)(TMAX > 0 ? TMAX : 1));
#if NUMA_STATIC
#pragma omp parallel for schedule(static)
    for (long it = 0; it < NWB; it++) {
        const long wb = it;
#else
#pragma omp parallel for schedule(dynamic, WALK_CHUNK)
    for (long it = 0; it < NWB; it++) {
        const long wb = (long)(((unsigned long long)it * (unsigned long long)PST) % (unsigned long long)NWB);
#endif
        const long b = wb * WB, e = b + WB < V ? b + WB : V;
        SrcScan nx = {b, e, indeg, D, SEG};
        walk_run(nx, D, indeg, acc, SEG, STOP, off, &parked[(size_t)omp_get_thread_num()], WALK_DEFER, SMIN);
    }
    PM("walk1");
    {
        std::vector<WCont> all;
        for (size_t k = 0; k < parked.size(); k++) all.insert(all.end(), parked[k].begin(), parked[k].end());
        const long NP = (long)all.size(), PCH = MW;
        if (NP > 0) {
#pragma omp parallel for schedule(dynamic, 1)
            for (long ib = 0; ib < (NP + PCH - 1) / PCH; ib++) {
                ContList cl = {&all[0], ib * PCH, (ib + 1) * PCH < NP ? (ib + 1) * PCH : NP};
                walk_run(cl, D, indeg, acc, SEG, STOP, off, (std::vector<WCont>*)0, 0, SMIN);
            }
        }
    }
    PM("walk2");
    gi = acc;
    FORMAT(2);
    PM("fmtA");

#if WS3
    int* F = acc;
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) if (D[c] == 0) F[c] = INT_MAX;
    PM("wsinit");
    const long RB = RES_BLOCK > 0 ? RES_BLOCK : WB, NRB = (V + RB - 1) / RB;
#pragma omp parallel for SCHED_LOC
    for (long it = 0; it < NRB; it++) {
        const long b = it * RB, e = b + RB < V ? b + RB : V;
        for (long s = b; s < e; s++) {
            if (D[s] == NODIR || SEG[s] != (int)s) continue;
            int v = __atomic_load_n(&STOP[s], __ATOMIC_RELAXED);
            int r;
            if (v < 0) r = -v - 1;
            else {
#if WS_HALVE
                long q = s;
                for (;;) {
                    int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED);
                    if (vq < 0) { r = -vq - 1; break; }
                    const long pq = SEG[vq];
                    int vp = __atomic_load_n(&STOP[pq], __ATOMIC_RELAXED);
                    if (vp < 0) { r = -vp - 1; break; }
                    __atomic_compare_exchange_n(&STOP[q], &vq, vp, false, __ATOMIC_RELAXED, __ATOMIC_RELAXED);
                    q = SEG[vp];
                }
                __atomic_store_n(&STOP[s], -r - 1, __ATOMIC_RELAXED);
#else
                long q = s;
                for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) { r = -vq - 1; break; } q = SEG[vq]; }
                q = s;
                for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) break;
                           __atomic_store_n(&STOP[q], -r - 1, __ATOMIC_RELAXED); q = SEG[vq]; }
#endif
            }
            const int mn = SMIN[s];
            int cur = __atomic_load_n(&F[r], __ATOMIC_RELAXED);
            while (mn < cur && !__atomic_compare_exchange_n(&F[r], &cur, mn, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
        }
    }
    PM("wsres");
    {
        const long C = V < 64L * T ? 1 : 4L * T;
        std::vector<long> fc(C + 1, 0);
#pragma omp parallel for schedule(static)
        for (long c = 0; c < V; c++) if (D[c] == 0) indeg[F[c]] = 1;
        PM("wsflag");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            long cntk = 0;
            for (long c = lo; c < hi; c++) cntk += indeg[c] == 1;
            fc[k + 1] = cntk;
        }
        for (long k = 1; k <= C; k++) fc[k] += fc[k - 1];
        PM("wscnt");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            int lab = 100 + (int)fc[k];
            for (long c = lo; c < hi; c++) if (indeg[c] == 1) F[-STOP[SEG[c]] - 1] = ++lab;
        }
    }
    PM("wslab");
    gstop = STOP; gseg = SEG; glab = F;
    FORMAT(3);
#else
    int* R = SEG;
    int* F = acc;
    const long RB = RES_BLOCK > 0 ? RES_BLOCK : WB, NRB = (V + RB - 1) / RB;
#if NUMA_STATIC && RES_STATIC
#pragma omp parallel for schedule(static)
#else
#pragma omp parallel for schedule(dynamic, 1)
#endif
    for (long it = 0; it < NRB; it++) {
        const long b = it * RB, e = b + RB < V ? b + RB : V;
        for (long s = b; s < e; s++) {
            if (!WS2 || D[s] == 0) F[s] = INT_MAX;
            if (D[s] == NODIR || SEG[s] != (int)s) continue;
            int v = __atomic_load_n(&STOP[s], __ATOMIC_RELAXED);
            if (v < 0) continue;
            long q = s; int r;
#if WS_HALVE2
            for (;;) {
                int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED);
                if (vq < 0) { r = -vq - 1; break; }
                const long pq = SEG[vq];
                int vp = __atomic_load_n(&STOP[pq], __ATOMIC_RELAXED);
                if (vp < 0) { r = -vp - 1; break; }
                __atomic_compare_exchange_n(&STOP[q], &vq, vp, false, __ATOMIC_RELAXED, __ATOMIC_RELAXED);
                q = SEG[vp];
            }
            __atomic_store_n(&STOP[s], -r - 1, __ATOMIC_RELAXED);
#else
            for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) { r = -vq - 1; break; } q = SEG[vq]; }
            q = s;
            for (;;) { int vq = __atomic_load_n(&STOP[q], __ATOMIC_RELAXED); if (vq < 0) break;
                       __atomic_store_n(&STOP[q], -r - 1, __ATOMIC_RELAXED); q = SEG[vq]; }
#endif
        }
    }
    PM("wsres");
#if WS2
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) {
        if (D[c] == NODIR) { R[c] = -1; continue; }
        const int r = -STOP[SEG[c]] - 1;
        R[c] = r;
        int cur = __atomic_load_n(&F[r], __ATOMIC_RELAXED);
        while (c < cur && !__atomic_compare_exchange_n(&F[r], &cur, (int)c, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
    }
    {
        const long C = V < 64L * T ? 1 : 4L * T;
        PM("wsroot");
        std::vector<long> fc(C + 1, 0);
#pragma omp parallel for schedule(static)
        for (long c = 0; c < V; c++) if (D[c] == 0) indeg[F[c]] = 1;
        PM("wsflag");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            long cntk = 0;
            for (long c = lo; c < hi; c++) cntk += indeg[c] == 1;
            fc[k + 1] = cntk;
        }
        for (long k = 1; k <= C; k++) fc[k] += fc[k - 1];
        PM("wscnt");
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            int lab = 100 + (int)fc[k];
            for (long c = lo; c < hi; c++) if (indeg[c] == 1) F[R[c]] = ++lab;
        }
    }
#else
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) R[c] = D[c] == NODIR ? -1 : -STOP[SEG[c]] - 1;
#pragma omp parallel for schedule(static)
    for (long c = 0; c < V; c++) {
        if (D[c] == NODIR) continue;
        int r = R[c];
        int cur = __atomic_load_n(&F[r], __ATOMIC_RELAXED);
        while (c < cur && !__atomic_compare_exchange_n(&F[r], &cur, (int)c, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
    }
    {
        const long C = V < 64L * T ? 1 : 4L * T;
        std::vector<long> fc(C + 1, 0);
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            long cntk = 0;
            for (long c = lo; c < hi; c++) {
                unsigned char f = D[c] != NODIR && F[R[c]] == c;
                indeg[c] = f; cntk += f;
            }
            fc[k + 1] = cntk;
        }
        for (long k = 1; k <= C; k++) fc[k] += fc[k - 1];
#pragma omp parallel for schedule(static)
        for (long k = 0; k < C; k++) {
            long lo, hi; split(V, (int)C, (int)k, &lo, &hi);
            int lab = 100 + (int)fc[k];
            for (long c = lo; c < hi; c++) if (indeg[c]) F[R[c]] = ++lab;
        }
#pragma omp parallel for schedule(static)
        for (long c = 0; c < V; c++) R[c] = D[c] == NODIR ? -1 : F[R[c]];
    }
#endif
    PM("wslab");
    gi = R;
    if (WS2) glab = F;
    FORMAT(3);
#endif
    PM("fmtW");
    size_t relbytes = 0;
    for (size_t i = 0; i < late.size(); i++) relbytes += late[i].len;
    for (size_t i = 0; i < g_regions.size(); i++) relbytes += g_regions[i].len;
    for (size_t i = 0; i < g_pool.size(); i++) relbytes += g_pool[i].len;
    const bool rel = FASTREL && relbytes >= REL_MIN;
    (void)rel;
#if FASTREL
    if (rel) {
        std::vector<Region> rs = late;
        rs.insert(rs.end(), g_regions.begin(), g_regions.end());
        release_parallel(rs, T);
    }
#endif
    PM("rel1");
    if (out.async) out.th.join();
    if (omap) {
        munmap(omap, omap_len);
        if (ftruncate(ofd, obase + (off_t)opos) != 0) perror("ftruncate");
        lseek(1, obase + (off_t)opos, SEEK_SET);
        close(ofd);
    }
    PM("join");
#if FASTREL
    if (rel) release_parallel(g_pool, T);
#endif
    PM("rel2");
    if (PROF) {
        struct rusage ru; getrusage(RUSAGE_SELF, &ru);
        fprintf(stderr, "maxrss=%ld(kB-linux/B-mac) writer[wait=%.3f write=%.3f free=%.3f] ", (long)ru.ru_maxrss, out.t_wait, out.t_write, out.t_free);
    }
    if (PROF) {
        const long long rt1 = rt_ns();
        fprintf(stderr, "PAR3 T=%d n=%d m=%d", T, n, m);
        for (int k = 0; k < np; k++) fprintf(stderr, " %s=%.4f/%ld", pn[k], ph[k], pf[k]);
        fprintf(stderr, " total=%.4f ABS main0=%lld mainend=%lld minflt=%ld\n", wtime() - t0, rt0, rt1, minflt());
    }
#if FAST_EXIT
    _exit(0);
#endif
    return 0;
}
