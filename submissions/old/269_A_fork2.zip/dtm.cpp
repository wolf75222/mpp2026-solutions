#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sched.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <emmintrin.h>
#include "fastio.h"

#ifndef SMALL_MAX
#define SMALL_MAX 4000000L
#endif
#ifndef CPT
#define CPT 18000L
#endif
#ifndef TMAXP
#define TMAXP 32
#endif
#ifndef OUT_CAP
#define OUT_CAP (64 * 1024)
#endif
#ifndef POPULATE
#define POPULATE 1
#endif
#ifndef PREFAULT
#define PREFAULT 1
#endif
#ifndef HUGE
#define HUGE 0
#endif
#ifndef HUGE_MIN
#define HUGE_MIN ((size_t)1 << 20)
#endif
#ifndef PROF
#define PROF 0
#endif
#ifndef EXPER
#define EXPER 0
#endif

#if PROF
static double ptime() { struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec * 1e3 + ts.tv_nsec * 1e-6; }
static double g_pt[32]; static const char* g_pn[32]; static int g_np;
#define PM(name) do { g_pt[g_np] = ptime(); g_pn[g_np++] = name; } while (0)
#else
#define PM(name) do { } while (0)
#endif

static const unsigned NOD = 15;

#ifndef STEPMODE
#define STEPMODE 2
#endif
struct Step {
    const long* off; unsigned k; long o;
    explicit Step(const long* t) : off(t), k(0), o(0) {}
    inline long next(long c, unsigned kk);
};
static inline long step(long c, unsigned k, long M) {
    switch (k) {
    case 1: return c - M;
    case 2: return c - M + 1;
    case 3: return c + 1;
    case 4: return c + M + 1;
    case 5: return c + M;
    case 6: return c + M - 1;
    case 7: return c - 1;
    default: return c - M - 1;
    }
}
inline long Step::next(long c, unsigned kk) {
#if STEPMODE == 1
    return step(c, kk, off[5]);
#elif STEPMODE == 2
    if (kk != k) { k = kk; o = off[kk]; }
    return c + o;
#else
    return c + off[kk];
#endif
}

static char g_ob[OUT_CAP + 512] __attribute__((aligned(64)));

static void write_all(int fd, const char* b, size_t len) {
    while (len) {
        ssize_t w = write(fd, b, len);
        if (w < 0) { if (errno == EINTR) continue; perror("write"); exit(1); }
        b += w; len -= (size_t)w;
    }
}
static void writev_all(struct iovec* iov, int cnt) {
    int i = 0;
    while (i < cnt) {
        const int c = cnt - i > 1024 ? 1024 : cnt - i;
        ssize_t w = writev(1, iov + i, c);
        if (w < 0) { if (errno == EINTR) continue; perror("write"); exit(1); }
        size_t left = (size_t)w;
        while (i < cnt && left >= iov[i].iov_len) { left -= iov[i].iov_len; ++i; }
        if (i < cnt && left) { iov[i].iov_base = (char*)iov[i].iov_base + left; iov[i].iov_len -= left; }
    }
}
template <bool S> static inline char* ensure(char* q, size_t need) {
    if (S && (size_t)(q - g_ob) + need > (size_t)OUT_CAP) { write_all(1, g_ob, (size_t)(q - g_ob)); q = g_ob; }
    return q;
}
template <bool S> static char* put_str(char* q, const char* s) {
    const size_t l = strlen(s);
    q = ensure<S>(q, l);
    memcpy(q, s, l);
    return q + l;
}
template <bool S> static char* put_ghost(char* q, const char* tok, long M) {
    const size_t tl = strlen(tok);
    for (long j = 0; j < M;) {
        const long b = M - j < 4096 ? M - j : 4096;
        q = ensure<S>(q, (size_t)b * 3 + 1);
        if (tl == 2) for (long k = 0; k < b; k++) { memcpy(q, tok, 2); q += 2; }
        else for (long k = 0; k < b; k++) { memcpy(q, tok, 3); q += 3; }
        j += b;
    }
    q = ensure<S>(q, 1);
    *q++ = '\n';
    return q;
}

static inline const char* ptok(const char* p, float* out) {
    const char* const s = p;
    const unsigned neg = *p == '-';
    p += neg;
    uint32_t m = (uint32_t)(unsigned char)*p - '0';
    if (m > 9) return fio::parse_float(s, out);
    const char* const d0 = p;
    ++p;
    uint32_t d;
    while ((d = (uint32_t)(unsigned char)*p - '0') <= 9) { m = m * 10 + d; ++p; }
    long nd = p - d0;
    long e10 = 0;
    if (*p == '.') {
        ++p;
        const char* const f0 = p;
        while ((d = (uint32_t)(unsigned char)*p - '0') <= 9) { m = m * 10 + d; ++p; }
        e10 = f0 - p;
        nd -= e10;
    }
    if (nd > 9 || (unsigned char)*p > ' ' || m >= (1u << 24)) return fio::parse_float(s, out);
    float f = (float)m;
    if (e10) f /= fio::P10F[-e10];
    *out = neg ? -f : f;
    return p;
}

static inline char* put4(char* p, uint32_t v) {
    if (v < 100) {
        if (v < 10) { *p = (char)('0' + v); return p + 1; }
        memcpy(p, fio::DIG2 + 2 * v, 2); return p + 2;
    }
    const uint32_t h = v / 100, l = v - 100 * h;
    if (v < 1000) { p[0] = (char)('0' + h); memcpy(p + 1, fio::DIG2 + 2 * l, 2); return p + 3; }
    memcpy(p, fio::DIG2 + 2 * h, 2); memcpy(p + 2, fio::DIG2 + 2 * l, 2); return p + 4;
}
static inline char* pu32(char* p, uint32_t v) {
    if (v < 10000) return put4(p, v);
    if (v < 100000000) {
        const uint32_t h = v / 10000, l = v - 10000 * h;
        p = put4(p, h);
        const uint32_t a = l / 100, b = l - 100 * a;
        memcpy(p, fio::DIG2 + 2 * a, 2); memcpy(p + 2, fio::DIG2 + 2 * b, 2);
        return p + 4;
    }
    return fio::put_u32(p, v);
}

static inline char* g6_slow(char* p, float f) {
    char t[48];
    const int n = snprintf(t, sizeof t, "%g", (double)f);
    memcpy(p, t, (size_t)n);
    return p + n;
}
static inline char* g6(char* p, float f) {
    const double v = (double)f;
    const double a = __builtin_fabs(v);
    if (!(a < 1e6)) return g6_slow(p, f);
    if (__builtin_signbit(v)) *p++ = '-';
    if (a == 0.0) { *p++ = '0'; return p; }
    const uint32_t ia = (uint32_t)a;
    if ((double)ia == a) return pu32(p, ia);
    int X;
    double s;
    if (a >= 1.0) {
        X = a >= 1e5 ? 5 : a >= 1e4 ? 4 : a >= 1e3 ? 3 : a >= 1e2 ? 2 : a >= 1e1 ? 1 : 0;
        s = a * fio::P10D[5 - X];
    } else {
        X = -1;
        s = a * fio::P10D[6];
        while (s < 1e5) {
            if (X == -4) { if (v < 0) --p; return g6_slow(p, f); }
            --X; s *= 10.0;
        }
    }
    uint32_t r = (uint32_t)s;
    const double fr = s - (double)r;
    if (fr > 0.5 || (fr == 0.5 && (r & 1u))) r++;
    if (r >= 1000000u) { r = 100000u; X++; if (X >= 6) { if (v < 0) --p; return g6_slow(p, f); } }
    uint64_t w;
    {
        uint16_t a2, b2, c2;
        memcpy(&a2, fio::DIG2 + 2 * (r / 10000), 2);
        memcpy(&b2, fio::DIG2 + 2 * ((r / 100) % 100), 2);
        memcpy(&c2, fio::DIG2 + 2 * (r % 100), 2);
        w = (uint64_t)a2 | ((uint64_t)b2 << 16) | ((uint64_t)c2 << 32);
    }
    const uint64_t z = w ^ 0x0000303030303030ULL;
    const uint64_t nz = (((z & 0x7f7f7f7f7f7f7f7fULL) + 0x7f7f7f7f7f7f7f7fULL) | z) & 0x0000808080808080ULL;
    const int last = (63 - __builtin_clzll(nz)) >> 3;
    if (X >= 0) {
        memcpy(p, &w, 8);
        if (last > X) {
            p[X + 1] = '.';
            const uint64_t fw = w >> (8 * (X + 1));
            memcpy(p + X + 2, &fw, 8);
            p += last + 2;
        } else p += X + 1;
    } else {
        memcpy(p, "0.000000", 8);
        memcpy(p + 1 - X, &w, 8);
        p += 2 - X + last;
    }
    return p;
}

static long count_tokens(const char* s, const char* e) {
    long c = 0;
    const char* q = s;
    const __m128i sp = _mm_set1_epi8(' ');
    const __m128i zero = _mm_setzero_si128();
    while (e - q >= 16) {
        long it = (e - q) / 16; if (it > 255) it = 255;
        __m128i acc = zero;
        for (long k = 0; k < it; k++, q += 16) {
            const __m128i cur = _mm_loadu_si128((const __m128i*)q);
            const __m128i prv = _mm_loadu_si128((const __m128i*)(q - 1));
            const __m128i wc = _mm_cmpeq_epi8(_mm_max_epu8(cur, sp), sp);
            const __m128i wp = _mm_cmpeq_epi8(_mm_max_epu8(prv, sp), sp);
            acc = _mm_sub_epi8(acc, _mm_andnot_si128(wc, wp));
        }
        const __m128i sad = _mm_sad_epu8(acc, zero);
        c += _mm_cvtsi128_si64(sad) + _mm_cvtsi128_si64(_mm_unpackhi_epi64(sad, sad));
    }
    for (; q < e; ++q) c += ((unsigned char)q[0] > ' ') & ((unsigned char)q[-1] <= ' ');
    return c;
}
static const char* skip_tokens(const char* s, const char* e, long k) {
    const char* q = s;
    const __m128i sp = _mm_set1_epi8(' ');
    while (e - q >= 16) {
        const __m128i cur = _mm_loadu_si128((const __m128i*)q);
        const __m128i prv = _mm_loadu_si128((const __m128i*)(q - 1));
        unsigned msk = (unsigned)_mm_movemask_epi8(_mm_andnot_si128(_mm_cmpeq_epi8(_mm_max_epu8(cur, sp), sp),
                                                                  _mm_cmpeq_epi8(_mm_max_epu8(prv, sp), sp)));
        const long c = __builtin_popcount(msk);
        if (c > k) { while (k--) msk &= msk - 1; return q + __builtin_ctz(msk); }
        k -= c; q += 16;
    }
    for (; q < e; ++q)
        if (((unsigned char)q[0] > ' ') & ((unsigned char)q[-1] <= ' ')) { if (k == 0) return q; --k; }
    return e;
}

static const char* parse_row(const char* p, const char* end, float* r, float* e, long M, float nv, int* bad) {
    for (long j = 0; j < M; j++) {
        while (p < end && (unsigned char)*p <= ' ') ++p;
        if (p >= end) { for (; j < M; j++) r[j] = 0.0f; break; }
        p = ptok(p, &r[j]);
        if ((unsigned char)*p > ' ') *bad = 1;
    }
    const __m128 vnv = _mm_set1_ps(nv), inf = _mm_set1_ps(__builtin_inff());
    long j = 0;
    for (; j + 4 <= M; j += 4) {
        const __m128 x = _mm_loadu_ps(r + j);
        const __m128 c = _mm_cmpeq_ps(x, vnv);
        _mm_storeu_ps(e + j, _mm_or_ps(_mm_and_ps(c, inf), _mm_andnot_ps(c, x)));
    }
    for (; j < M; j++) e[j] = r[j] == nv ? __builtin_inff() : r[j];
    e[-1] = __builtin_inff(); e[M] = __builtin_inff();
    return p;
}

static void dir_row(const float* up, const float* e, const float* dn, const float* r, uint8_t* d, long M, float nv) {
    long j = 0;
    const long J = M - 1;
    const __m128 vnv = _mm_set1_ps(nv);
    const __m128i k15 = _mm_set1_epi32((int)NOD);
    for (; j + 16 <= J; j += 16) {
        __m128i c4[4];
        for (int u = 0; u < 4; u++) {
            const long q = j + 4 * u;
            __m128 mn = _mm_loadu_ps(e + q);
            __m128i code = _mm_setzero_si128();
#define SD(PTR, K) { const __m128 x = _mm_loadu_ps(PTR); const __m128 c = _mm_cmplt_ps(x, mn); mn = _mm_min_ps(x, mn); \
            code = _mm_max_epi16(code, _mm_and_si128(_mm_castps_si128(c), _mm_set1_epi32(K))); }
            SD(up + q, 1) SD(up + q + 1, 2) SD(e + q + 1, 3) SD(dn + q + 1, 4)
            SD(dn + q, 5) SD(dn + q - 1, 6) SD(e + q - 1, 7) SD(up + q - 1, 8)
#undef SD
            const __m128i valid = _mm_castps_si128(_mm_cmpneq_ps(_mm_loadu_ps(r + q), vnv));
            c4[u] = _mm_or_si128(_mm_and_si128(valid, code), _mm_andnot_si128(valid, k15));
        }
        const __m128i a = _mm_packs_epi32(c4[0], c4[1]), b = _mm_packs_epi32(c4[2], c4[3]);
        _mm_storeu_si128((__m128i*)(d + j), _mm_packus_epi16(a, b));
    }
#define STEPD(x, kk) { const float xx = (x); const bool c = xx < mn; mn = c ? xx : mn; code = c ? (kk) : code; }
    for (; j < J; j++) {
        float mn = e[j]; int code = 0;
        STEPD(up[j], 1) STEPD(up[j + 1], 2) STEPD(e[j + 1], 3) STEPD(dn[j + 1], 4)
        STEPD(dn[j], 5) STEPD(dn[j - 1], 6) STEPD(e[j - 1], 7) STEPD(up[j - 1], 8)
        d[j] = r[j] != nv ? (uint8_t)code : (uint8_t)NOD;
    }
    {
        float mn = e[J]; int code = 0;
        STEPD(dn[J], 5) STEPD(dn[J - 1], 6) STEPD(e[J - 1], 7) STEPD(up[J - 1], 8) STEPD(up[J], 1)
        d[J] = r[J] != nv ? (uint8_t)code : (uint8_t)NOD;
    }
#undef STEPD
}

static void indeg_row(uint8_t* D, long c0, long M) {
    long j = 0;
    const __m128i m0f = _mm_set1_epi8(0x0F);
    for (; j + 16 <= M; j += 16) {
        const long c = c0 + j;
        __m128i cnt = _mm_setzero_si128();
#define IG(OFF, K) cnt = _mm_sub_epi8(cnt, _mm_cmpeq_epi8(_mm_and_si128(_mm_loadu_si128((const __m128i*)(D + c + (OFF))), m0f), _mm_set1_epi8(K)));
        IG(-M, 5) IG(-M + 1, 6) IG(1, 7) IG(M + 1, 8) IG(M, 1) IG(M - 1, 2) IG(-1, 3) IG(-M - 1, 4)
#undef IG
        const __m128i cur = _mm_loadu_si128((const __m128i*)(D + c));
        _mm_storeu_si128((__m128i*)(D + c), _mm_or_si128(cur, _mm_slli_epi16(cnt, 4)));
    }
    for (; j < M; j++) {
        const long c = c0 + j;
        const int k = ((D[c - M] & 15) == 5) + ((D[c - M + 1] & 15) == 6) + ((D[c + 1] & 15) == 7) + ((D[c + M + 1] & 15) == 8)
                    + ((D[c + M] & 15) == 1) + ((D[c + M - 1] & 15) == 2) + ((D[c - 1] & 15) == 3) + ((D[c - M - 1] & 15) == 4);
        D[c] = (uint8_t)(D[c] | (k << 4));
    }
}

static inline void walk(uint8_t* D, uint32_t* A, long c, const long* off) {
    unsigned k = D[c] & 15u;
    uint32_t a = 1;
    Step st(off);
    while (k != 0) {
        const long x = st.next(c, k);
        const uint32_t ax = A[x] + a;
        A[x] = ax;
        const unsigned bx = D[x];
        if (bx >= 0x20u) { D[x] = (uint8_t)(bx - 0x10u); return; }
        D[x] = (uint8_t)(bx | 0xF0u);
        a = ax + 1; c = x; k = bx & 15u;
    }
}
static void walk_all(uint8_t* D, uint32_t* A, long V, const long* off) {
    const __m128i mf0 = _mm_set1_epi8((char)0xF0), m0f = _mm_set1_epi8(0x0F), k15 = _mm_set1_epi8((char)NOD);
    const __m128i zero = _mm_setzero_si128();
    long c0 = 0;
    for (; c0 + 16 <= V; c0 += 16) {
        const __m128i v = _mm_loadu_si128((const __m128i*)(D + c0));
        const __m128i src = _mm_andnot_si128(_mm_cmpeq_epi8(_mm_and_si128(v, m0f), k15), _mm_cmpeq_epi8(_mm_and_si128(v, mf0), zero));
        unsigned msk = (unsigned)_mm_movemask_epi8(src);
        while (msk) { const int b = __builtin_ctz(msk); msk &= msk - 1; walk(D, A, c0 + b, off); }
    }
    for (; c0 < V; c0++) {
        const unsigned b = D[c0];
        if ((b & 0xF0u) == 0 && (b & 15u) != NOD) walk(D, A, c0, off);
    }
}
static inline uint32_t label_of(const uint8_t* D, uint32_t* A, long c, const long* off, uint32_t* num) {
    const unsigned k = D[c] & 15u;
    if (k == 0) { const uint32_t L = ++*num; A[c] = L; return L; }
    Step st(off);
    uint32_t L = A[st.next(c, k)];
    if (L) { A[c] = L; return L; }
    long x = c;
    for (;;) {
        L = A[x];
        if (L) break;
        const unsigned kx = D[x] & 15u;
        if (kx == 0) { L = ++*num; A[x] = L; break; }
        x = st.next(x, kx);
    }
    x = c;
    while (A[x] == 0) { A[x] = L; x = st.next(x, D[x] & 15u); }
    return L;
}

template <bool S> static char* fmt_terrain_row(char* q, const float* r, long M) {
    for (long j = 0; j < M;) {
        const long b = M - j < 2048 ? M - j : 2048;
        q = ensure<S>(q, (size_t)b * 16 + 32);
        for (const long e = j + b; j < e; j++) { q = g6(q, r[j]); *q++ = ' '; }
    }
    q = ensure<S>(q, 1);
    *q++ = '\n';
    return q;
}
template <bool S> static char* fmt_dir_row(char* q, const uint8_t* r, long M) {
    const __m128i m0f = _mm_set1_epi8(0x0F), k15 = _mm_set1_epi8((char)NOD);
    const __m128i z0 = _mm_set1_epi8('0'), spc = _mm_set1_epi8(' ');
    for (long j = 0; j < M;) {
        const long b = M - j < 2048 ? M - j : 2048;
        q = ensure<S>(q, (size_t)b * 3 + 32);
        const long e = j + b;
        for (; j + 16 <= e; j += 16) {
            const __m128i v = _mm_and_si128(_mm_loadu_si128((const __m128i*)(r + j)), m0f);
            if (_mm_movemask_epi8(_mm_cmpeq_epi8(v, k15))) {
                for (int k = 0; k < 16; k++) {
                    const unsigned d = r[j + k] & 15u;
                    if (d != NOD) { q[0] = (char)('0' + d); q[1] = ' '; q += 2; }
                    else { q[0] = '-'; q[1] = '9'; q[2] = ' '; q += 3; }
                }
                continue;
            }
            const __m128i c = _mm_add_epi8(v, z0);
            _mm_storeu_si128((__m128i*)q, _mm_unpacklo_epi8(c, spc));
            _mm_storeu_si128((__m128i*)(q + 16), _mm_unpackhi_epi8(c, spc));
            q += 32;
        }
        for (; j < e; j++) {
            const unsigned d = r[j] & 15u;
            if (d != NOD) { q[0] = (char)('0' + d); q[1] = ' '; q += 2; }
            else { q[0] = '-'; q[1] = '9'; q[2] = ' '; q += 3; }
        }
    }
    q = ensure<S>(q, 1);
    *q++ = '\n';
    return q;
}
template <bool S> static char* fmt_acc_row(char* q, const uint8_t* d, uint32_t* a, long M) {
    for (long j = 0; j < M;) {
        const long b = M - j < 2048 ? M - j : 2048;
        q = ensure<S>(q, (size_t)b * 12 + 32);
        for (const long e = j + b; j < e; j++) {
            if ((d[j] & 15u) == NOD) { q[0] = '-'; q[1] = '1'; q[2] = ' '; q += 3; }
            else { q = pu32(q, a[j] + 1); *q++ = ' '; }
            a[j] = 0;
        }
    }
    q = ensure<S>(q, 1);
    *q++ = '\n';
    return q;
}
struct LabCache { uint32_t llab; int llen; char lbuf[16]; };
template <bool S, bool RES> static char* fmt_ws_row(char* q, const uint8_t* D, uint32_t* A, long r0, long M,
                                                  const long* off, uint32_t* num, LabCache* lc) {
    uint32_t llab = lc->llab; int llen = lc->llen;
    for (long j = 0; j < M;) {
        const long b = M - j < 2048 ? M - j : 2048;
        q = ensure<S>(q, (size_t)b * 12 + 32);
        for (const long e = j + b; j < e; j++) {
            const long c = r0 + j;
            if ((D[c] & 15u) == NOD) { q[0] = '-'; q[1] = '1'; q[2] = ' '; q += 3; continue; }
            uint32_t L = A[c];
            if (RES && !L) L = label_of(D, A, c, off, num);
            if (L != llab) { llab = L; llen = (int)(pu32(lc->lbuf, L) - lc->lbuf); lc->lbuf[llen] = ' '; }
            memcpy(q, lc->lbuf, 16); q += llen + 1;
        }
    }
    lc->llab = llab; lc->llen = llen;
    q = ensure<S>(q, 1);
    *q++ = '\n';
    return q;
}

struct Grid {
    const char* text;
    const char* end;
    int n; long M, V; float nv;
    uint8_t* D;
    uint32_t* A;
    float* rows;
    long off[9];
};
static Grid g;
static float* g_trows[TMAXP];
static float* row_slot(int t, int s) { return (g_trows[t] ? g_trows[t] : g.rows) + (size_t)s * ((size_t)g.M + 8) + 4; }
static float* ghost_e(int t) {
    float* e = row_slot(t, 7);
    for (long j = -1; j <= g.M; j++) e[j] = __builtin_inff();
    return e;
}

static void run_serial() {
    const long M = g.M, V = g.V; const int n = g.n; const float nv = g.nv;
    uint8_t* const D = g.D; uint32_t* const A = g.A;
    const char* p = g.text; const char* const end = g.end;
    int bad = 0;
    float* r[3] = {row_slot(0, 0), row_slot(0, 1), row_slot(0, 2)};
    float* e[3] = {row_slot(0, 3), row_slot(0, 4), row_slot(0, 5)};
    float* const ge = ghost_e(0);
    char* q = g_ob;
    q = put_str<true>(q, "the terrain\n");
    {
        const float* pe = ge;
        int cur = 0;
        p = parse_row(p, end, r[0], e[0], M, nv, &bad);
        q = fmt_terrain_row<true>(q, r[0], M);
        for (long i = 0; i < n; i++) {
            const int nx = cur == 2 ? 0 : cur + 1;
            const float* ne;
            if (i + 1 < n) {
                p = parse_row(p, end, r[nx], e[nx], M, nv, &bad);
                q = fmt_terrain_row<true>(q, r[nx], M);
                ne = e[nx];
            } else ne = ge;
            dir_row(pe, e[cur], ne, r[cur], D + i * M, M, nv);
            if (i >= 1) indeg_row(D, (i - 1) * M, M);
            pe = e[cur]; cur = nx;
        }
        indeg_row(D, (long)(n - 1) * M, M);
    }
    PM("p1");
    q = put_str<true>(q, "the directions\n");
    q = put_ghost<true>(q, "1 ", M);
    for (long i = 0; i < n; i++) q = fmt_dir_row<true>(q, D + i * M, M);
    q = put_ghost<true>(q, "5 ", M);
    PM("fmtD");
    walk_all(D, A, V, g.off);
    PM("walk");
    q = put_str<true>(q, "flow accumulation \n");
    q = put_ghost<true>(q, "0 ", M);
    for (long i = 0; i < n; i++) q = fmt_acc_row<true>(q, D + i * M, A + i * M, M);
    q = put_ghost<true>(q, "0 ", M);
    PM("fmtA");
    q = put_str<true>(q, "watersheds\n");
    q = put_ghost<true>(q, "-1 ", M);
    {
        uint32_t num = 100;
        LabCache lc; lc.llab = 0; lc.llen = 0; memset(lc.lbuf, 0, sizeof lc.lbuf);
        for (long i = 0; i < n; i++) q = fmt_ws_row<true, true>(q, D, A, i * M, M, g.off, &num, &lc);
    }
    q = put_ghost<true>(q, "-1 ", M);
    write_all(1, g_ob, (size_t)(q - g_ob));
    PM("fmtW");
}

static int g_T;
struct alignas(64) Slot {
    char* buf; size_t len;
    int ready;
    int written;
};
static Slot g_slot[TMAXP];
static long g_cnt[TMAXP];
static const char* g_cut[TMAXP + 1];
static int g_bad;
struct alignas(64) Bar { int cnt; char pad[60]; int gen; };
static Bar g_bar;
static pthread_t g_th[TMAXP];
static char* g_gh[2];

#ifndef SPIN
#define SPIN 4000
#endif
static int g_sleep;
static inline void futex_wait(const int* a, int v) { syscall(SYS_futex, a, 128  , v, 0, 0, 0); }
static inline void wake_all(const int* a) {
    if (__atomic_load_n(&g_sleep, __ATOMIC_SEQ_CST)) syscall(SYS_futex, a, 129  , 0x7fffffff, 0, 0, 0);
}
static void spin_until_ge(const int* x, int v) {
    for (unsigned s = 0; __atomic_load_n(x, __ATOMIC_ACQUIRE) < v; s++) {
        _mm_pause();
        if (s >= SPIN) {
            __atomic_add_fetch(&g_sleep, 1, __ATOMIC_SEQ_CST);
            for (int c; (c = __atomic_load_n(x, __ATOMIC_SEQ_CST)) < v;) futex_wait(x, c);
            __atomic_sub_fetch(&g_sleep, 1, __ATOMIC_SEQ_CST);
            return;
        }
    }
}
static inline void store_wake(int* x, int v) { __atomic_store_n(x, v, __ATOMIC_SEQ_CST); wake_all(x); }
static void barrier() {
    const int gen = __atomic_load_n(&g_bar.gen, __ATOMIC_ACQUIRE);
    if (__atomic_add_fetch(&g_bar.cnt, 1, __ATOMIC_ACQ_REL) == g_T) {
        __atomic_store_n(&g_bar.cnt, 0, __ATOMIC_RELAXED);
        store_wake(&g_bar.gen, gen + 1);
        return;
    }
    spin_until_ge(&g_bar.gen, gen + 1);
}
static void exec_par(const char* data, size_t len, bool from_file);
static const char* g_in; static size_t g_inlen; static bool g_from_file;

static void band_ready(Slot& s, char* q) {
    s.len = (size_t)(q - s.buf);
    store_wake(&s.ready, s.ready + 1);
}
static void write_section(int sec, const char* hdr, const char* gtop, size_t gtl, const char* gbot, size_t gbl) {
    struct iovec iov[TMAXP + 3];
    int c = 0;
    iov[c].iov_base = (void*)hdr; iov[c].iov_len = strlen(hdr); c++;
    if (gtop) { iov[c].iov_base = (void*)gtop; iov[c].iov_len = gtl; c++; }
    for (int t = 0; t < g_T; t++) {
        spin_until_ge(&g_slot[t].ready, sec + 1);
        iov[c].iov_base = g_slot[t].buf; iov[c].iov_len = g_slot[t].len; c++;
    }
    if (gbot) { iov[c].iov_base = (void*)gbot; iov[c].iov_len = gbl; c++; }
    writev_all(iov, c);
    for (int t = 0; t < g_T; t++) store_wake(&g_slot[t].written, sec + 1);
}
static size_t ghost_rows(int k, const char* tok, long M) {
    const size_t need = (size_t)M * 3 + 2;
    if (!g_gh[k]) g_gh[k] = 2 * need <= (size_t)OUT_CAP ? g_ob + (size_t)k * need : (char*)malloc(need);
    if (!g_gh[k]) { perror("malloc"); exit(1); }
    return (size_t)(put_ghost<false>(g_gh[k], tok, M) - g_gh[k]);
}

static inline void walk_par(uint8_t* D, uint32_t* A, long c, const long* off) {
    unsigned k = D[c] & 15u;
    uint32_t a = 1;
    Step st(off);
    while (k != 0) {
        const long x = st.next(c, k);
        unsigned cur = __atomic_load_n(&D[x], __ATOMIC_ACQUIRE);
        if ((cur >> 4) == 1) {
            const uint32_t ax = __atomic_load_n(&A[x], __ATOMIC_RELAXED) + a;
            __atomic_store_n(&A[x], ax, __ATOMIC_RELAXED);
            __atomic_store_n(&D[x], (uint8_t)(cur | 0xF0u), __ATOMIC_RELAXED);
            a = ax + 1; c = x; k = cur & 15u;
            continue;
        }
        __atomic_fetch_add(&A[x], a, __ATOMIC_RELAXED);
        for (;;) {
            uint8_t ex = (uint8_t)cur;
            const uint8_t nw = (uint8_t)((cur >> 4) == 1 ? (cur | 0xF0u) : cur - 0x10u);
            if (__atomic_compare_exchange_n(&D[x], &ex, nw, false, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE)) break;
            cur = ex;
        }
        if ((cur >> 4) != 1) return;
        a = __atomic_load_n(&A[x], __ATOMIC_RELAXED) + 1; c = x; k = cur & 15u;
    }
}
static long g_nsrc[TMAXP];
static inline unsigned src_mask16(const uint8_t* p) {
    const __m128i v = _mm_loadu_si128((const __m128i*)p);
    const __m128i src = _mm_andnot_si128(_mm_cmpeq_epi8(_mm_and_si128(v, _mm_set1_epi8(0x0F)), _mm_set1_epi8((char)NOD)),
                                         _mm_cmpeq_epi8(_mm_and_si128(v, _mm_set1_epi8((char)0xF0)), _mm_setzero_si128()));
    return (unsigned)_mm_movemask_epi8(src);
}
static long count_sources(const uint8_t* D, long c0, long c1) {
    long k = 0, c = c0;
    for (; c + 16 <= c1; c += 16) k += __builtin_popcount(src_mask16(D + c));
    for (; c < c1; c++) k += (D[c] & 0xF0u) == 0 && (D[c] & 15u) != NOD;
    return k;
}
static void walk_share(int t) {
    uint8_t* const D = g.D; uint32_t* const A = g.A; const long* const off = g.off;
    const int T = g_T; const int n = g.n; const long M = g.M;
    long S = 0;
    for (int k = 0; k < T; k++) S += g_nsrc[k];
    const long k0 = S * t / T, k1 = S * (t + 1) / T;
    if (k0 >= k1) return;
    int b = 0; long pre = 0;
    while (b < T - 1 && pre + g_nsrc[b] <= k0) { pre += g_nsrc[b]; b++; }
    long c = (long)n * b / T * M;
    long skip = k0 - pre, left = k1 - k0;
    const long V = g.V;
    for (; c < V && left > 0;) {
        if (c + 16 <= V) {
            unsigned msk = src_mask16(D + c);
            const long pc = __builtin_popcount(msk);
            if (pc <= skip) { skip -= pc; c += 16; continue; }
            while (skip > 0) { msk &= msk - 1; skip--; }
            while (msk && left > 0) { const int x = __builtin_ctz(msk); msk &= msk - 1; walk_par(D, A, c + x, off); left--; }
            c += 16;
        } else {
            if ((D[c] & 0xF0u) == 0 && (D[c] & 15u) != NOD) {
                if (skip > 0) skip--;
                else { walk_par(D, A, c, off); left--; }
            }
            c++;
        }
    }
}

static const uint32_t HIGH = 0x80000000u;
static long* g_exits[TMAXP];
static char* g_reg; static size_t g_regsz, g_rowsz, g_exitsz, g_fminsz;
static long g_nexit[TMAXP], g_nsink[TMAXP], g_nfirst[TMAXP];
static uint32_t* g_fminb[TMAXP];
static inline uint32_t* fmin_of(uint32_t s) { return g_fminb[s >> 25] + (s & 0x1FFFFFFu); }
static void local_roots(int t, long c0, long c1) {
    uint8_t* const D = g.D; uint32_t* const A = g.A;
    Step st(g.off);
    long ne = 0, ns = 0;
    long* ex = g_exits[t];
    for (long c = c0; c < c1; c++) {
        const unsigned kc = D[c] & 15u;
        if (kc == NOD) continue;
        if (kc == 0) { ns++; A[c] = (uint32_t)c + 1; continue; }
        if (A[c]) continue;
        long x = c;
        uint32_t R;
        for (;;) {
            if (x < c0 || x >= c1) { R = (uint32_t)x + 1; ex[ne++] = x; break; }
            const uint32_t ax = A[x];
            if (ax) { R = ax; break; }
            const unsigned kx = D[x] & 15u;
            if (kx == 0) { R = (uint32_t)x + 1; A[x] = R; break; }
            x = st.next(x, kx);
        }
        for (long y = c; y >= c0 && y < c1 && A[y] == 0; y = st.next(y, D[y] & 15u)) A[y] = R;
    }
    g_nexit[t] = ne; g_nsink[t] = ns;
}
static void resolve_exits() {
    uint8_t* const D = g.D; uint32_t* const A = g.A;
    for (int t = 0; t < g_T; t++)
        for (long i = 0; i < g_nexit[t]; i++) {
            const long x = g_exits[t][i];
            if ((D[x] & 15u) == 0) continue;
            long y = x;
            while ((D[y] & 15u) != 0) y = (long)A[y] - 1;
            A[x] = (uint32_t)y + 1;
        }
}
static const uint32_t DIRECT = 0x40000000u;
static void number_sinks(int t, long c0, long c1) {
    uint8_t* const D = g.D; uint32_t* const A = g.A;
    uint32_t s = (uint32_t)t << 25;
    for (long c = c0; c < c1; c++)
        if ((D[c] & 15u) == 0) __atomic_store_n(&A[c], D[c] == 0 ? HIGH | DIRECT : HIGH | s++, __ATOMIC_RELAXED);
}
static inline uint32_t sink_number(const uint32_t* A, long c) {
    uint32_t x = __atomic_load_n(&A[c], __ATOMIC_RELAXED);
    while (!(x & HIGH)) x = __atomic_load_n(&A[x - 1], __ATOMIC_RELAXED);
    return x & ~HIGH;
}
static void basin_min(long c0, long c1) {
    uint8_t* const D = g.D; uint32_t* const A = g.A;
    const uint32_t V = (uint32_t)g.V;
    uint32_t last = HIGH;
    for (long c = c0; c < c1; c++) {
        const unsigned d = D[c];
        if ((d & 15u) == NOD || d == 0) continue;
        const uint32_t s = sink_number(A, c);
        __atomic_store_n(&A[c], HIGH | s, __ATOMIC_RELAXED);
        if (s == last) continue;
        last = s;
        const uint32_t v = V - (uint32_t)c;
        uint32_t* const f = fmin_of(s);
        uint32_t cur = __atomic_load_n(f, __ATOMIC_RELAXED);
        while (v > cur && !__atomic_compare_exchange_n(f, &cur, v, true, __ATOMIC_RELAXED, __ATOMIC_RELAXED)) {}
    }
}
static void count_firsts(int t, long c0, long c1) {
    uint8_t* const D = g.D; const uint32_t* const A = g.A;
    const uint32_t V = (uint32_t)g.V;
    long f = 0;
    for (long c = c0; c < c1; c++) {
        const unsigned d = D[c];
        if ((d & 15u) == NOD) continue;
        f += d == 0 || *fmin_of(A[c] & ~HIGH) == V - (uint32_t)c;
    }
    g_nfirst[t] = f;
}
static void assign_labels(int t, long c0, long c1) {
    uint8_t* const D = g.D; uint32_t* const A = g.A;
    const uint32_t V = (uint32_t)g.V;
    uint32_t lab = 100;
    for (int k = 0; k < t; k++) lab += (uint32_t)g_nfirst[k];
    for (long c = c0; c < c1; c++) {
        const unsigned d = D[c];
        if ((d & 15u) == NOD) continue;
        if (d == 0) { A[c] = HIGH | DIRECT | ++lab; continue; }
        uint32_t* const fp = fmin_of(A[c] & ~HIGH);
        if (__atomic_load_n(fp, __ATOMIC_RELAXED) == V - (uint32_t)c) __atomic_store_n(fp, HIGH | ++lab, __ATOMIC_RELAXED);
    }
}
static char* fmt_ws_row_par(char* q, const uint8_t* D, const uint32_t* A, long r0, long M, LabCache* lc) {
    uint32_t llab = lc->llab; int llen = lc->llen;
    for (long j = 0; j < M; j++) {
        const long c = r0 + j;
        if ((D[c] & 15u) == NOD) { q[0] = '-'; q[1] = '1'; q[2] = ' '; q += 3; continue; }
        const uint32_t x = A[c];
        const uint32_t L = (x & DIRECT) ? x & ~(HIGH | DIRECT) : *fmin_of(x & ~HIGH) & ~HIGH;
        if (L != llab) { llab = L; llen = (int)(pu32(lc->lbuf, L) - lc->lbuf); lc->lbuf[llen] = ' '; }
        memcpy(q, lc->lbuf, 16); q += llen + 1;
    }
    lc->llab = llab; lc->llen = llen;
    *q++ = '\n';
    return q;
}

static void* band_main(void* arg);
#ifndef PIN
#define PIN 1
#endif
#ifndef STACK
#define STACK (256 * 1024)
#endif
#if PIN
static int g_cpu[TMAXP];
#endif
static void spawn_children(int t) {
    for (int c = 2 * t + 1; c <= 2 * t + 2 && c < g_T; c++) {
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setstacksize(&at, (size_t)STACK);
#if PIN
        cpu_set_t cs; CPU_ZERO(&cs); CPU_SET(g_cpu[c], &cs);
        pthread_attr_setaffinity_np(&at, sizeof cs, &cs);
#endif
        if (pthread_create(&g_th[c], &at, band_main, (void*)(intptr_t)c) != 0) { perror("pthread_create"); exit(1); }
        pthread_attr_destroy(&at);
    }
}
#if PROF
static double g_tt[TMAXP][32]; static int g_ntt[TMAXP];
#define TT() do { tt[ntt++] = ptime(); } while (0)
#else
#define TT() do { } while (0)
#endif
static void band_work(int t) {
#if PROF
    double tt[32]; int ntt = 0;
#endif
    TT();
    spawn_children(t);
    TT();
    const int T = g_T, n = g.n; const long M = g.M; const float nv = g.nv;
    uint8_t* const D = g.D; uint32_t* const A = g.A;
    Slot& sl = g_slot[t];
    const long r0 = (long)n * t / T, r1 = (long)n * (t + 1) / T;
    {
        char* rg = g_reg + (size_t)t * g_regsz;
        g_trows[t] = (float*)rg; rg += g_rowsz;
        g_exits[t] = (long*)rg; rg += g_exitsz;
        g_fminb[t] = (uint32_t*)rg; rg += g_fminsz;
        sl.buf = rg;
    }
    g_cnt[t] = count_tokens(g_cut[t], g_cut[t + 1]);
    TT();
    barrier();
    TT();
    const char* p = g.end;
    {
        const long want = (r0 > 0 ? r0 - 1 : 0) * M;
        long pre = 0;
        for (int k = 0; k < T; k++) {
            if (want < pre + g_cnt[k]) { p = skip_tokens(g_cut[k], g_cut[k + 1], want - pre); break; }
            pre += g_cnt[k];
        }
    }
    {
        int bad = 0;
        float* r[3] = {row_slot(t, 0), row_slot(t, 1), row_slot(t, 2)};
        float* e[3] = {row_slot(t, 3), row_slot(t, 4), row_slot(t, 5)};
        float* const ge = ghost_e(t);
        char* q = sl.buf;
        const float* pe = ge;
        int cur = 0;
        if (r0 > 0) { p = parse_row(p, g.end, r[2], e[2], M, nv, &bad); pe = e[2]; }
        p = parse_row(p, g.end, r[0], e[0], M, nv, &bad);
        q = fmt_terrain_row<false>(q, r[0], M);
        for (long i = r0; i < r1; i++) {
            const int nx = cur == 2 ? 0 : cur + 1;
            const float* ne;
            if (i + 1 < n) {
                p = parse_row(p, g.end, r[nx], e[nx], M, nv, &bad);
                if (i + 1 < r1) q = fmt_terrain_row<false>(q, r[nx], M);
                ne = e[nx];
            } else ne = ge;
            dir_row(pe, e[cur], ne, r[cur], D + i * M, M, nv);
            pe = e[cur]; cur = nx;
        }
        if (bad) __atomic_store_n(&g_bad, 1, __ATOMIC_RELAXED);
        band_ready(sl, q);
    }
    TT();
    if (t == 0) PM("p1");
    barrier();
    TT();
    if (t == 0) {
        if (__atomic_load_n(&g_bad, __ATOMIC_RELAXED)) exec_par(g_in, g_inlen, g_from_file);
        write_section(0, "the terrain\n", 0, 0, 0, 0);
        PM("wT");
    }
    for (long i = r0; i < r1; i++) indeg_row(D, i * M, M);
    g_nsrc[t] = count_sources(D, r0 * M, r1 * M);
#if PREFAULT
    {
        const uintptr_t lo = (uintptr_t)(A + r0 * M), hi = (uintptr_t)(A + r1 * M);
        for (uintptr_t a = (lo + 4095) & ~(uintptr_t)4095; a < hi; a += 4096) *(volatile uint32_t*)a = 0;
    }
#endif
    TT();
    barrier();
    TT();
    if (t == 0) PM("indeg");
    walk_share(t);
    TT();
    barrier();
    TT();
    if (t == 0) PM("walk");
    {
        char* q = sl.buf;
        for (long i = r0; i < r1; i++) q = fmt_dir_row<false>(q, D + i * M, M);
        band_ready(sl, q);
    }
    if (t == 0) {
        const size_t g1 = ghost_rows(0, "1 ", M), g5 = ghost_rows(1, "5 ", M);
        write_section(1, "the directions\n", g_gh[0], g1, g_gh[1], g5);
        PM("wD");
    }
    {
        spin_until_ge(&sl.written, 2);
        char* q = sl.buf;
        for (long i = r0; i < r1; i++) q = fmt_acc_row<false>(q, D + i * M, A + i * M, M);
        band_ready(sl, q);
    }
    TT();
    local_roots(t, r0 * M, r1 * M);
    TT();
    barrier();
    if (t == 0) {
        PM("fmtA+L1");
        const size_t g0 = ghost_rows(0, "0 ", M);
        write_section(2, "flow accumulation \n", g_gh[0], g0, g_gh[0], g0);
        PM("wA");
        resolve_exits();
        PM("L2");
    }
    TT();
    number_sinks(t, r0 * M, r1 * M);
    TT();
    barrier();
    TT();
    basin_min(r0 * M, r1 * M);
    TT();
    barrier();
    TT();
    count_firsts(t, r0 * M, r1 * M);
    TT();
    barrier();
    TT();
    assign_labels(t, r0 * M, r1 * M);
    TT();
    barrier();
    TT();
    if (t == 0) PM("lab");
    {
        spin_until_ge(&sl.written, 3);
        char* q = sl.buf;
        LabCache lc; lc.llab = 0; lc.llen = 0; memset(lc.lbuf, 0, sizeof lc.lbuf);
        for (long i = r0; i < r1; i++) q = fmt_ws_row_par(q, D, A, i * M, M, &lc);
        TT();
#if PROF
        memcpy(g_tt[t], tt, sizeof tt); g_ntt[t] = ntt;
#endif
        band_ready(sl, q);
    }
    if (t == 0) {
        const size_t gm = ghost_rows(0, "-1 ", M);
        write_section(3, "watersheds\n", g_gh[0], gm, g_gh[0], gm);
        PM("wW");
    }
}
static void* band_main(void* arg) { band_work((int)(intptr_t)arg); return 0; }

static char** g_argv;
static void exec_par(const char* data, size_t len, bool from_file) {
    char path[4096];
    const char* a0 = g_argv && g_argv[0] ? g_argv[0] : "";
    const char* sl = strrchr(a0, '/');
    size_t dl = sl ? (size_t)(sl - a0 + 1) : 0;
    if (dl + 8 >= sizeof path) dl = 0;
    if (dl) memcpy(path, a0, dl); else { memcpy(path, "./", 2); dl = 2; }
    memcpy(path + dl, "dtm_par", 8);
    if (access(path, X_OK) != 0) return;
    if (!from_file) {
        const int fd = (int)syscall(SYS_memfd_create, "dtm_in", 0);
        if (fd < 0) return;
        write_all(fd, data, len);
        if (lseek(fd, 0, SEEK_SET) != 0 || dup2(fd, 0) < 0) { close(fd); return; }
        close(fd);
    }
    static const char* const unset_vars[] = {"OMP_NUM_THREADS", "OMP_THREAD_LIMIT", "OMP_DYNAMIC", "OMP_PROC_BIND",
        "OMP_PLACES", "OMP_WAIT_POLICY", "GOMP_CPU_AFFINITY", "OMP_DISPLAY_ENV", "OMP_DISPLAY_AFFINITY",
        "OMP_AFFINITY_FORMAT", "GOMP_SPINCOUNT", "DTM_TMAX"};
    for (size_t k = 0; k < sizeof unset_vars / sizeof unset_vars[0]; k++) unsetenv(unset_vars[k]);
    execv(path, g_argv);
}

int main(int argc, char** argv) {
    (void)argc;
    g_argv = argv;
    PM("start");
    const char* buf = 0;
    size_t len = 0;
    bool from_file = false;
    {
        struct stat st;
        if (fstat(0, &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0) {
            const off_t cur = lseek(0, 0, SEEK_CUR);
            if (cur >= 0 && cur < st.st_size) {
                const size_t fs = (size_t)st.st_size;
                const size_t pg = 4096;
                const size_t rl = (fs + pg - 1) / pg * pg + pg;
                void* r = mmap(0, rl, PROT_READ, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
                if (r != MAP_FAILED) {
                    void* f = mmap(r, fs, PROT_READ, MAP_PRIVATE | MAP_FIXED | ((POPULATE && fs <= ((size_t)256 << 10)) ? MAP_POPULATE : 0), 0, 0);
                    if (f == r) { buf = (const char*)f + cur; len = fs - (size_t)cur; from_file = true; }
                    else munmap(r, rl);
                }
            }
        }
        if (!buf) {
            size_t cap = (size_t)1 << 16, nb = 0;
            char* o = (char*)malloc(cap + 1);
            if (!o) { perror("malloc"); exit(1); }
            for (;;) {
                if (nb == cap) { cap *= 2; o = (char*)realloc(o, cap + 1); if (!o) { perror("realloc"); exit(1); } }
                const ssize_t rr = read(0, o + nb, cap - nb);
                if (rr < 0) { if (errno == EINTR) continue; perror("read"); exit(1); }
                if (rr == 0) break;
                nb += (size_t)rr;
            }
            o[nb] = '\0';
            buf = o; len = nb;
        }
    }
    g_in = buf; g_inlen = len; g_from_file = from_file;
    PM("read");
    const char* p = buf;
    const char* const end = buf + len;
    long hv[5];
    for (int k = 0; k < 5; k++) {
        while (p < end && fio::is_ws((unsigned char)*p)) ++p;
        char* e; hv[k] = strtol(p, &e, 10); p = e;
    }
    const int n = (int)hv[0], m = (int)hv[1];
    float nv;
    while (p < end && fio::is_ws((unsigned char)*p)) ++p;
    p = fio::parse_float(p, &nv);
    long small_max = SMALL_MAX, cpt = CPT;
#if EXPER
    { const char* e = getenv("DTM_SMALL_MAX"); if (e && *e) small_max = atol(e); }
    { const char* e = getenv("DTM_CPT"); if (e && *e) cpt = atol(e); }
#endif
    const long V = (long)n * m;
    if (n < 1 || m < 2 || V > small_max) {
        exec_par(buf, len, from_file);
        if (n < 1 || m < 2) return 1;
    }
    const long M = m;
    long tl = (V + cpt - 1) / cpt;
    if (tl > TMAXP) tl = TMAXP;
    if (tl > n) tl = n;
    int T = tl < 1 ? 1 : (int)tl;
    if (T > 1) {
        cpu_set_t cs;
        if (sched_getaffinity(0, sizeof cs, &cs) == 0) {
            const int c = CPU_COUNT(&cs); if (T > c) T = c;
#if PIN
            const int me = sched_getcpu();
            int k = 0;
            for (int pass = 0; pass < 2 && k < T; pass++)
                for (int cpu = 0; cpu < CPU_SETSIZE && k < T; cpu++)
                    if (CPU_ISSET(cpu, &cs) && (pass == 0 ? cpu >= me : cpu < me)) g_cpu[k++] = cpu;
            if (k < T) T = k;
            cpu_set_t one; CPU_ZERO(&one); CPU_SET(g_cpu[0], &one);
            sched_setaffinity(0, sizeof one, &one);
#endif
        }
        else T = 1;
        if (T < 1) T = 1;
    }
    g_T = T;
    PM("hdr");

    const size_t dpad = (size_t)M + 64;
    const size_t dbytes = ((size_t)V + 2 * dpad + 4095) & ~(size_t)4095;
    const size_t abytes = ((size_t)V * 4 + 4095) & ~(size_t)4095;
    const size_t rbytes = T == 1 ? ((size_t)8 * ((size_t)M + 8) * 4 + 4095) & ~(size_t)4095 : 0;
    const size_t total = dbytes + abytes + rbytes;
    char* mem;
    if (HUGE && T > 1 && total >= (size_t)HUGE_MIN) {
        const size_t H = (size_t)2 << 20, tl2 = (total + H - 1) & ~(H - 1);
        char* r = (char*)mmap(0, tl2 + H, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
        if (r == MAP_FAILED) { perror("mmap"); exit(1); }
        mem = (char*)(((uintptr_t)r + H - 1) & ~(uintptr_t)(H - 1));
#ifdef MADV_HUGEPAGE
        madvise(mem, tl2, MADV_HUGEPAGE);
#endif
    } else {
        mem = (char*)mmap(0, total, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | ((POPULATE && T == 1) ? MAP_POPULATE : MAP_NORESERVE), -1, 0);
        if (mem == MAP_FAILED) { perror("mmap"); exit(1); }
#ifdef MADV_NOHUGEPAGE
        if (T > 1) madvise(mem, total, MADV_NOHUGEPAGE);
#endif
    }
    g.text = p; g.end = end; g.n = n; g.M = M; g.V = V; g.nv = nv;
    g.D = (uint8_t*)mem + dpad;
    g.A = (uint32_t*)(mem + dbytes);
    g.rows = (float*)(mem + dbytes + abytes);
    const long off[9] = {0, -M, -M + 1, 1, M + 1, M, M - 1, -1, -M - 1};
    memcpy(g.off, off, sizeof off);
    memset(g.D - dpad, (int)NOD, dpad);
    memset(g.D + V, (int)NOD, dpad);
    PM("alloc");
    if (T == 1) run_serial();
    else {
        const size_t rows_max = (size_t)((n + T - 1) / T) + 1, cells_max = rows_max * (size_t)M;
        const size_t H = (size_t)2 << 20;
        g_rowsz = ((size_t)8 * ((size_t)M + 8) * 4 + 63) & ~(size_t)63;
        g_exitsz = ((size_t)(2 * M + 16) * sizeof(long) + 63) & ~(size_t)63;
        g_fminsz = ((cells_max + 1) * 4 + 63) & ~(size_t)63;
        g_regsz = (g_rowsz + g_exitsz + g_fminsz + cells_max * 16 + rows_max + 4096 + H - 1) & ~(H - 1);
        char* rr = (char*)mmap(0, (size_t)T * g_regsz + H, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
        if (rr == MAP_FAILED) { perror("mmap"); exit(1); }
        g_reg = (char*)(((uintptr_t)rr + H - 1) & ~(uintptr_t)(H - 1));
#ifdef MADV_NOHUGEPAGE
        madvise(g_reg, (size_t)T * g_regsz, MADV_NOHUGEPAGE);
#endif
        g_cut[0] = p; g_cut[T] = end;
        for (int k = 1; k < T; k++) {
            const char* b = p + (end - p) * k / T;
            if (b < g_cut[k - 1]) b = g_cut[k - 1];
            while (b < end && (unsigned char)*b > ' ') ++b;
            g_cut[k] = b;
        }
        band_work(0);
    }
#if PROF
    fprintf(stderr, "SMALL n=%d m=%d T=%d", n, m, T);
    for (int k = 1; k < g_np; k++) fprintf(stderr, " %s=%.3f", g_pn[k], g_pt[k] - g_pt[k - 1]);
    fprintf(stderr, " total=%.3f", g_pt[g_np - 1] - g_pt[0]);
    if (T > 1) {
        double st = 0; for (int t = 1; t < T; t++) if (g_tt[t][0] - g_tt[0][0] > st) st = g_tt[t][0] - g_tt[0][0];
        fprintf(stderr, " laststart=%.3f", st);
        for (int k = 1; k < g_ntt[0]; k++) {
            double mx = 0, sm = 0;
            for (int t = 0; t < T; t++) { const double d = g_tt[t][k] - g_tt[t][k - 1]; sm += d; if (d > mx) mx = d; }
            fprintf(stderr, " s%d=%.3f/%.3f", k, mx, sm / T);
        }
    }
    fprintf(stderr, "\n");
#endif
    return 0;
}
