#include <stdio.h>
#include <stdlib.h>
int pulse_cpu_main(int N, int T);
int main(void)
{
    int N, T;
    const char* nt = getenv("PULSE_NT");
    if (nt) {
        if (sscanf(nt, "%d %d", &N, &T) != 2)
            return EXIT_FAILURE;
    } else if (scanf("%d %d", &N, &T) != 2)
        return EXIT_FAILURE;
    return pulse_cpu_main(N, T);
}
