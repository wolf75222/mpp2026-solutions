#include <cuda_runtime.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <vector>
#include <algorithm>
#include <thread>
#include <omp.h>

#define BORDER 6
#define NOISE_AMP 1.0f
#define PRINT_MIN 0.0005
#define PRINT_MAX 500

static int g_N = 0, g_T = 0;
static volatile int g_printed = 0;
extern "C" int pulse_cpu_main(int N, int T);
[[noreturn]] static void gpu_fallback(const char* why)
{
    if (getenv("PULSE_TIME"))
        fprintf(stderr, "GPU path unavailable (%s): CPU path\n", why);
    if (g_printed)
        _exit(EXIT_FAILURE);
    char nt[64];
    snprintf(nt, sizeof nt, "%d %d", g_N, g_T);
    setenv("PULSE_NT", nt, 1);
    setenv("PULSE_PATH", "cpu", 1);
    unsetenv("OMP_NUM_THREADS");
    unsetenv("OMP_THREAD_LIMIT");
    unsetenv("OMP_DYNAMIC");
    setenv("OMP_PLACES", "cores", 1);
    setenv("OMP_PROC_BIND", "close", 1);
    setenv("OMP_WAIT_POLICY", "active", 1);
    fflush(stdout);
    char* const av[] = {(char*)"pulse", NULL};
    execv("/proc/self/exe", av);
    const int r = pulse_cpu_main(g_N, g_T);
    fflush(stdout);
    _exit(r);
}
#define CK(x)                                                                         \
    do {                                                                              \
        cudaError_t e_ = (x);                                                         \
        if (e_ != cudaSuccess)                                                        \
            gpu_fallback(cudaGetErrorString(e_));                                     \
    } while (0)
#define CKH(x)                                                                        \
    do {                                                                              \
        cudaError_t e_ = (x);                                                         \
        if (e_ != cudaSuccess) {                                                      \
            helper_err = cudaGetErrorString(e_);                                      \
            return;                                                                   \
        }                                                                             \
    } while (0)

typedef struct {
    float W[7];
    float e[7];
    float k, g, r;
} stGS;

static void init_constants(stGS* c, float dx, float dt, float vp)
{
    int a;
    float fat = ((dt * dt) / (dx * dx));

    c->W[0] = (float)(-5369.0 / 1800.0);
    c->W[1] = (float)(12.0 / 7.0);
    c->W[2] = (float)(-15.0 / 56.0);
    c->W[3] = (float)(10.0 / 189.0);
    c->W[4] = (float)(-1.0 / 112.0);
    c->W[5] = (float)(2.0 / 1925.0);
    c->W[6] = (float)(-1.0 / 16632.0);

    c->r = fat * vp * vp;
    c->k = 0.5f * c->r;
    c->g = 1.0f / (1.0f - 3.0f * c->k * c->W[0]);
    c->e[0] = 0.0f;
    for (a = 1; a <= 6; a++)
        c->e[a] = c->g * c->k * c->W[a];
}

static float pulse(float tau, float peak)
{
    float a = 3.14159265f * peak * tau;
    float a2 = a * a;
    return (1.0f - 2.0f * a2) * expf(-a2);
}

static long pad_stride(long n)
{
    long s = (n + 15) & ~15L;
    if (((s >> 4) & 1) == 0)
        s += 16;
    return s;
}

#define FA(a, b) __fadd_rn((a), (b))
#define FS(a, b) __fsub_rn((a), (b))
#define FM(a, b) __fmul_rn((a), (b))

#define MAXDEP 16
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 900 && !defined(A100LIKE)
#define MINB16 2
#define MINB8 3
#elif defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 800
#define MINB16 1
#define MINB8 2
#else
#define MINB16 1
#define MINB8 1
#endif
#ifndef PDEPTH
#if defined(__CUDA_ARCH__) && __CUDA_ARCH__ >= 900 && !defined(A100LIKE)
#define PDEPTH 2
#else
#define PDEPTH 3
#endif
#endif
#ifdef PROF
#define PMODE p.mode
#else
#define PMODE 0
#endif
#define MAXT 161
#define SRCI 34
#define SRCJ 42
#define SRCK 50

__constant__ float c_sv[MAXT];

struct KP {
    float* U0;
    float* U1;
    int* flags;
    int* counter;
    const int2* task;
    const int* deps;
    const int* gorder;
    int N, M, PD, PJ, slabI, sD;
    int TPS, nsteps, C;
    int mode;
    unsigned long long* prof;
    float W0, W1, W2, W3, W4, W5, W6;
    float e1, e2, e3, e4, e5, e6;
    float k, g;
};

__device__ __forceinline__ int ld_flag(const int* p)
{
    int v;
    asm volatile("ld.relaxed.gpu.global.s32 %0, [%1];" : "=r"(v) : "l"(p) : "memory");
    return v;
}
__device__ __forceinline__ void st_flag_release(int* p, int v)
{
    asm volatile("st.release.gpu.global.s32 [%0], %1;" ::"l"(p), "r"(v) : "memory");
}
__device__ __forceinline__ void fence_acq_rel_gpu() { asm volatile("fence.acq_rel.gpu;" ::: "memory"); }

static __device__ __forceinline__ float noise_dev(long long p)
{
    unsigned h = (unsigned)p * 2654435761u;
    h ^= h >> 16;
    h *= 0x85ebca6bu;
    h ^= h >> 13;
    h *= 0xc2b2ae35u;
    h ^= h >> 16;
    return FM(FS(FM(FM(__uint2float_rn(h >> 8), (1.0f / 16777216.0f)), 2.0f), 1.0f), NOISE_AMP);
}

__global__ void init_noise_k(float* U0, float* U1, int N, int sI, int sD)
{
    const int j = blockIdx.x * blockDim.x + threadIdx.x + BORDER;
    const int d = blockIdx.y;
    const int i = blockIdx.z + BORDER;
    const int k = d - j;
    if (j < N - BORDER && k >= BORDER && k < N - BORDER) {
        long long p = ((long long)k * N + j) * N + i;
        float v = noise_dev(p);
        size_t idx = (size_t)i * sI + (size_t)d * sD + j;
        U0[idx] = v;
        U1[idx] = v;
    }
}

__global__ void plane_sums_k(const float* __restrict__ R, double* ps, int N, int sI, int sD)
{
    const int wib = threadIdx.x >> 5, l = threadIdx.x & 31;
    const int kz = blockIdx.x * 8 + wib;
    if (kz >= N)
        return;
    const int NN = N * N, nch = (NN + 127) / 128;
    auto addr = [&](int pos) -> size_t {
        const int jy = pos / N, ix = pos - jy * N;
        return (size_t)(jy + kz) * sD + (size_t)ix * sI + jy;
    };
    float a[4], b[4];
#pragma unroll
    for (int m = 0; m < 4; m++) {
        const int pos = m * 32 + l;
        a[m] = pos < NN ? __ldg(R + addr(pos)) : 0.0f;
    }
    double plane = 0.0;
    for (int c = 0; c < nch; c++) {
#pragma unroll
        for (int m = 0; m < 4; m++) {
            const int pos = (c + 1) * 128 + m * 32 + l;
            b[m] = pos < NN ? __ldg(R + addr(pos)) : 0.0f;
        }
        const int n = min(128, NN - c * 128);
#pragma unroll
        for (int m = 0; m < 4; m++)
#pragma unroll
            for (int k = 0; k < 32; k++) {
                const float v = __shfl_sync(0xffffffffu, a[m], k);
                if (m * 32 + k < n)
                    plane += (double)v;
            }
#pragma unroll
        for (int m = 0; m < 4; m++)
            a[m] = b[m];
    }
    if (l == 0)
        ps[kz] = plane;
}

template <int W>
struct Geo {
    static constexpr int NT = W * 32;
    static constexpr int QW = 44, QRING = 16, QD = W + 12;
    static constexpr int XW = 40, XRING = 8, XD = W + 6;
    static constexpr int NQI = QD * 11;
    static constexpr int NXA = 6 * 10 + (W - 1);
    static constexpr int NXB = W - 1;
    static constexpr int NITEM = NQI + NXA + NXB;
    static constexpr int NI = (NITEM + NT - 1) / NT;
    static constexpr size_t SMEM = (size_t)(QD * QRING * QW + XD * XRING * XW) * sizeof(float);
};

struct Item {
    int type;
    int off;
    int lo;
    unsigned span;
    int soff, sc;
};

template <int W>
__global__ void __launch_bounds__(W * 32, (W == 16 ? MINB16 : MINB8)) sweep_k(const KP p)
{
    typedef Geo<W> G;
    extern __shared__ float4 sm4[];
    float* Qs = (float*)sm4;
    float* Xs = Qs + G::QD * G::QRING * G::QW;
    __shared__ int s_task;

    const int tid = threadIdx.x, w = tid >> 5, l = tid & 31;
    const int M = p.M, sD = p.sD, sI = p.slabI;
    const int total = p.TPS * p.nsteps;
    const int S = M + W - 1;
    const int Cm = p.C - 1;
    const int BIG = 1 << 30;
    const int qr = w + 6, xr = w + 6, jj = l + 6;
#ifdef PROF
    unsigned long long pw = 0, pt0 = clock64(), ntask = 0;
#endif

    for (;;) {
        if (tid == 0)
            s_task = atomicAdd(p.counter, 1);
        __syncthreads();
        const int q0 = s_task;
        if (q0 >= total)
            break;
        const int q = p.gorder[q0];
        const int t = q / p.TPS + 1;
        const int pi = q - (t - 1) * p.TPS;
        const int2 tk = p.task[pi];
        const int Jg = tk.x;
        const int d0 = 32 * Jg + W * tk.y;
        const float* Q = ((t - 1) & 1) ? p.U1 : p.U0;
        float* X = (t & 1) ? p.U1 : p.U0;
        int* myflag = p.flags + (size_t)(t - 1) * p.TPS + pi;
        const int mydep = (w == 0 && l < MAXDEP) ? p.deps[pi * MAXDEP + l] : -1;
        int seen = -(1 << 30);

        auto wait_deps = [&](int tgt) {
            if (w == 0 && !(PMODE & 1)) {
#ifdef PROF
                unsigned long long c0 = clock64();
#endif
                bool obs = false;
                if (mydep >= 0 && !(PMODE & 32)) {
                    const int prev = mydep >> 20, dpi = mydep & 0xFFFFF;
                    const int need = tgt + d0 + (prev ? 7 : 0);
                    if (!(prev && t == 1) && seen < need) {
                        const int* f = p.flags + (size_t)(t - 1 - prev) * p.TPS + dpi;
                        int v;
                        while ((v = ld_flag(f)) < need)
                            __nanosleep(64);
                        seen = v;
                        obs = true;
                    }
                }
                if (__any_sync(0xffffffffu, obs) && !(PMODE & 16))
                    fence_acq_rel_gpu();
                __syncwarp();
#ifdef PROF
                if (l == 0)
                    pw += clock64() - c0;
#endif
            }
        };

        Item it[G::NI];
#pragma unroll
        for (int n = 0; n < G::NI; n++) {
            const int e = tid + n * G::NT;
            Item& I = it[n];
            I.type = 0;
            I.off = 0;
            I.lo = 0;
            I.span = 0;
            I.soff = 0;
            I.sc = 0;
            if (e < G::NQI) {
                const int r = e / 11, c4 = e - r * 11;
                I.type = 1;
                I.off = (18 - r) * sI + (d0 + r + 6) * sD + 32 * Jg + 4 * c4;
                I.lo = r - 18;
                I.span = M + 12;
                I.soff = r * G::QRING * G::QW + 4 * c4;
                I.sc = 12 - r;
            } else if (e < G::NQI + G::NXA + G::NXB) {
                int r, c4;
                if (e < G::NQI + G::NXA) {
                    const int j = e - G::NQI;
                    if (j < 60) {
                        r = j / 10;
                        c4 = j - r * 10;
                    } else {
                        r = 6 + (j - 60);
                        c4 = 0;
                    }
                    I.type = 2;
                } else {
                    r = 6 + (e - G::NQI - G::NXA);
                    c4 = 1;
                    I.type = 3;
                }
                I.off = (11 - r) * sI + (d0 + r + 6) * sD + 32 * Jg + 4 * c4;
                I.lo = r - 5;
                I.span = M;
                I.soff = r * G::XRING * G::XW + 4 * c4;
                I.sc = 5 - r;
            }
        }
        auto ld_item = [&](const Item& I, int T) -> float4 {
            float4 r = make_float4(0.0f, 0.0f, 0.0f, 0.0f);
            if (I.type && (unsigned)(T - I.lo) < I.span && !(PMODE & 4)) {
                const float* g = (I.type == 1 ? Q : (const float*)X) + (I.off + T * sI);
                if (I.type == 3) {
                    const float2 v2 = __ldcg((const float2*)g);
                    r.x = v2.x;
                    r.y = v2.y;
                } else
                    r = __ldcg((const float4*)g);
            }
            return r;
        };
        auto st_item = [&](const Item& I, int T, const float4& r) {
            if (I.type && (unsigned)(T - I.lo) < I.span) {
                if (I.type == 1)
                    *(float4*)(Qs + I.soff + ((T + I.sc) & (G::QRING - 1)) * G::QW) = r;
                else if (I.type == 2)
                    *(float4*)(Xs + I.soff + ((T + I.sc) & (G::XRING - 1)) * G::XW) = r;
                else
                    *(float2*)(Xs + I.soff + ((T + I.sc) & (G::XRING - 1)) * G::XW) = make_float2(r.x, r.y);
            }
        };

        const int jp = 32 * Jg + l, dp = d0 + w, kp = dp - jp;
        const bool lane_ok = (jp < M) && (kp >= 0) && (kp < M);
        const bool src_line = lane_ok && jp == SRCJ && kp == SRCK;
        const float sv = c_sv[t];
        const int xown = 6 * sI + (dp + 12) * sD + jp + 6;
        auto ld_xold = [&](int s2) -> float {
            const int ip2 = s2 - w;
            return (lane_ok && (unsigned)ip2 < (unsigned)M && !(PMODE & 8)) ? __ldcg(X + (xown + ip2 * sI)) : 0.0f;
        };

        wait_deps(PDEPTH - 1);
        __syncthreads();
        for (int T = -12; T <= 0; T += 4) {
            float4 r[4][G::NI];
#pragma unroll
            for (int k = 0; k < 4; k++)
#pragma unroll
                for (int n = 0; n < G::NI; n++)
                    r[k][n] = (T + k <= 0) ? ld_item(it[n], T + k) : make_float4(0.0f, 0.0f, 0.0f, 0.0f);
#pragma unroll
            for (int k = 0; k < 4; k++)
#pragma unroll
                for (int n = 0; n < G::NI; n++)
                    if (T + k <= 0)
                        st_item(it[n], T + k, r[k][n]);
        }
        float4 RS_[PDEPTH][G::NI];
        float XR_[PDEPTH];
#pragma unroll
        for (int u = 0; u < PDEPTH; u++) {
#pragma unroll
            for (int n = 0; n < G::NI; n++)
                RS_[u][n] = u ? ld_item(it[n], u) : make_float4(0.0f, 0.0f, 0.0f, 0.0f);
            XR_[u] = ld_xold(u);
        }
        float u1 = 0.0f, u2 = 0.0f, u3 = 0.0f, u4 = 0.0f, u5 = 0.0f, u6 = 0.0f;
        float qw[13];
#pragma unroll
        for (int k = 0; k < 13; k++)
            qw[k] = 0.0f;
        __syncthreads();

        auto body = [&](const int s, float4(&RL)[G::NI], const float4(&RS)[G::NI], float& XR) {
            if ((s & Cm) == 0) {
                if (tid == 0 && s > 0)
                    st_flag_release(myflag, s + d0);
                wait_deps(s + p.C + PDEPTH - 1);
                __syncthreads();
            }
#pragma unroll
            for (int n = 0; n < G::NI; n++)
                RL[n] = ld_item(it[n], s + PDEPTH);
            const float xold = XR;
            XR = ld_xold(s + PDEPTH);
            const int ip = s - w;
            if ((unsigned)ip < (unsigned)M && !(PMODE & 2)) {
                const float* qb = Qs + (qr * G::QRING + (ip & (G::QRING - 1))) * G::QW + jj;
                float* xb = Xs + (xr * G::XRING + (ip & (G::XRING - 1))) * G::XW + jj;
                if (ip == 0) {
#pragma unroll
                    for (int k = 0; k < 12; k++)
                        qw[k] = Qs[(qr * G::QRING + ((k - 6) & (G::QRING - 1))) * G::QW + jj];
                }
                qw[12] = Qs[(qr * G::QRING + ((ip + 6) & (G::QRING - 1))) * G::QW + jj];
#define QI(a) qw[6 + (a)]
#define QJ(a) qb[(a) * (G::QRING * G::QW) + (a)]
#define QK(a) qb[(a) * (G::QRING * G::QW)]
#define XJ(a) xb[-(a) * (G::XRING * G::XW) - (a)]
#define XK(a) xb[-(a) * (G::XRING * G::XW)]
#define LAP(Q_)                                                                                                    \
    FA(FA(FA(FA(FA(FA(FM(p.W6, FA(Q_(-6), Q_(6))), FM(p.W5, FA(Q_(-5), Q_(5)))), FM(p.W4, FA(Q_(-4), Q_(4)))),    \
                 FM(p.W3, FA(Q_(-3), Q_(3)))),                                                                     \
              FM(p.W2, FA(Q_(-2), Q_(2)))),                                                                        \
           FM(p.W1, FA(Q_(-1), Q_(1)))),                                                                           \
        FM(p.W0, q0))
#define OT(a, ea) FM(ea, FA(FA(FA(QI(a), XJ(a)), QJ(a)), FA(XK(a), QK(a))))
                const float q0 = qw[6];
                const float lx = LAP(QI);
                const float ly = LAP(QJ);
                const float lz = LAP(QK);
                const float R = FM(p.g, FA(FS(FM(2.0f, q0), xold), FM(p.k, FA(FA(lx, ly), lz))));
                const float o = FA(FA(FA(FA(FA(OT(6, p.e6), OT(5, p.e5)), OT(4, p.e4)), OT(3, p.e3)), OT(2, p.e2)), OT(1, p.e1));
                const float Sv = FA(R, o);
                float v = FA(FA(Sv, FA(FA(FA(FA(FM(p.e6, u6), FM(p.e5, u5)), FM(p.e4, u4)), FM(p.e3, u3)), FM(p.e2, u2))), FM(p.e1, u1));
                if (src_line && ip == SRCI)
                    v = FA(v, sv);
#undef QI
#undef QJ
#undef QK
#undef XJ
#undef XK
#undef LAP
#undef OT
                u6 = u5;
                u5 = u4;
                u4 = u3;
                u3 = u2;
                u2 = u1;
                u1 = v;
#pragma unroll
                for (int k = 0; k < 12; k++)
                    qw[k] = qw[k + 1];
                xb[0] = lane_ok ? v : 0.0f;
                if (lane_ok)
                    __stcg(X + (xown + ip * sI), v);
            }
#pragma unroll
            for (int n = 0; n < G::NI; n++)
                st_item(it[n], s + 1, RS[n]);
            __syncthreads();
        };

        for (int s0 = 0; s0 < S; s0 += PDEPTH) {
#pragma unroll
            for (int u = 0; u < PDEPTH; u++)
                if (s0 + u < S)
                    body(s0 + u, RS_[u], RS_[(u + 1) % PDEPTH], XR_[u]);
        }
        if (tid == 0)
            st_flag_release(myflag, BIG);
#ifdef PROF
        ntask++;
#endif
    }
#ifdef PROF
    if (tid == 0 && p.prof) {
        p.prof[3 * blockIdx.x] = pw;
        p.prof[3 * blockIdx.x + 1] = clock64() - pt0;
        p.prof[3 * blockIdx.x + 2] = ntask;
    }
#endif
}

static double now(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + 1e-6 * tv.tv_usec;
}

static int floordiv(int a, int b) { return (a >= 0) ? a / b : -((-a + b - 1) / b); }

struct Tiling {
    int W, nJg, TPS;
    std::vector<int> nKb, base;
    std::vector<int2> task;
    std::vector<int> order;
    std::vector<int> deps;
    int maxd0;
};

static void build_tiling(Tiling& tl, int M, int W)
{
    tl.W = W;
    tl.nJg = (M + 31) / 32;
    tl.nKb.resize(tl.nJg);
    tl.base.resize(tl.nJg);
    int tot = 0;
    for (int c = 0; c < tl.nJg; c++) {
        int nv = std::min(32, M - 32 * c);
        tl.nKb[c] = (nv + M - 1 + W - 1) / W;
        tl.base[c] = tot;
        tot += tl.nKb[c];
    }
    tl.TPS = tot;
    std::vector<int2> all;
    tl.maxd0 = 0;
    for (int c = 0; c < tl.nJg; c++)
        for (int b = 0; b < tl.nKb[c]; b++) {
            all.push_back(make_int2(c, b));
            tl.maxd0 = std::max(tl.maxd0, 32 * c + W * b);
        }
    std::sort(all.begin(), all.end(), [W](const int2& x, const int2& y) {
        int dx = 32 * x.x + W * x.y, dy = 32 * y.x + W * y.y;
        if (dx != dy)
            return dx < dy;
        return x.x < y.x;
    });
    tl.task = all;
    tl.order.assign(tot, -1);
    for (int i = 0; i < tot; i++)
        tl.order[tl.base[all[i].x] + all[i].y] = i;
    tl.deps.assign((size_t)tot * MAXDEP, -1);
    for (int i = 0; i < tot; i++) {
        int c0 = all[i].x, d0 = 32 * c0 + W * all[i].y;
        std::vector<int> dl;
        auto add = [&](int c, int lo, int hi, int prev) {
            if (c < 0 || c >= tl.nJg)
                return;
            int b0 = std::max(0, floordiv(lo - 32 * c, W)), b1 = std::min(tl.nKb[c] - 1, floordiv(hi - 32 * c, W));
            for (int b = b0; b <= b1; b++) {
                int o = tl.order[tl.base[c] + b];
                if (!prev && o == i)
                    continue;
                if (!prev && o > i)
                    gpu_fallback("tiling order");
                int ent = o | (prev << 20);
                if (std::find(dl.begin(), dl.end(), ent) == dl.end())
                    dl.push_back(ent);
            }
        };
        add(c0, d0 - 6, d0 - 1, 0);
        add(c0 - 1, d0 - 6, d0 + W - 2, 0);
        for (int dc = -1; dc <= 1; dc++)
            add(c0 + dc, d0 - 6, d0 + W + 5, 1);
        if ((int)dl.size() > MAXDEP)
            gpu_fallback("too many deps");
        for (size_t k = 0; k < dl.size(); k++)
            tl.deps[(size_t)i * MAXDEP + k] = dl[k];
    }
}

template <int W>
static void launch_sweep(const KP& kp, int nsm, int verbose)
{
    const size_t smem = Geo<W>::SMEM;
    CK(cudaFuncSetAttribute(sweep_k<W>, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)smem));
    int bps = 0;
    CK(cudaOccupancyMaxActiveBlocksPerMultiprocessor(&bps, sweep_k<W>, W * 32, smem));
    if (bps < 1)
        bps = 1;
    const char* g = getenv("PULSE_BPS");
    if (g && atoi(g) > 0 && atoi(g) < bps)
        bps = atoi(g);
    const char* ns = getenv("PULSE_NSM");
    if (ns && atoi(ns) > 0 && atoi(ns) < nsm)
        nsm = atoi(ns);
    if (verbose) {
        cudaFuncAttributes fa;
        CK(cudaFuncGetAttributes(&fa, sweep_k<W>));
        fprintf(stderr, "sweep W=%d C=%d smem=%zu regs=%d local=%zu blocks/SM=%d grid=%d TPS=%d\n", W, kp.C, smem,
            fa.numRegs, (size_t)fa.localSizeBytes, bps, nsm * bps, kp.TPS);
    }
    sweep_k<W><<<nsm * bps, W * 32, smem>>>(kp);
    CK(cudaGetLastError());
}

static bool build_order(const Tiling& tl, int W, int nsteps, int lam, int mu, std::vector<int>& gorder)
{
    const int TPS = tl.TPS;
    std::vector<int> bk(TPS);
    int maxb = 0;
    for (int p = 0; p < TPS; p++) {
        bk[p] = 32 * tl.task[p].x + W * tl.task[p].y + (lam > 0 ? mu * tl.task[p].x : 0);
        maxb = std::max(maxb, bk[p]);
    }
    for (int p = 0; p < TPS; p++)
        for (int k = 0; k < MAXDEP; k++) {
            const int e = tl.deps[(size_t)p * MAXDEP + k];
            if (e < 0)
                continue;
            const int prev = e >> 20, dp = e & 0xFFFFF;
            bool ok;
            if (lam <= 0)
                ok = prev || dp < p;
            else if (prev)
                ok = bk[dp] - lam <= bk[p];
            else
                ok = bk[dp] < bk[p] || (bk[dp] == bk[p] && tl.task[dp].x < tl.task[p].x);
            if (!ok)
                return false;
        }
    gorder.clear();
    gorder.reserve((size_t)(nsteps > 0 ? nsteps : 0) * TPS);
    if (lam <= 0) {
        for (int t = 0; t < nsteps; t++)
            for (int p = 0; p < TPS; p++)
                gorder.push_back(t * TPS + p);
        return true;
    }
    std::vector<std::vector<int>> buck(maxb + 1);
    for (int p = 0; p < TPS; p++)
        buck[bk[p]].push_back(p);
    for (auto& b : buck)
        std::sort(b.begin(), b.end(), [&](int a, int c) { return tl.task[a].x < tl.task[c].x; });
    const long long kmax = (long long)maxb + (long long)lam * (nsteps - 1);
    for (long long K = 0; K <= kmax; K++) {
        const int t0 = K > maxb ? (int)((K - maxb + lam - 1) / lam) : 0;
        const int t1 = (int)std::min<long long>(nsteps - 1, K / lam);
        for (int t = t0; t <= t1; t++)
            for (int p : buck[K - (long long)lam * t])
                gorder.push_back(t * TPS + p);
    }
    return true;
}

static void geometry(int N, int W, int& PJ, int& PD)
{
    const int M = N - 2 * BORDER, nJg = (M + 31) / 32;
    int maxd0 = 0;
    for (int c = 0; c < nJg; c++) {
        const int nv = std::min(32, M - 32 * c), nkb = (nv + M - 1 + W - 1) / W;
        maxd0 = std::max(maxd0, 32 * c + W * (nkb - 1));
    }
    PJ = 32 * nJg + 32;
    PD = maxd0 + W + 18 + 12 + 1;
}

int main(void)
{
    int N, T, t;
    const float dx = 12.5f, dt = 0.001f, vp = 2500.0f, peak = 25.0f;
    stGS c;
    const int verbose = getenv("PULSE_TIME") != NULL;
    double t0 = now();

    const char* ntenv = getenv("PULSE_NT");
    if (ntenv) {
        if (sscanf(ntenv, "%d %d", &N, &T) != 2)
            return EXIT_FAILURE;
    } else if (scanf("%d %d", &N, &T) != 2)
        return EXIT_FAILURE;
    g_N = N;
    g_T = T;
    const int M = N - 2 * BORDER;
    const int nsteps = T - 1;

    {
        const double work = (double)(nsteps > 0 ? nsteps : 0) * M * M * M;
        double wmin = 1.0e10;
        if (getenv("PULSE_GPU_MIN_WORK"))
            wmin = atof(getenv("PULSE_GPU_MIN_WORK"));
        const char* pp = getenv("PULSE_PATH");
        bool cpu = work < wmin || T > MAXT || N < 2 * BORDER + 1;
        if (pp && !strcmp(pp, "cpu"))
            cpu = true;
        if (pp && !strcmp(pp, "gpu") && T <= MAXT && N >= 2 * BORDER + 1)
            cpu = false;
        if (cpu) {
            if (verbose)
                fprintf(stderr, "path=cpu work=%.3g\n", work);
            const int r = pulse_cpu_main(N, T);
            fflush(stdout);
            return r;
        }
    }

    int W = 16, PJ = 0, PD = 0, sI = 0, sD = 0, nsm = 0;
    size_t cells = 0;
    float* Ubuf = NULL;
    double tctx = 0, tmal = 0;
    const int layout = getenv("PULSE_LAYOUT") ? atoi(getenv("PULSE_LAYOUT")) : 1;
    const char* helper_err = NULL;
    std::thread helper([&] {
        int ndev = 0;
        CKH(cudaGetDeviceCount(&ndev));
        if (ndev < 1) {
            helper_err = "no CUDA device";
            return;
        }
        CKH(cudaFree(0));
        cudaDeviceProp prop;
        CKH(cudaGetDeviceProperties(&prop, 0));
        if (prop.major < 7) {
            helper_err = "compute capability < 7.0";
            return;
        }
        tctx = now();
        nsm = prop.multiProcessorCount;
        if (prop.sharedMemPerMultiprocessor < 2 * Geo<16>::SMEM + 2048 || prop.sharedMemPerBlockOptin < Geo<16>::SMEM)
            W = 8;
        if (getenv("PULSE_W"))
            W = atoi(getenv("PULSE_W")) == 8 ? 8 : 16;
        geometry(N, W, PJ, PD);
        cells = (size_t)N * PD * PJ;
        if (cells >= (1ull << 31)) {
            helper_err = "grid too large for 32-bit offsets";
            return;
        }
        sI = layout == 0 ? PD * PJ : PJ;
        sD = layout == 0 ? PJ : N * PJ;
        CKH(cudaMalloc(&Ubuf, 2 * cells * sizeof(float)));
        CKH(cudaMemsetAsync(Ubuf, 0, 2 * cells * sizeof(float)));
        tmal = now();
    });

    init_constants(&c, dx, dt, vp);
    std::vector<float> wavelet(T > 0 ? T : 1, 0.0f), svh(MAXT, 0.0f);
    float delay = 1.2f / peak;
    for (t = 0; t < T; t++)
        wavelet[t] = 400.0f * pulse(t * dt - delay, peak);
    for (t = 1; t < T; t++)
        svh[t] = c.r * wavelet[t];

    int C = 8;
    if (getenv("PULSE_C"))
        C = atoi(getenv("PULSE_C"));
    if (C < 2 || (C & (C - 1)))
        C = 8;
    Tiling tls[2];
    std::vector<int> gos[2];
    int lams[2];
    bool order_ok[2];
    for (int wi = 0; wi < 2; wi++) {
        const int Wc = wi ? 8 : 16;
        build_tiling(tls[wi], M, Wc);
        int lam = 2 * Wc + 8, mu = 8;
        if (getenv("PULSE_LAM"))
            lam = atoi(getenv("PULSE_LAM"));
        if (getenv("PULSE_MU"))
            mu = atoi(getenv("PULSE_MU"));
        lams[wi] = lam;
        order_ok[wi] = build_order(tls[wi], Wc, nsteps, lam, mu, gos[wi]);
    }
    double t1 = now();
    helper.join();
    if (helper_err)
        gpu_fallback(helper_err);
    double tj = now();
    const int wi = W == 16 ? 0 : 1;
    if (!order_ok[wi]) {
        fprintf(stderr, "grab order not topological (W=%d lam=%d)\n", W, lams[wi]);
        return EXIT_FAILURE;
    }
    const Tiling& tl = tls[wi];
    const std::vector<int>& gorder = gos[wi];
    const int lam = lams[wi];
    float* U0 = Ubuf;
    float* U1 = Ubuf + cells;

    int *flags, *counter, *deps, *gord;
    int2* task;
    double* ps;
    const size_t nflag = (size_t)(nsteps > 0 ? nsteps : 1) * tl.TPS;
    auto al = [](size_t b) { return (b + 255) & ~(size_t)255; };
    const size_t o_flags = 0, o_cnt = o_flags + al(nflag * 4), o_gord = o_cnt + 256, o_deps = o_gord + al((gorder.size() + 1) * 4),
                 o_task = o_deps + al(tl.deps.size() * 4), o_ps = o_task + al(tl.TPS * sizeof(int2)), o_end = o_ps + al(N * 8);
    char* small;
    CK(cudaMalloc(&small, o_end));
    flags = (int*)(small + o_flags);
    counter = (int*)(small + o_cnt);
    gord = (int*)(small + o_gord);
    deps = (int*)(small + o_deps);
    task = (int2*)(small + o_task);
    ps = (double*)(small + o_ps);
    CK(cudaMemsetAsync(small, 0, o_gord));
    if (gorder.size())
        CK(cudaMemcpy(gord, gorder.data(), gorder.size() * sizeof(int), cudaMemcpyHostToDevice));
    CK(cudaMemcpy(deps, tl.deps.data(), tl.deps.size() * sizeof(int), cudaMemcpyHostToDevice));
    CK(cudaMemcpy(task, tl.task.data(), tl.TPS * sizeof(int2), cudaMemcpyHostToDevice));
    CK(cudaMemcpyToSymbol(c_sv, svh.data(), MAXT * sizeof(float)));
    {
        dim3 b(128), g((M + 127) / 128, 2 * N, M);
        init_noise_k<<<g, b>>>(U0, U1, N, sI, sD);
        CK(cudaGetLastError());
    }
    CK(cudaDeviceSynchronize());
    double t2 = now();
    if (verbose)
        fprintf(stderr, "setup: ctx+props=%.4f malloc+memset=%.4f host_setup=%.4f join_wait=%.4f copies+init=%.4f (MB per array=%.0f)\n",
            tctx - t0, tmal - tctx, t1 - t0, tj - t1, t2 - tj, cells * 4.0 / 1e6);

    if (nsteps > 0) {
        KP kp;
        kp.U0 = U0;
        kp.U1 = U1;
        kp.flags = flags;
        kp.counter = counter;
        kp.task = task;
        kp.deps = deps;
        kp.gorder = gord;
        kp.N = N;
        kp.M = M;
        kp.PD = PD;
        kp.PJ = PJ;
        kp.slabI = sI;
        kp.sD = sD;
        kp.TPS = tl.TPS;
        kp.nsteps = nsteps;
        kp.C = C;
        kp.mode = getenv("PULSE_MODE") ? atoi(getenv("PULSE_MODE")) : 0;
        kp.prof = NULL;
#ifdef PROF
        CK(cudaMalloc(&kp.prof, 3 * 4096 * sizeof(unsigned long long)));
        CK(cudaMemset(kp.prof, 0, 3 * 4096 * sizeof(unsigned long long)));
#endif
        kp.W0 = c.W[0];
        kp.W1 = c.W[1];
        kp.W2 = c.W[2];
        kp.W3 = c.W[3];
        kp.W4 = c.W[4];
        kp.W5 = c.W[5];
        kp.W6 = c.W[6];
        kp.e1 = c.e[1];
        kp.e2 = c.e[2];
        kp.e3 = c.e[3];
        kp.e4 = c.e[4];
        kp.e5 = c.e[5];
        kp.e6 = c.e[6];
        kp.k = c.k;
        kp.g = c.g;
        if (W == 16)
            launch_sweep<16>(kp, nsm, verbose);
        else
            launch_sweep<8>(kp, nsm, verbose);
        CK(cudaDeviceSynchronize());
#ifdef PROF
        {
            std::vector<unsigned long long> h(3 * 4096);
            CK(cudaMemcpy(h.data(), kp.prof, h.size() * sizeof(unsigned long long), cudaMemcpyDeviceToHost));
            double sw = 0, st = 0, sn = 0, mx = 0;
            int nb = 0;
            for (int b = 0; b < 4096; b++)
                if (h[3 * b + 1]) {
                    sw += h[3 * b];
                    st += h[3 * b + 1];
                    sn += h[3 * b + 2];
                    mx = std::max(mx, (double)h[3 * b + 1]);
                    nb++;
                }
            fprintf(stderr, "PROF blocks=%d tasks=%.0f avg_total_cyc=%.3g max=%.3g wait_frac=%.3f cyc/iter/block=%.0f\n", nb, sn,
                st / nb, mx, sw / st, st / (sn * (M + W - 1)));
        }
#endif
    }
    double t3 = now();

    const float* res = (T - 1) & 1 ? U1 : U0;
    std::vector<float> line(N);
    CK(cudaMemcpy2D(line.data(), sizeof(float), res + (size_t)(56 + 48) * sD + 48, (size_t)sI * sizeof(float),
        sizeof(float), N, cudaMemcpyDeviceToHost));
    plane_sums_k<<<(N + 7) / 8, 256>>>(res, ps, N, sI, sD);
    CK(cudaGetLastError());
    std::vector<double> psh(N);
    CK(cudaMemcpy(psh.data(), ps, N * sizeof(double), cudaMemcpyDeviceToHost));
    g_printed = 1;
    for (int i = 0; i < N; i++)
        if (fabs(line[i]) >= PRINT_MIN && fabs(line[i]) <= PRINT_MAX)
            printf("%.6f\n", line[i]);
    double total = 0.0;
    for (int kz = 0; kz < N; kz++)
        total += psh[kz];
    printf("%.17g\n", total);
    fflush(stdout);
    double t4 = now();

    const char* dp = getenv("PULSE_DUMP");
    if (dp) {
        long pitch = pad_stride(N), slab = pad_stride(N * pitch);
        std::vector<float> g(cells), out((size_t)slab * N, 0.0f);
        CK(cudaMemcpy(g.data(), res, cells * sizeof(float), cudaMemcpyDeviceToHost));
        for (long k = 0; k < N; k++)
            for (long j = 0; j < N; j++)
                for (long i = 0; i < N; i++)
                    out[k * slab + j * pitch + i] = g[(size_t)i * sI + (size_t)(j + k) * sD + j];
        FILE* f = fopen(dp, "wb");
        fwrite(out.data(), sizeof(float), out.size(), f);
        fclose(f);
    }
    if (verbose)
        fprintf(stderr, "N=%d T=%d W=%d C=%d lam=%d host=%.4f alloc+init=%.4f sweep=%.4f out=%.4f total=%.4f ns/pt=%.4f\n", N, T, W, C, lam,
            t1 - t0, t2 - t1, t3 - t2, t4 - t3, t4 - t0, nsteps > 0 ? (t3 - t2) / ((double)nsteps * M * M * M) * 1e9 : 0.0);
    if (getenv("PULSE_NOEXIT"))
        return 0;
    fflush(stdout);
    fflush(stderr);
    _exit(0);
}
